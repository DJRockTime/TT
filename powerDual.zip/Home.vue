<!-- App.vue 或测试页面 -->
<template>
  <div style="padding: 40px; background: #f5f7fa; min-height: 100%">
    <h2 style="margin-bottom: 20px">双向绑定 + 回显验证</h2>

    <!-- 1. 实时显示父组件收到的值 -->
    <div
      style="
        margin-bottom: 20px;
        padding: 16px;
        background: white;
        border-radius: 8px;
      "
    >
      <strong>父组件当前 v-model 值：</strong>
      <pre style="margin-top: 8px; color: #e67e22">{{ selectedCodes }}</pre>
    </div>

    <!-- 2. 手动改值测试回显 -->
    <div style="margin-bottom: 20px">
      <button
        @click="setValue(['DOC0001', 'DOC0003'])"
        style="margin-right: 8px; padding: 8px 16px"
      >
        外部设为：合同范本 + 法律意见书
      </button>
      <button
        @click="setValue(['DOC0006'])"
        style="margin-right: 8px; padding: 8px 16px"
      >
        外部设为：专利申请
      </button>
      <button
        @click="setValue([])"
        style="padding: 8px 16px; background: #ff4d4f; color: white"
      >
        清空
      </button>
    </div>

    <!-- 3. 你的组件 -->
    <div class="transfer-container">
      <IDual v-model="selectedCodes" :allow-parent-select="true" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import IDual from "./IDual.vue"; // 你的组件路径

const selectedCodes = ref<string[]>(["DOC0003"]); // 初始回显一个

// 手动改值测试回显
const setValue = (arr: string[]) => {
  selectedCodes.value = arr;
  console.log("父组件强制设置值 →", arr);
};
</script>

<style>
pre {
  background: #f8f9fa;
  padding: 12px;
  border-radius: 6px;
  border: 1px solid #eee;
}

.transfer-container {
  height: 500px;
  padding: 16px;
  background: white;
  border-radius: 8px;
}
</style>
