package com.cmall.shop.respository;

import com.cmall.shop.dto.ProductDTO;
import com.cmall.shop.generated.tables.records.ProductRecord;
import org.jooq.DSLContext;
import org.springframework.stereotype.Repository;

import java.util.List;

import static com.cmall.shop.generated.Tables.PRODUCT;

@Repository
public class ProductRepository extends BaseRepository<ProductRecord, ProductDTO, Long> {
    protected ProductRepository(DSLContext dsl) {
        super(dsl, PRODUCT, ProductDTO.class, PRODUCT.ID);
    }

    /**
     * 专属逻辑： 根据店铺ID 查询商品列表
     */
    public List<ProductDTO> findByShopId(Long shopId) {
        return dsl.selectFrom(PRODUCT).where(PRODUCT.SHOP_ID.eq(shopId)).fetchInto(ProductDTO.class);
    }

    /**
     * 专属逻辑： 根据店铺ID 查询商品列表
     */
    public List<ProductDTO> findByCategory(Long shopId, String category) {
        return dsl.selectFrom(PRODUCT).where(PRODUCT.SHOP_ID.eq(shopId)).and(PRODUCT.CATEGORY.eq(category)).fetchInto(ProductDTO.class);
    }
}
