package com.cmall.shop.dto;

import java.util.List;

public record PageResult<T>(
        List<T> content,
        long total,
        int page,
        int size
) {
    public static <T> PageResult<T> of(List<T> content, long total, int page, int size) {
        return new PageResult<>(content, total, page, size);
    }
}