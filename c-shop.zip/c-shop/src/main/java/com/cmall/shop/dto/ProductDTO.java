package com.cmall.shop.dto;


import java.math.BigDecimal;

/**
 * 商品数据传输对象
 * 严格对应数据库字段，并为业务逻辑提供基础数据
 */
public record ProductDTO(Long id, Long shopId, String title, BigDecimal price, Integer stock, String category) {
}
