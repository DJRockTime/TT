package com.cmall.shop.dto;

import java.math.BigDecimal;

public record OrderItemDTO(
        Long id,
        Long orderId,
        Long productId,
        String productTitle, // 数据库 item 表没这个，需要关联 product 表查
        BigDecimal unitPrice,
        Integer quantity
) {}
