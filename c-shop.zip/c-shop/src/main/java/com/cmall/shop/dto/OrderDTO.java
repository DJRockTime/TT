package com.cmall.shop.dto;


import java.math.BigDecimal;
import java.time.LocalDateTime;

public record OrderDTO(Long id, String orderNo, BigDecimal amount, String status, LocalDateTime createdAt) {
}
