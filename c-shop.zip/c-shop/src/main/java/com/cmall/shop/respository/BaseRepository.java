package com.cmall.shop.respository;

import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.Table;
import org.jooq.UpdatableRecord;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;


@Repository
public abstract class BaseRepository<R extends UpdatableRecord<R>, D, ID> {

    protected final DSLContext dsl;
    protected final Table<R> table;
    protected final Class<D> dtoClass;
    protected final Field<ID> idField;

    protected BaseRepository(DSLContext dsl, Table<R> table, Class<D> dtoClass, Field<ID> idField) {
        this.dsl = dsl;
        this.table = table;
        this.dtoClass = dtoClass;
        this.idField = idField;
    }

    // 1. 单个查询
    public Optional<D> findById(ID id) {
        return dsl.selectFrom(table).where(idField.eq(id)).fetchOptionalInto(dtoClass);
    }

    // 2. 批量查询
    public List<D> findByIds(Collection<ID> ids) {
        return dsl.selectFrom(table).where(idField.in(ids)).fetchInto(dtoClass);
    }

    // 3. 检查是否存在
    public boolean existsById(ID id) {
        return dsl.fetchExists(dsl.selectOne().from(table).where(idField.eq(id)));
    }

    // 4. 通用删除
    public int deleteById(ID id) {
        return dsl.deleteFrom(table).where(idField.eq(id)).execute();
    }

    // 5. 计数
    public long count() {
        return dsl.fetchCount(table);
    }
}
