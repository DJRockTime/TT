package com.cmall.shop.service;

import com.cmall.shop.dto.ProductDTO;
import com.cmall.shop.respository.ProductRepository;
import com.cmall.shop.vo.ProductHealthVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public List<ProductHealthVO> checkShopProductsHealth(Long shopId) {
        List<ProductDTO> products = productRepository.findByShopId(shopId);

        return products.stream()
                .map(this::mapToHealthVO) // 调用下方的私有转换方法
                .toList();
    }

    private ProductHealthVO mapToHealthVO(ProductDTO dto) {
        List<String> tags = new ArrayList<>();

        if(dto.stock() != null && dto.stock() < 10) {
            tags.add("LOW_STOCK");
        }

        // 规则 2：高端商品 (注意 BigDecimal 的比较方式)
        if (dto.price() != null && dto.price().compareTo(new BigDecimal("5000")) > 0) {
            tags.add("PREMIUM");
        }

        // 规则 3：清仓建议 (预留逻辑)
        if (dto.stock() != null && dto.stock() > 100 &&
                dto.price() != null && dto.price().compareTo(new BigDecimal("50")) < 0) {
            tags.add("OVERSTOCK_SALE");
        }

        // 封装返回 VO
        return new ProductHealthVO(
                dto.title(),
                dto.stock(),
                tags
        );


    }

}
