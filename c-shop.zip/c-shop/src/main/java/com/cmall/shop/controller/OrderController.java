package com.cmall.shop.controller;


import com.cmall.shop.dto.OrderDTO;

import com.cmall.shop.dto.PageResult;
import com.cmall.shop.dto.Result;
import com.cmall.shop.generated.Tables;
import com.cmall.shop.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class OrderController {

    private final DSLContext dsl;
    private final RestClient managerClient;
    private final OrderService orderService;


    @GetMapping("/orders")
    public List<OrderDTO> getOrders() {
        return dsl.select(Tables.ORDERS.ORDER_NO, Tables.ORDERS.AMOUNT, Tables.ORDERS.STATUS, Tables.ORDERS.CREATED_AT).from(Tables.ORDERS).fetchInto(OrderDTO.class);
    }

    @GetMapping("/orders/detail")
    public List<OrderDTO> getOrdersWithShop() {
        // 1. 先从数据库查订单 (jOOQ)
        var orders = dsl.selectFrom(Tables.ORDERS).fetchInto(OrderDTO.class);

        // 2. 这里的“魔法”：调用远程 c-manager 接口获取店铺信息
        // 假设我们要给第一个订单找店铺名
        if (!orders.isEmpty()) {
            // 调用 8066 端口的接口
            String shopInfo = managerClient.get().uri("/shops").retrieve().body(String.class); // 暂时拿字符串看看效果
            System.out.println("从 Manager 获取的店铺信息: " + shopInfo);
        }

        return orders;
    }

    @GetMapping("/v2/{shopId}/orders")
    public Result<PageResult<OrderDTO>> getOrders(@PathVariable Long shopId, @RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer size) {
        // return orderService.getOrderByShop(shopId, page, size);
        return Result.success(orderService.getOrderByShop2(shopId, page, size));
    }
}
