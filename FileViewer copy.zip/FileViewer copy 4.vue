<template>
    <div class="file-manager">
        <!-- ==================== 顶部工具栏 ==================== -->
        <header class="file-manager__header">
            <div class="header-left">
                <div class="header-title">
                    <span class="header-title__icon">📁</span>
                    <div>
                        <div class="header-title__text">文件管理器</div>
                        <div class="header-title__sub">
                            {{ filteredFiles.length }} 个文件
                        </div>
                    </div>
                </div>
            </div>

            <div class="header-right">
                <div class="search-box">
                    <span class="search-box__icon">⌕</span>

                    <input
                        v-model="searchKeyword"
                        type="text"
                        placeholder="搜索文件..."
                    />

                    <button
                        v-if="searchKeyword"
                        class="search-box__clear"
                        type="button"
                        @click="searchKeyword = ''"
                    >
                        ×
                    </button>
                </div>

                <button
                    class="upload-button"
                    type="button"
                    @click="openFilePicker"
                >
                    <span>＋</span>
                    <span>上传文件</span>
                </button>

                <input
                    ref="fileInputRef"
                    class="hidden-input"
                    type="file"
                    multiple
                    @change="handleFileInput"
                />
            </div>
        </header>

        <!-- ==================== 主体 ==================== -->
        <main class="file-manager__body">
            <!-- ==================== 左侧文件区域 ==================== -->
            <aside
                class="file-panel"
                :class="{
                    'file-panel--dragging': isDragging,
                }"
                @dragenter.prevent="handleDragEnter"
                @dragover.prevent="handleDragOver"
                @dragleave.prevent="handleDragLeave"
                @drop.prevent="handleDrop"
            >
                <!-- 文件区域头部 -->
                <div class="file-panel__header">
                    <div class="file-panel__title">
                        <span>全部文件</span>
                        <span class="file-count">
                            {{ filteredFiles.length }}
                        </span>
                    </div>

                    <button
                        class="icon-button"
                        type="button"
                        title="刷新"
                        @click="refreshFiles"
                    >
                        ↻
                    </button>
                </div>

                <!-- 文件列表 -->
                <div class="file-list">
                    <!-- 空状态 -->
                    <div v-if="filteredFiles.length === 0" class="file-empty">
                        <div class="file-empty__icon">
                            {{ searchKeyword ? "🔎" : "📂" }}
                        </div>

                        <div class="file-empty__title">
                            {{
                                searchKeyword ? "没有找到匹配文件" : "暂无文件"
                            }}
                        </div>

                        <div class="file-empty__sub">
                            {{
                                searchKeyword
                                    ? "换个关键词试试"
                                    : "点击上传或将文件拖到这里"
                            }}
                        </div>

                        <button
                            v-if="!searchKeyword"
                            class="empty-upload-button"
                            type="button"
                            @click="openFilePicker"
                        >
                            上传文件
                        </button>
                    </div>

                    <!-- 文件 -->
                    <div
                        v-for="file in filteredFiles"
                        :key="file.id"
                        class="file-item"
                        :class="{
                            'file-item--active': selectedFile?.id === file.id,
                        }"
                        @click="selectFile(file)"
                    >
                        <!-- 文件图标 -->
                        <div
                            class="file-item__icon"
                            :class="`file-item__icon--${file.type}`"
                        >
                            {{ getFileIconText(file) }}
                        </div>

                        <!-- 文件信息 -->
                        <div class="file-item__content">
                            <div class="file-item__name" :title="file.name">
                                {{ file.name }}
                            </div>

                            <div class="file-item__meta">
                                <span>
                                    {{ formatFileSize(file.size) }}
                                </span>

                                <span>·</span>

                                <span>
                                    {{ formatTime(file.createdAt) }}
                                </span>
                            </div>
                        </div>

                        <!-- 文件操作 -->
                        <div class="file-item__actions" @click.stop>
                            <button
                                class="file-action"
                                type="button"
                                title="预览"
                                @click="selectFile(file)"
                            >
                                👁
                            </button>

                            <button
                                class="file-action"
                                type="button"
                                title="下载"
                                @click="downloadFile(file)"
                            >
                                ↓
                            </button>

                            <button
                                class="file-action file-action--danger"
                                type="button"
                                title="删除"
                                @click="deleteFile(file)"
                            >
                                ×
                            </button>
                        </div>
                    </div>
                </div>

                <!-- 拖拽提示 -->
                <Transition name="fade">
                    <div v-if="isDragging" class="drop-overlay">
                        <div class="drop-overlay__content">
                            <div class="drop-overlay__icon">↓</div>

                            <div class="drop-overlay__title">
                                松开鼠标上传文件
                            </div>

                            <div class="drop-overlay__sub">
                                支持 PPTX、XLSX、DOCX、PDF、图片、TXT
                            </div>
                        </div>
                    </div>
                </Transition>
            </aside>

            <!-- ==================== 右侧预览区域 ==================== -->
            <section class="preview-panel">
                <!-- 没有选择文件 -->
                <div v-if="!selectedFile" class="preview-empty">
                    <div class="preview-empty__illustration">
                        <div class="preview-empty__folder">📁</div>
                    </div>

                    <div class="preview-empty__title">选择一个文件开始预览</div>

                    <div class="preview-empty__sub">
                        支持 Word、Excel、PPT、PDF、图片和文本文件
                    </div>

                    <button
                        class="preview-empty__button"
                        type="button"
                        @click="openFilePicker"
                    >
                        上传文件
                    </button>
                </div>

                <!-- ==================== 文件预览 ==================== -->
                <template v-else>
                    <!-- 预览头部 -->
                    <div class="preview-header">
                        <div class="preview-header__file">
                            <div
                                class="preview-header__icon"
                                :class="`file-item__icon--${selectedFile.type}`"
                            >
                                {{ getFileIconText(selectedFile) }}
                            </div>

                            <div class="preview-header__info">
                                <div
                                    class="preview-header__name"
                                    :title="selectedFile.name"
                                >
                                    {{ selectedFile.name }}
                                </div>

                                <div class="preview-header__meta">
                                    {{ formatFileSize(selectedFile.size) }}
                                    <span>·</span>
                                    {{ getFileTypeLabel(selectedFile) }}
                                </div>
                            </div>
                        </div>

                        <div class="preview-header__actions">
                            <button
                                class="preview-tool-button"
                                type="button"
                                title="下载"
                                @click="downloadFile(selectedFile)"
                            >
                                <span>↓</span>
                                <span>下载</span>
                            </button>

                            <button
                                class="preview-tool-button preview-tool-button--danger"
                                type="button"
                                title="删除"
                                @click="deleteFile(selectedFile)"
                            >
                                <span>×</span>
                                <span>删除</span>
                            </button>
                        </div>
                    </div>

                    <!-- ==================== 预览内容 ==================== -->
                    <div ref="previewContainerRef" class="preview-content">
                        <!-- 加载状态 -->
                        <Transition name="fade">
                            <div v-if="previewLoading" class="preview-loading">
                                <div class="loading-spinner" />

                                <div class="preview-loading__text">
                                    正在解析文件...
                                </div>

                                <div class="preview-loading__sub">
                                    {{ selectedFile.name }}
                                </div>
                            </div>
                        </Transition>

                        <!-- 错误 -->
                        <div v-if="previewError" class="preview-error">
                            <div class="preview-error__icon">!</div>

                            <div class="preview-error__title">文件预览失败</div>

                            <div class="preview-error__message">
                                {{ previewError }}
                            </div>

                            <div class="preview-error__actions">
                                <button
                                    class="preview-error__button"
                                    type="button"
                                    @click="reloadPreview"
                                >
                                    重新加载
                                </button>

                                <button
                                    class="preview-error__button preview-error__button--secondary"
                                    type="button"
                                    @click="downloadFile(selectedFile)"
                                >
                                    下载文件
                                </button>
                            </div>
                        </div>

                        <!-- ==================== PPTX ==================== -->
                        <div
                            v-if="
                                selectedFile &&
                                selectedFile.type === 'pptx' &&
                                !previewError
                            "
                            ref="pptxContainerRef"
                            class="office-preview office-preview--pptx"
                        >
                            <div class="pptx-toolbar">
                                <div class="pptx-toolbar__left">
                                    <span class="pptx-toolbar__label">
                                        演示文稿
                                    </span>
                                </div>

                                <div class="pptx-toolbar__center">
                                    <button
                                        class="pptx-control"
                                        type="button"
                                        :disabled="pptxCurrentSlide <= 0"
                                        @click="pptxPrevious"
                                    >
                                        ‹
                                    </button>

                                    <span class="pptx-page">
                                        {{ pptxCurrentSlide + 1 }}
                                        /
                                        {{ pptxSlideCount }}
                                    </span>

                                    <button
                                        class="pptx-control"
                                        type="button"
                                        :disabled="
                                            pptxCurrentSlide >=
                                            pptxSlideCount - 1
                                        "
                                        @click="pptxNext"
                                    >
                                        ›
                                    </button>
                                </div>

                                <div class="pptx-toolbar__right">
                                    <button
                                        class="pptx-control"
                                        type="button"
                                        :disabled="pptxZoom <= 30"
                                        @click="pptxZoomOut"
                                    >
                                        −
                                    </button>

                                    <button
                                        class="pptx-zoom"
                                        type="button"
                                        @click="pptxResetZoom"
                                    >
                                        {{ pptxZoom }}%
                                    </button>

                                    <button
                                        class="pptx-control"
                                        type="button"
                                        :disabled="pptxZoom >= 200"
                                        @click="pptxZoomIn"
                                    >
                                        +
                                    </button>

                                    <button
                                        class="pptx-control pptx-control--fullscreen"
                                        type="button"
                                        title="全屏"
                                        @click="togglePreviewFullscreen"
                                    >
                                        ⛶
                                    </button>
                                </div>
                            </div>

                            <div ref="pptxViewportRef" class="pptx-viewport">
                                <div
                                    ref="pptxRendererRef"
                                    class="pptx-renderer"
                                />
                            </div>
                        </div>

                        <!-- ==================== XLSX ==================== -->
                        <div
                            v-else-if="
                                selectedFile &&
                                selectedFile.type === 'xlsx' &&
                                !previewError
                            "
                            class="office-preview office-preview--xlsx"
                        >
                            <div class="xlsx-toolbar">
                                <div class="xlsx-sheet-info">
                                    <span class="xlsx-sheet-icon"> XLS </span>

                                    <span>
                                        {{ xlsxSheets.length }}
                                        个工作表
                                    </span>
                                </div>

                                <div
                                    v-if="xlsxSheets.length"
                                    class="xlsx-sheet-tabs"
                                >
                                    <button
                                        v-for="(sheet, index) in xlsxSheets"
                                        :key="sheet.name"
                                        class="xlsx-sheet-tab"
                                        :class="{
                                            'xlsx-sheet-tab--active':
                                                xlsxActiveSheet === index,
                                        }"
                                        type="button"
                                        @click="xlsxActiveSheet = index"
                                    >
                                        {{ sheet.name }}
                                    </button>
                                </div>
                            </div>

                            <div class="xlsx-content">
                                <div
                                    v-if="xlsxSheets.length"
                                    class="xlsx-table-wrapper"
                                >
                                    <table class="xlsx-table">
                                        <tbody>
                                            <tr
                                                v-for="(
                                                    row, rowIndex
                                                ) in currentXlsxRows"
                                                :key="rowIndex"
                                            >
                                                <th class="xlsx-row-number">
                                                    {{ rowIndex + 1 }}
                                                </th>

                                                <td
                                                    v-for="(
                                                        cell, cellIndex
                                                    ) in row"
                                                    :key="cellIndex"
                                                    class="xlsx-cell"
                                                >
                                                    {{ cell }}
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div v-else class="format-empty">
                                    Excel 中没有可显示的数据
                                </div>
                            </div>
                        </div>

                        <!-- ==================== DOCX ==================== -->
                        <div
                            v-else-if="
                                selectedFile &&
                                selectedFile.type === 'docx' &&
                                !previewError
                            "
                            class="office-preview office-preview--docx"
                        >
                            <div ref="docxContainerRef" class="docx-renderer" />
                        </div>

                        <!-- ==================== PDF ==================== -->
                        <div
                            v-else-if="
                                selectedFile &&
                                selectedFile.type === 'pdf' &&
                                !previewError
                            "
                            class="office-preview office-preview--pdf"
                        >
                            <iframe
                                v-if="pdfObjectUrl"
                                class="pdf-frame"
                                :src="pdfObjectUrl"
                                title="PDF Preview"
                            />
                        </div>

                        <!-- ==================== 图片 ==================== -->
                        <div
                            v-else-if="
                                selectedFile &&
                                selectedFile.type === 'image' &&
                                !previewError
                            "
                            class="office-preview office-preview--image"
                        >
                            <div class="image-preview-toolbar">
                                <button
                                    class="preview-control"
                                    type="button"
                                    @click="imageZoomOut"
                                >
                                    −
                                </button>

                                <button
                                    class="preview-zoom"
                                    type="button"
                                    @click="imageResetZoom"
                                >
                                    {{ imageZoom }}%
                                </button>

                                <button
                                    class="preview-control"
                                    type="button"
                                    @click="imageZoomIn"
                                >
                                    +
                                </button>

                                <button
                                    class="preview-control"
                                    type="button"
                                    @click="togglePreviewFullscreen"
                                >
                                    ⛶
                                </button>
                            </div>

                            <div ref="imageViewportRef" class="image-viewport">
                                <img
                                    v-if="imageObjectUrl"
                                    class="image-preview"
                                    :src="imageObjectUrl"
                                    :alt="selectedFile.name"
                                    :style="{
                                        transform: `scale(${imageZoom / 100})`,
                                    }"
                                />
                            </div>
                        </div>

                        <!-- ==================== 文本 ==================== -->
                        <div
                            v-else-if="
                                selectedFile &&
                                selectedFile.type === 'text' &&
                                !previewError
                            "
                            class="office-preview office-preview--text"
                        >
                            <pre class="text-preview">{{ textContent }}</pre>
                        </div>

                        <!-- ==================== 其他 ==================== -->
                        <div
                            v-else-if="
                                selectedFile && !previewLoading && !previewError
                            "
                            class="format-empty"
                        >
                            <div class="format-empty__icon">📄</div>

                            <div class="format-empty__title">
                                暂不支持在线预览
                            </div>

                            <div class="format-empty__sub">
                                可以下载文件后使用本地应用打开
                            </div>

                            <button
                                class="preview-error__button"
                                type="button"
                                @click="downloadFile(selectedFile)"
                            >
                                下载文件
                            </button>
                        </div>
                    </div>
                </template>
            </section>
        </main>

        <!-- ==================== 上传进度 ==================== -->
        <Transition name="slide-up">
            <div v-if="uploading" class="upload-status">
                <div class="upload-status__icon">↑</div>

                <div class="upload-status__content">
                    <div class="upload-status__title">正在添加文件</div>

                    <div class="upload-status__sub">
                        {{ uploadingFileName }}
                    </div>
                </div>

                <div class="upload-spinner" />
            </div>
        </Transition>

        <!-- ==================== 删除确认 ==================== -->
        <Transition name="fade">
            <div
                v-if="deleteTarget"
                class="modal-mask"
                @click.self="cancelDelete"
            >
                <div class="delete-dialog">
                    <div class="delete-dialog__icon">🗑</div>

                    <div class="delete-dialog__title">删除文件</div>

                    <div class="delete-dialog__message">
                        确定要删除
                        <strong>{{ deleteTarget.name }}</strong>
                        吗？
                        <br />
                        删除后无法恢复。
                    </div>

                    <div class="delete-dialog__actions">
                        <button
                            class="dialog-button dialog-button--secondary"
                            type="button"
                            @click="cancelDelete"
                        >
                            取消
                        </button>

                        <button
                            class="dialog-button dialog-button--danger"
                            type="button"
                            @click="confirmDelete"
                        >
                            删除
                        </button>
                    </div>
                </div>
            </div>
        </Transition>
    </div>
</template>

<script setup lang="ts">
import {
    computed,
    nextTick,
    onBeforeUnmount,
    onMounted,
    ref,
    watch,
} from "vue";

import * as XLSX from "xlsx";

import {
    PptxViewer as PptxRendererViewer,
    RECOMMENDED_ZIP_LIMITS,
} from "@aiden0z/pptx-renderer";

import { renderAsync as renderDocx } from "docx-preview";

/* =========================================================
 * 类型
 * ========================================================= */

type FileType = "pptx" | "xlsx" | "docx" | "pdf" | "image" | "text" | "other";

interface FileItem {
    id: string;
    name: string;
    size: number;
    type: FileType;
    extension: string;
    mimeType: string;
    createdAt: number;
    file: File;
}

/* =========================================================
 * DOM
 * ========================================================= */

const fileInputRef = ref<HTMLInputElement | null>(null);

const previewContainerRef = ref<HTMLElement | null>(null);

const pptxContainerRef = ref<HTMLElement | null>(null);
const pptxRendererRef = ref<HTMLElement | null>(null);
const pptxViewportRef = ref<HTMLElement | null>(null);

const docxContainerRef = ref<HTMLElement | null>(null);

const imageViewportRef = ref<HTMLElement | null>(null);

/* =========================================================
 * 文件状态
 * ========================================================= */

const files = ref<FileItem[]>([]);

const selectedFile = ref<FileItem | null>(null);

const searchKeyword = ref("");

const isDragging = ref(false);

let dragCounter = 0;

/* =========================================================
 * 上传状态
 * ========================================================= */

const uploading = ref(false);

const uploadingFileName = ref("");

/* =========================================================
 * 删除
 * ========================================================= */

const deleteTarget = ref<FileItem | null>(null);

/* =========================================================
 * 预览状态
 * ========================================================= */

const previewLoading = ref(false);

const previewError = ref("");

let previewAbortController: AbortController | null = null;

/* =========================================================
 * PPTX
 * ========================================================= */

const pptxViewer = ref<PptxRendererViewer | null>(null);

/**
 * 当前 PPT 页码
 *
 * 0-based
 */
const pptxCurrentSlide = ref(0);

/**
 * PPT 总页数
 */
const pptxSlideCount = ref(0);

/**
 * PPT 缩放
 */
const pptxZoom = ref(100);

/* =========================================================
 * XLSX
 * ========================================================= */

interface XlsxSheet {
    name: string;
    rows: string[][];
}

const xlsxSheets = ref<XlsxSheet[]>([]);

/**
 * 当前 Sheet
 *
 * 0-based
 */
const xlsxActiveSheet = ref(0);

/**
 * 当前 Sheet 数据
 */
const currentXlsxRows = computed(() => {
    return xlsxSheets.value[xlsxActiveSheet.value]?.rows || [];
});

/* =========================================================
 * DOCX
 * ========================================================= */

const docxObjectUrl = ref("");

/* =========================================================
 * PDF
 * ========================================================= */

const pdfObjectUrl = ref("");

/* =========================================================
 * IMAGE
 * ========================================================= */

const imageObjectUrl = ref("");

const imageZoom = ref(100);

/* =========================================================
 * TEXT
 * ========================================================= */

const textContent = ref("");

/* =========================================================
 * 过滤
 * ========================================================= */

const filteredFiles = computed(() => {
    const keyword = searchKeyword.value.trim().toLowerCase();

    if (!keyword) {
        return files.value;
    }

    return files.value.filter((file) =>
        file.name.toLowerCase().includes(keyword),
    );
});

/* =========================================================
 * 文件类型
 * ========================================================= */

function getFileType(file: File): FileType {
    const name = file.name.toLowerCase();

    const extension = name.includes(".") ? name.split(".").pop() || "" : "";

    if (extension === "pptx" || extension === "ppt") {
        return "pptx";
    }

    if (extension === "xlsx" || extension === "xls" || extension === "csv") {
        return "xlsx";
    }

    if (extension === "docx" || extension === "doc") {
        return "docx";
    }

    if (extension === "pdf") {
        return "pdf";
    }

    if (
        ["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "ico"].includes(
            extension,
        )
    ) {
        return "image";
    }

    if (
        ["txt", "md", "json", "xml", "html", "css", "js", "ts", "vue"].includes(
            extension,
        )
    ) {
        return "text";
    }

    return "other";
}

/* =========================================================
 * 文件图标
 * ========================================================= */

function getFileIconText(file: FileItem) {
    switch (file.type) {
        case "pptx":
            return "PPT";

        case "xlsx":
            return "XLS";

        case "docx":
            return "DOC";

        case "pdf":
            return "PDF";

        case "image":
            return "IMG";

        case "text":
            return "TXT";

        default:
            return "FILE";
    }
}

function getFileTypeLabel(file: FileItem) {
    switch (file.type) {
        case "pptx":
            return "PowerPoint";

        case "xlsx":
            return "Excel";

        case "docx":
            return "Word";

        case "pdf":
            return "PDF";

        case "image":
            return "图片";

        case "text":
            return "文本";

        default:
            return file.extension.toUpperCase();
    }
}

/* =========================================================
 * 上传
 * ========================================================= */

function openFilePicker() {
    fileInputRef.value?.click();
}

function handleFileInput(event: Event) {
    const input = event.target as HTMLInputElement;

    if (!input.files?.length) {
        return;
    }

    addFiles(Array.from(input.files));

    input.value = "";
}

function handleDragEnter() {
    dragCounter++;

    isDragging.value = true;
}

function handleDragOver() {
    isDragging.value = true;
}

function handleDragLeave() {
    dragCounter--;

    if (dragCounter <= 0) {
        dragCounter = 0;
        isDragging.value = false;
    }
}

function handleDrop(event: DragEvent) {
    dragCounter = 0;

    isDragging.value = false;

    const droppedFiles = event.dataTransfer?.files;

    if (!droppedFiles?.length) {
        return;
    }

    addFiles(Array.from(droppedFiles));
}

async function addFiles(newFiles: File[]) {
    if (!newFiles.length) {
        return;
    }

    uploading.value = true;

    for (const file of newFiles) {
        uploadingFileName.value = file.name;

        await new Promise((resolve) => setTimeout(resolve, 80));

        const extension = file.name.includes(".")
            ? file.name.split(".").pop()?.toLowerCase() || ""
            : "";

        const item: FileItem = {
            id: createFileId(),
            name: file.name,
            size: file.size,
            type: getFileType(file),
            extension,
            mimeType: file.type || "application/octet-stream",
            createdAt: Date.now(),
            file,
        };

        files.value.unshift(item);
    }

    uploading.value = false;

    uploadingFileName.value = "";

    if (!selectedFile.value && files.value.length) {
        await selectFile(files.value[0]);
    }
}

function createFileId() {
    return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

/* =========================================================
 * 文件选择
 * ========================================================= */

async function selectFile(file: FileItem) {
    if (selectedFile.value?.id === file.id) {
        await reloadPreview();
        return;
    }

    selectedFile.value = file;

    await nextTick();

    await loadPreview(file);
}

/* =========================================================
 * 预览入口
 * ========================================================= */

async function loadPreview(file: FileItem) {
    cleanupPreview();

    previewLoading.value = true;

    previewError.value = "";

    try {
        switch (file.type) {
            case "pptx":
                await loadPptx(file);
                break;

            case "xlsx":
                await loadXlsx(file);
                break;

            case "docx":
                await loadDocx(file);
                break;

            case "pdf":
                await loadPdf(file);
                break;

            case "image":
                await loadImage(file);
                break;

            case "text":
                await loadText(file);
                break;

            default:
                break;
        }
    } catch (error: any) {
        console.error("[FileManager] preview error:", error);

        previewError.value =
            error?.message || "文件解析失败，请检查文件是否损坏。";
    } finally {
        previewLoading.value = false;
    }
}

/* =========================================================
 * PPTX
 * ========================================================= */

async function loadPptx(file: FileItem) {
    await nextTick();

    if (!pptxRendererRef.value) {
        throw new Error("PPTX 预览容器初始化失败。");
    }

    const buffer = await file.file.arrayBuffer();

    if (!buffer.byteLength) {
        throw new Error("PPTX 文件为空。");
    }

    const controller = new AbortController();

    previewAbortController = controller;

    /*
     * 这里使用 PptxViewer 的 slide 模式。
     *
     * slide 模式：
     * - 一次只显示当前页
     * - goToSlide(index) 切换页面
     * - slideCount 获取总页数
     * - currentSlideIndex 获取当前页
     *
     * @aiden0z/pptx-renderer 1.2.4 官方 API 支持。
     */
    const viewer = await PptxRendererViewer.open(
        buffer,
        pptxRendererRef.value,
        {
            fitMode: "contain",

            zoomPercent: pptxZoom.value,

            renderMode: "slide",

            zipLimits: RECOMMENDED_ZIP_LIMITS,

            signal: controller.signal,

            onSlideChange(index) {
                pptxCurrentSlide.value = index;
            },

            onSlideError(index, error) {
                console.error(`PPTX 第 ${index + 1} 页渲染失败`, error);
            },

            onRenderStart() {
                previewLoading.value = true;
            },

            onRenderComplete() {
                previewLoading.value = false;
            },
        },
    );

    pptxViewer.value = viewer;

    pptxSlideCount.value = viewer.slideCount;

    pptxCurrentSlide.value = viewer.currentSlideIndex;

    pptxZoom.value = viewer.zoomPercent;

    /*
     * 如果文件存在多个页面，
     * 确保初始页从第一页开始。
     */
    if (pptxSlideCount.value > 0 && pptxCurrentSlide.value < 0) {
        pptxCurrentSlide.value = 0;
    }
}

/**
 * PPT 上一页
 */
async function pptxPrevious() {
    const viewer = pptxViewer.value;

    if (!viewer) {
        return;
    }

    if (pptxCurrentSlide.value <= 0) {
        return;
    }

    const index = pptxCurrentSlide.value - 1;

    await viewer.goToSlide(index);

    pptxCurrentSlide.value = viewer.currentSlideIndex;

    scrollPptxToCurrentSlide();
}

/**
 * PPT 下一页
 */
async function pptxNext() {
    const viewer = pptxViewer.value;

    if (!viewer) {
        return;
    }

    if (pptxCurrentSlide.value >= pptxSlideCount.value - 1) {
        return;
    }

    const index = pptxCurrentSlide.value + 1;

    await viewer.goToSlide(index);

    pptxCurrentSlide.value = viewer.currentSlideIndex;

    scrollPptxToCurrentSlide();
}

/**
 * PPT 跳转到指定页
 *
 * index 为 0-based
 */
async function pptxGoToSlide(index: number) {
    const viewer = pptxViewer.value;

    if (!viewer) {
        return;
    }

    if (index < 0 || index >= pptxSlideCount.value) {
        return;
    }

    await viewer.goToSlide(index);

    pptxCurrentSlide.value = viewer.currentSlideIndex;

    scrollPptxToCurrentSlide();
}

/**
 * 将当前 PPT 页面滚动到视口中央
 *
 * slide 模式下通常只有当前页，
 * 这里主要兼容 renderer 内部产生的 DOM。
 */
function scrollPptxToCurrentSlide() {
    nextTick(() => {
        const viewport = pptxViewportRef.value;

        if (!viewport) {
            return;
        }

        const renderer = pptxRendererRef.value;

        if (!renderer) {
            return;
        }

        const slideElement = renderer.firstElementChild;

        if (slideElement instanceof HTMLElement) {
            slideElement.scrollIntoView({
                behavior: "smooth",
                block: "center",
                inline: "center",
            });
        }
    });
}

/**
 * PPT 放大
 */
function pptxZoomIn() {
    setPptxZoom(pptxZoom.value + 10);
}

/**
 * PPT 缩小
 */
function pptxZoomOut() {
    setPptxZoom(pptxZoom.value - 10);
}

/**
 * PPT 重置缩放
 */
function pptxResetZoom() {
    setPptxZoom(100);
}

/**
 * 设置 PPT 缩放
 */
function setPptxZoom(value: number) {
    const viewer = pptxViewer.value;

    if (!viewer) {
        return;
    }

    const next = Math.max(30, Math.min(200, value));

    pptxZoom.value = next;

    viewer.setZoom(next);
}

/* =========================================================
 * XLSX
 * ========================================================= */

async function loadXlsx(file: FileItem) {
    const buffer = await file.file.arrayBuffer();

    if (!buffer.byteLength) {
        throw new Error("Excel 文件为空。");
    }

    const workbook = XLSX.read(buffer, {
        type: "array",

        cellDates: true,

        cellStyles: true,

        /*
         * 保持公式结果可读。
         */
        cellFormula: true,
    });

    /*
     * Excel 没有 Sheet 时，
     * 直接进入空状态。
     */
    if (!workbook.SheetNames.length) {
        xlsxSheets.value = [];

        xlsxActiveSheet.value = 0;

        return;
    }

    /*
     * 一次解析全部 Sheet。
     *
     * 例如：
     *
     * Sheet1
     * Sheet2
     * Sheet3
     *
     * 最终：
     *
     * xlsxSheets[0]
     * xlsxSheets[1]
     * xlsxSheets[2]
     */
    xlsxSheets.value = workbook.SheetNames.map((sheetName) => {
        const sheet = workbook.Sheets[sheetName];

        if (!sheet) {
            return {
                name: sheetName,
                rows: [],
            };
        }

        const rows = XLSX.utils.sheet_to_json(sheet, {
            header: 1,

            raw: false,

            defval: "",
        }) as unknown[][];

        return {
            name: sheetName,

            rows: rows.map((row) =>
                row.map((cell) => {
                    if (cell === null || cell === undefined) {
                        return "";
                    }

                    return String(cell);
                }),
            ),
        };
    });

    /*
     * 每次重新打开 Excel，
     * 默认回到第一个 Sheet。
     */
    xlsxActiveSheet.value = 0;
}

/**
 * Excel 切换 Sheet
 */
function switchXlsxSheet(index: number) {
    if (index < 0 || index >= xlsxSheets.value.length) {
        return;
    }

    xlsxActiveSheet.value = index;
}

/* =========================================================
 * DOCX
 * ========================================================= */

async function loadDocx(file: FileItem) {
    await nextTick();

    if (!docxContainerRef.value) {
        throw new Error("Word 预览容器初始化失败。");
    }

    const buffer = await file.file.arrayBuffer();

    if (!buffer.byteLength) {
        throw new Error("Word 文件为空。");
    }

    await renderDocx(buffer, docxContainerRef.value, undefined, {
        className: "docx-preview-container",

        inWrapper: true,

        breakPages: true,

        ignoreWidth: false,

        ignoreHeight: false,

        ignoreFonts: false,

        renderHeaders: true,

        renderFooters: true,

        renderFootnotes: true,

        renderEndnotes: true,
    });
}

/* =========================================================
 * PDF
 * ========================================================= */

async function loadPdf(file: FileItem) {
    if (!file.size) {
        throw new Error("PDF 文件为空。");
    }

    pdfObjectUrl.value = URL.createObjectURL(file.file);
}

/* =========================================================
 * IMAGE
 * ========================================================= */

async function loadImage(file: FileItem) {
    if (!file.size) {
        throw new Error("图片文件为空。");
    }

    imageZoom.value = 100;

    imageObjectUrl.value = URL.createObjectURL(file.file);
}

/* =========================================================
 * TEXT
 * ========================================================= */

async function loadText(file: FileItem) {
    /*
     * 0KB TXT 是合法的空文件。
     *
     * 不报错，直接显示空状态。
     */
    if (!file.size) {
        textContent.value = "";

        return;
    }

    textContent.value = await file.file.text();
}

/* =========================================================
 * 图片缩放
 * ========================================================= */

function imageZoomIn() {
    imageZoom.value = Math.min(300, imageZoom.value + 10);
}

function imageZoomOut() {
    imageZoom.value = Math.max(20, imageZoom.value - 10);
}

function imageResetZoom() {
    imageZoom.value = 100;
}

/* =========================================================
 * 全屏
 * ========================================================= */

async function togglePreviewFullscreen() {
    const element = previewContainerRef.value;

    if (!element) {
        return;
    }

    try {
        if (!document.fullscreenElement) {
            await element.requestFullscreen();
        } else {
            await document.exitFullscreen();
        }
    } catch (error) {
        console.warn("[FileManager] fullscreen error:", error);
    }
}

/* =========================================================
 * 下载
 * ========================================================= */

function downloadFile(file: FileItem) {
    const url = URL.createObjectURL(file.file);

    const anchor = document.createElement("a");

    anchor.href = url;

    anchor.download = file.name;

    document.body.appendChild(anchor);

    anchor.click();

    anchor.remove();

    setTimeout(() => {
        URL.revokeObjectURL(url);
    }, 1000);
}

/* =========================================================
 * 删除
 * ========================================================= */

function deleteFile(file: FileItem) {
    deleteTarget.value = file;
}

function cancelDelete() {
    deleteTarget.value = null;
}

async function confirmDelete() {
    const target = deleteTarget.value;

    if (!target) {
        return;
    }

    const index = files.value.findIndex((file) => file.id === target.id);

    if (index !== -1) {
        files.value.splice(index, 1);
    }

    if (selectedFile.value?.id === target.id) {
        cleanupPreview();

        selectedFile.value = null;
    }

    deleteTarget.value = null;
}

/* =========================================================
 * 刷新
 * ========================================================= */

function refreshFiles() {
    /*
     * 当前文件全部存在内存中。
     *
     * 如果后续接公司后端：
     * 这里直接替换成 API 查询即可。
     */

    searchKeyword.value = "";
}

/* =========================================================
 * 预览重新加载
 * ========================================================= */

async function reloadPreview() {
    if (!selectedFile.value) {
        return;
    }

    await nextTick();

    await loadPreview(selectedFile.value);
}

/* =========================================================
 * 清理预览
 * ========================================================= */

function cleanupPreview() {
    /*
     * 终止正在进行的解析 / 渲染。
     */
    previewAbortController?.abort();

    previewAbortController = null;

    /* ---------------- PPTX ---------------- */

    if (pptxViewer.value) {
        try {
            pptxViewer.value.destroy();
        } catch (error) {
            console.warn("[FileManager] destroy PPTX error:", error);
        }

        pptxViewer.value = null;
    }

    pptxCurrentSlide.value = 0;

    pptxSlideCount.value = 0;

    pptxZoom.value = 100;

    if (pptxRendererRef.value) {
        pptxRendererRef.value.innerHTML = "";
    }

    /* ---------------- XLSX ---------------- */

    xlsxSheets.value = [];

    xlsxActiveSheet.value = 0;

    /* ---------------- DOCX ---------------- */

    if (docxContainerRef.value) {
        docxContainerRef.value.innerHTML = "";
    }

    /* ---------------- PDF ---------------- */

    if (pdfObjectUrl.value) {
        URL.revokeObjectURL(pdfObjectUrl.value);

        pdfObjectUrl.value = "";
    }

    /* ---------------- IMAGE ---------------- */

    if (imageObjectUrl.value) {
        URL.revokeObjectURL(imageObjectUrl.value);

        imageObjectUrl.value = "";
    }

    /* ---------------- 其它 ---------------- */

    docxObjectUrl.value = "";

    textContent.value = "";

    imageZoom.value = 100;
}

/* =========================================================
 * 格式化
 * ========================================================= */

function formatFileSize(size: number) {
    if (size < 1024) {
        return `${size} B`;
    }

    if (size < 1024 * 1024) {
        return `${(size / 1024).toFixed(1)} KB`;
    }

    if (size < 1024 * 1024 * 1024) {
        return `${(size / 1024 / 1024).toFixed(1)} MB`;
    }

    return `${(size / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function formatTime(timestamp: number) {
    const date = new Date(timestamp);

    const now = new Date();

    const isToday = date.toDateString() === now.toDateString();

    if (isToday) {
        return date.toLocaleTimeString("zh-CN", {
            hour: "2-digit",
            minute: "2-digit",
        });
    }

    return date.toLocaleDateString("zh-CN", {
        month: "2-digit",
        day: "2-digit",
    });
}

/* =========================================================
 * Watch
 * ========================================================= */

watch(
    () => selectedFile.value?.id,
    async () => {
        await nextTick();
    },
);

/* =========================================================
 * 生命周期
 * ========================================================= */

onMounted(() => {
    /*
     * 预留：
     *
     * 如果后续接 IndexedDB / 后端，
     * 可以在这里加载文件列表。
     */
});

onBeforeUnmount(() => {
    cleanupPreview();

    files.value = [];
});
</script>
<style scoped>
/* =========================================================
 * Root
 * ========================================================= */

.file-manager {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    min-width: 0;
    min-height: 0;
    overflow: hidden;
    background: #f5f7fa;
    color: #1f2329;
    font-family:
        -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC",
        "Microsoft YaHei", Arial, sans-serif;
}

/* =========================================================
 * Header
 * ========================================================= */

.file-manager__header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex: 0 0 64px;
    height: 64px;
    min-height: 64px;
    padding: 0 20px;
    background: #ffffff;
    border-bottom: 1px solid #e8ebef;
    z-index: 10;
}

.header-left,
.header-right {
    display: flex;
    align-items: center;
    min-width: 0;
}

.header-right {
    gap: 12px;
}

.header-title {
    display: flex;
    align-items: center;
    gap: 11px;
}

.header-title__icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 38px;
    height: 38px;
    border-radius: 10px;
    background: #f0f6ff;
    font-size: 20px;
}

.header-title__text {
    color: #1f2329;
    font-size: 16px;
    font-weight: 600;
    line-height: 22px;
}

.header-title__sub {
    margin-top: 1px;
    color: #8f959e;
    font-size: 12px;
    line-height: 17px;
}

/* =========================================================
 * Search
 * ========================================================= */

.search-box {
    position: relative;
    display: flex;
    align-items: center;
    width: 230px;
    height: 36px;
    padding: 0 34px 0 36px;
    background: #f5f6f7;
    border: 1px solid transparent;
    border-radius: 8px;
    transition:
        border-color 0.2s ease,
        background 0.2s ease;
}

.search-box:focus-within {
    background: #ffffff;
    border-color: #b8d4ff;
    box-shadow: 0 0 0 3px rgba(22, 119, 255, 0.08);
}

.search-box__icon {
    position: absolute;
    left: 13px;
    top: 50%;
    transform: translateY(-52%);
    color: #8f959e;
    font-size: 21px;
    line-height: 1;
}

.search-box input {
    width: 100%;
    height: 100%;
    padding: 0;
    border: 0;
    outline: 0;
    background: transparent;
    color: #1f2329;
    font-size: 13px;
}

.search-box input::placeholder {
    color: #a9adb3;
}

.search-box__clear {
    position: absolute;
    right: 8px;
    top: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    padding: 0;
    transform: translateY(-50%);
    border: 0;
    border-radius: 50%;
    background: transparent;
    color: #8f959e;
    font-size: 16px;
    line-height: 1;
    cursor: pointer;
}

.search-box__clear:hover {
    background: #e5e6e8;
    color: #4e5969;
}

/* =========================================================
 * Upload Button
 * ========================================================= */

.upload-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    height: 36px;
    padding: 0 15px;
    border: 0;
    border-radius: 8px;
    background: #1677ff;
    color: #ffffff;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(22, 119, 255, 0.16);
    transition:
        background 0.2s ease,
        box-shadow 0.2s ease,
        transform 0.15s ease;
}

.upload-button:hover {
    background: #4096ff;
    box-shadow: 0 4px 10px rgba(22, 119, 255, 0.22);
}

.upload-button:active {
    transform: translateY(1px);
}

.upload-button span:first-child {
    font-size: 18px;
    font-weight: 300;
    line-height: 1;
}

.hidden-input {
    display: none;
}

/* =========================================================
 * Main Body
 * ========================================================= */

.file-manager__body {
    display: flex;
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
    overflow: hidden;
}

/* =========================================================
 * File Panel
 * ========================================================= */

.file-panel {
    position: relative;
    display: flex;
    flex-direction: column;
    flex: 0 0 330px;
    width: 330px;
    min-width: 260px;
    min-height: 0;
    background: #ffffff;
    border-right: 1px solid #e8ebef;
    transition:
        background 0.2s ease,
        border-color 0.2s ease;
}

.file-panel--dragging {
    background: #f0f7ff;
    border-right-color: #91caff;
}

/* =========================================================
 * File Panel Header
 * ========================================================= */

.file-panel__header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex: 0 0 52px;
    height: 52px;
    min-height: 52px;
    padding: 0 14px 0 18px;
    border-bottom: 1px solid #f0f1f3;
}

.file-panel__title {
    display: flex;
    align-items: center;
    gap: 7px;
    color: #1f2329;
    font-size: 13px;
    font-weight: 600;
}

.file-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 20px;
    height: 20px;
    padding: 0 6px;
    border-radius: 10px;
    background: #f2f3f5;
    color: #8f959e;
    font-size: 11px;
    font-weight: 500;
}

.icon-button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    padding: 0;
    border: 0;
    border-radius: 6px;
    background: transparent;
    color: #8f959e;
    font-size: 20px;
    line-height: 1;
    cursor: pointer;
    transition:
        background 0.2s ease,
        color 0.2s ease,
        transform 0.25s ease;
}

.icon-button:hover {
    background: #f2f3f5;
    color: #1f2329;
}

.icon-button:active {
    transform: rotate(180deg);
}

/* =========================================================
 * File List
 * ========================================================= */

.file-list {
    position: relative;
    flex: 1 1 auto;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    padding: 8px;
}

.file-list::-webkit-scrollbar,
.preview-content::-webkit-scrollbar,
.pptx-viewport::-webkit-scrollbar,
.xlsx-content::-webkit-scrollbar,
.image-viewport::-webkit-scrollbar {
    width: 7px;
    height: 7px;
}

.file-list::-webkit-scrollbar-track,
.preview-content::-webkit-scrollbar-track,
.pptx-viewport::-webkit-scrollbar-track,
.xlsx-content::-webkit-scrollbar-track,
.image-viewport::-webkit-scrollbar-track {
    background: transparent;
}

.file-list::-webkit-scrollbar-thumb,
.preview-content::-webkit-scrollbar-thumb,
.pptx-viewport::-webkit-scrollbar-thumb,
.xlsx-content::-webkit-scrollbar-thumb,
.image-viewport::-webkit-scrollbar-thumb {
    border-radius: 8px;
    background: #d9dce1;
}

.file-list::-webkit-scrollbar-thumb:hover,
.preview-content::-webkit-scrollbar-thumb:hover,
.pptx-viewport::-webkit-scrollbar-thumb:hover,
.xlsx-content::-webkit-scrollbar-thumb:hover,
.image-viewport::-webkit-scrollbar-thumb:hover {
    background: #b8bdc5;
}

/* =========================================================
 * File Item
 * ========================================================= */

.file-item {
    position: relative;
    display: flex;
    align-items: center;
    min-height: 66px;
    margin-bottom: 3px;
    padding: 8px 7px;
    border-radius: 9px;
    cursor: pointer;
    user-select: none;
    transition:
        background 0.15s ease,
        box-shadow 0.15s ease;
}

.file-item:hover {
    background: #f5f7fa;
}

.file-item--active {
    background: #eaf3ff;
}

.file-item--active:hover {
    background: #eaf3ff;
}

.file-item__icon {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 40px;
    width: 40px;
    height: 44px;
    margin-right: 10px;
    border-radius: 7px;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: -0.2px;
}

.file-item__icon--pptx {
    background: #fff0ed;
    color: #d4380d;
}

.file-item__icon--xlsx {
    background: #eaf8ee;
    color: #16803c;
}

.file-item__icon--docx {
    background: #edf4ff;
    color: #1668dc;
}

.file-item__icon--pdf {
    background: #fff1f0;
    color: #cf1322;
}

.file-item__icon--image {
    background: #f3efff;
    color: #6941c6;
}

.file-item__icon--text {
    background: #f2f3f5;
    color: #4e5969;
}

.file-item__icon--other {
    background: #f2f3f5;
    color: #8f959e;
}

.file-item__content {
    flex: 1 1 auto;
    min-width: 0;
    padding-right: 4px;
}

.file-item__name {
    overflow: hidden;
    color: #1f2329;
    font-size: 13px;
    font-weight: 500;
    line-height: 19px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.file-item__meta {
    display: flex;
    align-items: center;
    gap: 5px;
    margin-top: 3px;
    color: #a0a5ad;
    font-size: 11px;
    line-height: 16px;
}

.file-item__actions {
    display: flex;
    align-items: center;
    gap: 1px;
    flex: 0 0 auto;
    opacity: 0;
    transform: translateX(3px);
    transition:
        opacity 0.15s ease,
        transform 0.15s ease;
}

.file-item:hover .file-item__actions,
.file-item--active .file-item__actions {
    opacity: 1;
    transform: translateX(0);
}

.file-action {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 27px;
    height: 27px;
    padding: 0;
    border: 0;
    border-radius: 5px;
    background: transparent;
    color: #8f959e;
    font-size: 14px;
    cursor: pointer;
}

.file-action:hover {
    background: #ffffff;
    color: #1677ff;
}

.file-action--danger:hover {
    background: #fff1f0;
    color: #f5222d;
}

/* =========================================================
 * Empty
 * ========================================================= */

.file-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    min-height: 260px;
    padding: 30px 20px;
    text-align: center;
}

.file-empty__icon {
    margin-bottom: 14px;
    font-size: 40px;
    line-height: 1;
    opacity: 0.75;
}

.file-empty__title {
    color: #4e5969;
    font-size: 13px;
    font-weight: 500;
}

.file-empty__sub {
    margin-top: 6px;
    color: #a0a5ad;
    font-size: 11px;
}

.empty-upload-button {
    margin-top: 18px;
    padding: 7px 16px;
    border: 1px solid #d9e8ff;
    border-radius: 6px;
    background: #f0f6ff;
    color: #1677ff;
    font-size: 12px;
    cursor: pointer;
}

.empty-upload-button:hover {
    background: #e6f1ff;
}

/* =========================================================
 * Drop Overlay
 * ========================================================= */

.drop-overlay {
    position: absolute;
    z-index: 20;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(240, 247, 255, 0.94);
    border: 2px dashed #1677ff;
    pointer-events: none;
}

.drop-overlay__content {
    text-align: center;
}

.drop-overlay__icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 58px;
    height: 58px;
    margin: 0 auto 15px;
    border-radius: 50%;
    background: #e6f4ff;
    color: #1677ff;
    font-size: 27px;
}

.drop-overlay__title {
    color: #1677ff;
    font-size: 15px;
    font-weight: 600;
}

.drop-overlay__sub {
    margin-top: 7px;
    color: #6b7785;
    font-size: 12px;
}

/* =========================================================
 * Preview Panel
 * ========================================================= */

.preview-panel {
    position: relative;
    display: flex;
    flex-direction: column;
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
    overflow: hidden;
    background: #f5f6f8;
}

/* =========================================================
 * Preview Header
 * ========================================================= */

.preview-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex: 0 0 60px;
    height: 60px;
    min-height: 60px;
    padding: 0 18px;
    background: #ffffff;
    border-bottom: 1px solid #e8ebef;
}

.preview-header__file {
    display: flex;
    align-items: center;
    min-width: 0;
}

.preview-header__icon {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 36px;
    width: 36px;
    height: 40px;
    margin-right: 10px;
    border-radius: 6px;
    font-size: 8px;
    font-weight: 700;
}

.preview-header__info {
    min-width: 0;
}

.preview-header__name {
    max-width: 500px;
    overflow: hidden;
    color: #1f2329;
    font-size: 14px;
    font-weight: 600;
    line-height: 20px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.preview-header__meta {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 2px;
    color: #8f959e;
    font-size: 11px;
    line-height: 16px;
}

.preview-header__actions {
    display: flex;
    align-items: center;
    gap: 6px;
}

.preview-tool-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    height: 32px;
    padding: 0 10px;
    border: 1px solid #e5e6e8;
    border-radius: 6px;
    background: #ffffff;
    color: #4e5969;
    font-size: 12px;
    cursor: pointer;
    transition:
        border-color 0.15s ease,
        background 0.15s ease,
        color 0.15s ease;
}

.preview-tool-button:hover {
    border-color: #b8d4ff;
    background: #f5f9ff;
    color: #1677ff;
}

.preview-tool-button--danger:hover {
    border-color: #ffccc7;
    background: #fff1f0;
    color: #f5222d;
}

/* =========================================================
 * Preview Content
 * ========================================================= */

.preview-content {
    position: relative;
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
    overflow: hidden;
}

/* =========================================================
 * Preview Empty
 * ========================================================= */

.preview-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    min-height: 400px;
    padding: 40px;
    text-align: center;
}

.preview-empty__illustration {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 110px;
    height: 110px;
    margin-bottom: 22px;
    border-radius: 28px;
    background: #ffffff;
    box-shadow: 0 8px 30px rgba(31, 35, 41, 0.06);
}

.preview-empty__folder {
    font-size: 54px;
    line-height: 1;
}

.preview-empty__title {
    color: #4e5969;
    font-size: 15px;
    font-weight: 500;
}

.preview-empty__sub {
    margin-top: 8px;
    color: #a0a5ad;
    font-size: 12px;
}

.preview-empty__button {
    margin-top: 20px;
    height: 34px;
    padding: 0 17px;
    border: 0;
    border-radius: 7px;
    background: #1677ff;
    color: #ffffff;
    font-size: 12px;
    cursor: pointer;
}

.preview-empty__button:hover {
    background: #4096ff;
}

/* =========================================================
 * Loading
 * ========================================================= */

.preview-loading {
    position: absolute;
    z-index: 100;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: rgba(245, 246, 248, 0.82);
    backdrop-filter: blur(2px);
}

.loading-spinner,
.upload-spinner {
    width: 28px;
    height: 28px;
    border: 3px solid #d9e8ff;
    border-top-color: #1677ff;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}

.preview-loading__text {
    margin-top: 14px;
    color: #4e5969;
    font-size: 13px;
    font-weight: 500;
}

.preview-loading__sub {
    max-width: 400px;
    margin-top: 5px;
    overflow: hidden;
    color: #a0a5ad;
    font-size: 11px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

@keyframes spin {
    to {
        transform: rotate(360deg);
    }
}

/* =========================================================
 * Error
 * ========================================================= */

.preview-error {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    min-height: 400px;
    padding: 40px;
    text-align: center;
}

.preview-error__icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 48px;
    height: 48px;
    margin-bottom: 16px;
    border-radius: 50%;
    background: #fff1f0;
    color: #f5222d;
    font-size: 23px;
    font-weight: 700;
}

.preview-error__title {
    color: #4e5969;
    font-size: 14px;
    font-weight: 600;
}

.preview-error__message {
    max-width: 500px;
    margin-top: 8px;
    color: #8f959e;
    font-size: 12px;
    line-height: 19px;
    word-break: break-word;
}

.preview-error__actions {
    display: flex;
    gap: 8px;
    margin-top: 20px;
}

.preview-error__button {
    height: 34px;
    padding: 0 15px;
    border: 0;
    border-radius: 6px;
    background: #1677ff;
    color: #ffffff;
    font-size: 12px;
    cursor: pointer;
}

.preview-error__button:hover {
    background: #4096ff;
}

.preview-error__button--secondary {
    background: #ffffff;
    border: 1px solid #d9dce1;
    color: #4e5969;
}

.preview-error__button--secondary:hover {
    background: #f5f6f7;
    color: #1f2329;
}

/* =========================================================
 * PPTX Preview
 * ========================================================= */

.office-preview--pptx {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    min-height: 0;
    background: #e9edf2;
}

.pptx-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex: 0 0 46px;
    height: 46px;
    min-height: 46px;
    padding: 0 12px;
    background: #ffffff;
    border-bottom: 1px solid #e3e6ea;
    box-shadow: 0 1px 3px rgba(31, 35, 41, 0.03);
    z-index: 5;
}

.pptx-toolbar__left,
.pptx-toolbar__right,
.pptx-toolbar__center {
    display: flex;
    align-items: center;
}

.pptx-toolbar__left {
    min-width: 150px;
}

.pptx-toolbar__right {
    justify-content: flex-end;
    gap: 3px;
    min-width: 150px;
}

.pptx-toolbar__center {
    gap: 7px;
}

.pptx-toolbar__label {
    color: #8f959e;
    font-size: 12px;
}

.pptx-control {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    padding: 0;
    border: 0;
    border-radius: 6px;
    background: transparent;
    color: #4e5969;
    font-size: 18px;
    line-height: 1;
    cursor: pointer;
}

.pptx-control:hover:not(:disabled) {
    background: #f2f3f5;
    color: #1677ff;
}

.pptx-control:disabled {
    color: #c9cdd4;
    cursor: not-allowed;
}

.pptx-control--fullscreen {
    margin-left: 4px;
}

.pptx-page {
    min-width: 58px;
    text-align: center;
    color: #4e5969;
    font-size: 12px;
    font-variant-numeric: tabular-nums;
}

.pptx-zoom {
    min-width: 48px;
    height: 30px;
    padding: 0 5px;
    border: 0;
    border-radius: 5px;
    background: transparent;
    color: #4e5969;
    font-size: 11px;
    cursor: pointer;
}

.pptx-zoom:hover {
    background: #f2f3f5;
}

.pptx-viewport {
    position: relative;
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
    overflow: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 28px;
    background:
        linear-gradient(45deg, #e4e8ed 25%, transparent 25%),
        linear-gradient(-45deg, #e4e8ed 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #e4e8ed 75%),
        linear-gradient(-45deg, transparent 75%, #e4e8ed 75%);
    background-position:
        0 0,
        0 7px,
        7px -7px,
        -7px 0;
    background-size: 14px 14px;
    background-color: #edf0f3;
}

.pptx-renderer {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 0;
    min-height: 0;
}

/*
 * pptx-renderer 生成的内容
 *
 * 不直接限制内部 canvas / svg 的尺寸，
 * 防止库内部计算尺寸失效。
 */

.pptx-renderer :deep(canvas),
.pptx-renderer :deep(svg) {
    display: block;
    max-width: none;
}

.pptx-renderer :deep(*) {
    box-sizing: border-box;
}

/* =========================================================
 * XLSX Preview
 * ========================================================= */

.office-preview--xlsx {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    min-height: 0;
    background: #ffffff;
}

.xlsx-toolbar {
    display: flex;
    align-items: center;
    flex: 0 0 48px;
    height: 48px;
    min-height: 48px;
    padding: 0 14px;
    background: #ffffff;
    border-bottom: 1px solid #e5e6e8;
}

.xlsx-sheet-info {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
    gap: 7px;
    margin-right: 15px;
    color: #8f959e;
    font-size: 11px;
}

.xlsx-sheet-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 27px;
    height: 27px;
    border-radius: 5px;
    background: #eaf8ee;
    color: #16803c;
    font-size: 8px;
    font-weight: 700;
}

.xlsx-sheet-tabs {
    display: flex;
    align-items: center;
    gap: 2px;
    min-width: 0;
    height: 100%;
    overflow-x: auto;
}

.xlsx-sheet-tabs::-webkit-scrollbar {
    height: 3px;
}

.xlsx-sheet-tab {
    height: 30px;
    padding: 0 12px;
    border: 0;
    border-radius: 5px;
    background: transparent;
    color: #6b7280;
    font-size: 11px;
    white-space: nowrap;
    cursor: pointer;
}

.xlsx-sheet-tab:hover {
    background: #f5f6f7;
    color: #1f2329;
}

.xlsx-sheet-tab--active {
    background: #eaf8ee;
    color: #16803c;
    font-weight: 500;
}

.xlsx-content {
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
    overflow: auto;
    background: #ffffff;
}

.xlsx-table-wrapper {
    min-width: max-content;
}

.xlsx-table {
    width: max-content;
    min-width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    table-layout: fixed;
    color: #1f2329;
    font-size: 12px;
}

.xlsx-table tr {
    height: 28px;
}

.xlsx-row-number {
    position: sticky;
    left: 0;
    z-index: 2;
    width: 46px;
    min-width: 46px;
    padding: 0 8px;
    background: #f7f8fa;
    border-right: 1px solid #dfe2e6;
    border-bottom: 1px solid #dfe2e6;
    color: #8f959e;
    font-size: 10px;
    font-weight: 400;
    text-align: center;
}

.xlsx-cell {
    min-width: 110px;
    max-width: 320px;
    padding: 5px 8px;
    overflow: hidden;
    border-right: 1px solid #e5e6e8;
    border-bottom: 1px solid #e5e6e8;
    background: #ffffff;
    line-height: 18px;
    text-align: left;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.xlsx-cell:hover {
    background: #f7fbff;
}

/* =========================================================
 * DOCX
 * ========================================================= */

.office-preview--docx {
    width: 100%;
    height: 100%;
    min-height: 0;
    overflow: auto;
    padding: 30px;
    background: #e9edf2;
}

.docx-renderer {
    width: 100%;
    min-height: 100%;
}

/*
 * docx-preview 内部 DOM 使用非 scoped class，
 * 所以通过 :deep() 进入。
 */

.docx-renderer :deep(.docx-wrapper) {
    min-height: 100%;
    padding: 20px 0 50px;
    background: transparent;
}

.docx-renderer :deep(.docx) {
    margin: 0 auto 20px;
    background: #ffffff;
    box-shadow: 0 2px 12px rgba(31, 35, 41, 0.08);
}

/* =========================================================
 * PDF
 * ========================================================= */

.office-preview--pdf {
    position: relative;
    width: 100%;
    height: 100%;
    min-height: 0;
    background: #e9edf2;
}

.pdf-frame {
    display: block;
    width: 100%;
    height: 100%;
    border: 0;
    background: #ffffff;
}

/* =========================================================
 * Image
 * ========================================================= */

.office-preview--image {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    min-height: 0;
    background: #e9edf2;
}

.image-preview-toolbar {
    position: absolute;
    z-index: 10;
    top: 14px;
    right: 14px;
    display: flex;
    align-items: center;
    gap: 2px;
    padding: 4px;
    border: 1px solid rgba(255, 255, 255, 0.65);
    border-radius: 7px;
    background: rgba(255, 255, 255, 0.92);
    box-shadow: 0 3px 12px rgba(31, 35, 41, 0.12);
    backdrop-filter: blur(8px);
}

.preview-control {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 28px;
    padding: 0;
    border: 0;
    border-radius: 5px;
    background: transparent;
    color: #4e5969;
    font-size: 16px;
    cursor: pointer;
}

.preview-control:hover {
    background: #f2f3f5;
    color: #1677ff;
}

.preview-zoom {
    min-width: 52px;
    height: 28px;
    padding: 0 5px;
    border: 0;
    border-radius: 5px;
    background: transparent;
    color: #4e5969;
    font-size: 11px;
    cursor: pointer;
}

.preview-zoom:hover {
    background: #f2f3f5;
}

.image-viewport {
    position: relative;
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
    overflow: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px;
}

.image-preview {
    display: block;
    width: auto;
    height: auto;
    max-width: none;
    max-height: none;
    transform-origin: center center;
    user-select: none;
    transition: transform 0.15s ease;
}

/* =========================================================
 * Text
 * ========================================================= */

.office-preview--text {
    width: 100%;
    height: 100%;
    min-height: 0;
    overflow: auto;
    padding: 25px;
    background: #ffffff;
}

.text-preview {
    box-sizing: border-box;
    min-height: 100%;
    margin: 0;
    padding: 22px 26px;
    border: 1px solid #e5e6e8;
    border-radius: 8px;
    background: #fafbfc;
    color: #1f2329;
    font-family:
        "Cascadia Code", "SFMono-Regular", Consolas, "Liberation Mono",
        monospace;
    font-size: 12px;
    line-height: 1.7;
    white-space: pre-wrap;
    word-break: break-word;
}

/* =========================================================
 * Unsupported
 * ========================================================= */

.format-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    min-height: 350px;
    padding: 40px;
    text-align: center;
}

.format-empty__icon {
    margin-bottom: 15px;
    font-size: 45px;
    opacity: 0.7;
}

.format-empty__title {
    color: #4e5969;
    font-size: 14px;
    font-weight: 500;
}

.format-empty__sub {
    margin-top: 7px;
    color: #a0a5ad;
    font-size: 12px;
}

/* =========================================================
 * Upload Status
 * ========================================================= */

.upload-status {
    position: absolute;
    z-index: 200;
    right: 22px;
    bottom: 22px;
    display: flex;
    align-items: center;
    width: 310px;
    min-height: 68px;
    padding: 12px 14px;
    border: 1px solid #e5e6e8;
    border-radius: 10px;
    background: #ffffff;
    box-shadow: 0 8px 30px rgba(31, 35, 41, 0.14);
}

.upload-status__icon {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 38px;
    width: 38px;
    height: 38px;
    margin-right: 11px;
    border-radius: 8px;
    background: #eaf3ff;
    color: #1677ff;
    font-size: 20px;
}

.upload-status__content {
    flex: 1 1 auto;
    min-width: 0;
}

.upload-status__title {
    color: #1f2329;
    font-size: 12px;
    font-weight: 500;
}

.upload-status__sub {
    margin-top: 3px;
    overflow: hidden;
    color: #8f959e;
    font-size: 10px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.upload-spinner {
    width: 19px;
    height: 19px;
    border-width: 2px;
}

/* =========================================================
 * Delete Dialog
 * ========================================================= */

.modal-mask {
    position: fixed;
    z-index: 1000;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(31, 35, 41, 0.38);
    backdrop-filter: blur(2px);
}

.delete-dialog {
    width: 380px;
    max-width: calc(100vw - 40px);
    padding: 28px;
    border-radius: 12px;
    background: #ffffff;
    box-shadow: 0 16px 50px rgba(31, 35, 41, 0.2);
    text-align: center;
}

.delete-dialog__icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 48px;
    height: 48px;
    margin: 0 auto 15px;
    border-radius: 50%;
    background: #fff1f0;
    font-size: 21px;
}

.delete-dialog__title {
    color: #1f2329;
    font-size: 16px;
    font-weight: 600;
}

.delete-dialog__message {
    margin-top: 10px;
    color: #8f959e;
    font-size: 12px;
    line-height: 21px;
}

.delete-dialog__message strong {
    color: #4e5969;
    font-weight: 500;
}

.delete-dialog__actions {
    display: flex;
    justify-content: center;
    gap: 9px;
    margin-top: 23px;
}

.dialog-button {
    min-width: 82px;
    height: 34px;
    padding: 0 15px;
    border-radius: 6px;
    font-size: 12px;
    cursor: pointer;
}

.dialog-button--secondary {
    border: 1px solid #d9dce1;
    background: #ffffff;
    color: #4e5969;
}

.dialog-button--secondary:hover {
    background: #f5f6f7;
}

.dialog-button--danger {
    border: 1px solid #f5222d;
    background: #f5222d;
    color: #ffffff;
}

.dialog-button--danger:hover {
    background: #ff4d4f;
}

/* =========================================================
 * Transitions
 * ========================================================= */

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.18s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}

.slide-up-enter-active,
.slide-up-leave-active {
    transition:
        opacity 0.2s ease,
        transform 0.2s ease;
}

.slide-up-enter-from,
.slide-up-leave-to {
    opacity: 0;
    transform: translateY(12px);
}

/* =========================================================
 * Fullscreen
 * ========================================================= */

.file-manager:fullscreen {
    width: 100vw;
    height: 100vh;
    background: #f5f7fa;
}

.file-manager:fullscreen .preview-content {
    min-height: 0;
}

/* =========================================================
 * Responsive
 * ========================================================= */

@media (max-width: 1000px) {
    .file-panel {
        flex-basis: 280px;
        width: 280px;
    }

    .search-box {
        width: 180px;
    }

    .preview-header__name {
        max-width: 300px;
    }
}

@media (max-width: 760px) {
    .file-manager__header {
        padding: 0 12px;
    }

    .header-title__sub {
        display: none;
    }

    .header-title__icon {
        width: 34px;
        height: 34px;
    }

    .search-box {
        width: 150px;
    }

    .upload-button span:last-child {
        display: none;
    }

    .upload-button {
        width: 36px;
        padding: 0;
    }

    .file-panel {
        flex-basis: 220px;
        width: 220px;
        min-width: 220px;
    }

    .preview-header {
        padding: 0 10px;
    }

    .preview-tool-button span:last-child {
        display: none;
    }

    .preview-tool-button {
        width: 32px;
        padding: 0;
    }

    .pptx-toolbar__left {
        display: none;
    }

    .pptx-toolbar__right {
        min-width: auto;
    }

    .pptx-toolbar__center {
        margin-left: auto;
        margin-right: auto;
    }

    .pptx-viewport {
        padding: 15px;
    }
}

@media (max-width: 560px) {
    .file-manager__body {
        position: relative;
    }

    .file-panel {
        flex-basis: 190px;
        width: 190px;
        min-width: 190px;
    }

    .file-item {
        padding-left: 5px;
        padding-right: 5px;
    }

    .file-item__icon {
        flex-basis: 34px;
        width: 34px;
        height: 38px;
        margin-right: 7px;
    }

    .file-item__actions {
        display: none;
    }

    .preview-header__meta {
        display: none;
    }

    .preview-empty {
        padding: 20px;
    }

    .office-preview--docx {
        padding: 15px;
    }

    .image-viewport {
        padding: 20px;
    }
}
</style>
