<template>
    <div class="tiptap-wrapper">
        <!-- ==================== Toolbar ==================== -->
        <div class="editor-toolbar">
            <!-- 字体 -->
            <div class="toolbar-group">
                <select
                    v-model="currentFontFamily"
                    class="toolbar-select font-select"
                    title="字体"
                    @change="setFontFamily"
                >
                    <option value="">默认字体</option>
                    <option
                        v-for="font in fontFamilies"
                        :key="font.value"
                        :value="font.value"
                    >
                        {{ font.label }}
                    </option>
                </select>
                <!-- 字号 -->
                <select
                    v-model="currentFontSize"
                    class="toolbar-select size-select"
                    title="字号"
                    @change="setFontSize"
                >
                    <option v-for="size in fontSizes" :key="size" :value="size">
                        {{ size }}
                    </option>
                </select>
                <button
                    class="toolbar-btn text-size-btn"
                    title="增大字号"
                    @click="increaseFontSize"
                >
                    A<sup>+</sup>
                </button>
                <button
                    class="toolbar-btn text-size-btn"
                    title="减小字号"
                    @click="decreaseFontSize"
                >
                    A<sup>−</sup>
                </button>
            </div>
            <div class="toolbar-divider"></div>
            <!-- 段落 / 标题 -->
            <div class="toolbar-group">
                <select
                    v-model="currentBlock"
                    class="toolbar-select style-select"
                    title="段落样式"
                    @change="setBlockType"
                >
                    <option value="paragraph">正文</option>
                    <option value="heading1">标题 1</option>
                    <option value="heading2">标题 2</option>
                    <option value="heading3">标题 3</option>
                </select>
            </div>
            <div class="toolbar-divider"></div>
            <!-- 基础文字 -->
            <div class="toolbar-group">
                <button
                    class="toolbar-btn bold-btn"
                    :class="{ active: editor?.isActive('bold') }"
                    title="加粗"
                    @click="toggleBold"
                >
                    B
                </button>
                <button
                    class="toolbar-btn italic-btn"
                    :class="{ active: editor?.isActive('italic') }"
                    title="斜体"
                    @click="toggleItalic"
                >
                    I
                </button>
                <button
                    class="toolbar-btn underline-btn"
                    :class="{ active: editor?.isActive('underline') }"
                    title="下划线"
                    @click="toggleUnderline"
                >
                    U
                </button>
                <button
                    class="toolbar-btn strike-btn"
                    :class="{ active: editor?.isActive('strike') }"
                    title="删除线"
                    @click="toggleStrike"
                >
                    S
                </button>
            </div>
            <div class="toolbar-divider"></div>
            <!-- 颜色 -->
            <div class="toolbar-group">
                <div class="color-control" title="文字颜色">
                    <button
                        class="toolbar-btn color-btn"
                        :class="{ active: currentColor }"
                        @click="applyTextColor"
                    >
                        <span>A</span>
                        <i
                            class="color-line"
                            :style="{ backgroundColor: currentColor || '#333' }"
                        ></i>
                    </button>
                    <input
                        v-model="textColor"
                        class="native-color"
                        type="color"
                        @input="applyTextColor"
                    />
                </div>
                <div class="color-control" title="高亮颜色">
                    <button
                        class="toolbar-btn highlight-btn"
                        @click="applyHighlight"
                    >
                        <span class="highlight-a">A</span>
                        <i
                            class="highlight-line"
                            :style="{
                                backgroundColor: highlightColor || '#fff2a8',
                            }"
                        ></i>
                    </button>
                    <input
                        v-model="highlightColor"
                        class="native-color"
                        type="color"
                        @input="applyHighlight"
                    />
                </div>
                <button
                    class="toolbar-btn"
                    title="清除格式"
                    @click="clearFormatting"
                >
                    ✦
                </button>
            </div>
            <div class="toolbar-divider"></div>
            <!-- 对齐 -->
            <div class="toolbar-group">
                <button
                    class="toolbar-btn"
                    :class="{
                        active: editor?.isActive({
                            textAlign: 'left',
                        }),
                    }"
                    title="左对齐"
                    @click="setTextAlign('left')"
                >
                    ≡
                </button>
                <button
                    class="toolbar-btn center-align"
                    :class="{
                        active: editor?.isActive({
                            textAlign: 'center',
                        }),
                    }"
                    title="居中"
                    @click="setTextAlign('center')"
                >
                    ≡
                </button>
                <button
                    class="toolbar-btn right-align"
                    :class="{
                        active: editor?.isActive({
                            textAlign: 'right',
                        }),
                    }"
                    title="右对齐"
                    @click="setTextAlign('right')"
                >
                    ≡
                </button>
                <button
                    class="toolbar-btn"
                    :class="{
                        active: editor?.isActive({
                            textAlign: 'justify',
                        }),
                    }"
                    title="两端对齐"
                    @click="setTextAlign('justify')"
                >
                    ≣
                </button>
            </div>
            <div class="toolbar-divider"></div>
            <!-- 列表 -->
            <div class="toolbar-group">
                <button
                    class="toolbar-btn list-btn"
                    :class="{
                        active: editor?.isActive('bulletList'),
                    }"
                    title="项目符号"
                    @click="toggleBulletList"
                >
                    •≡
                </button>
                <button
                    class="toolbar-btn list-btn"
                    :class="{
                        active: editor?.isActive('orderedList'),
                    }"
                    title="编号列表"
                    @click="toggleOrderedList"
                >
                    1≡
                </button>
                <button
                    class="toolbar-btn"
                    :class="{
                        active: editor?.isActive('taskList'),
                    }"
                    title="任务列表"
                    @click="toggleTaskList"
                >
                    ☑
                </button>
            </div>
            <div class="toolbar-divider"></div>
            <!-- 插入 -->
            <div class="toolbar-group">
                <button
                    class="toolbar-btn"
                    title="链接"
                    :class="{ active: editor?.isActive('link') }"
                    @click="setLink"
                >
                    ↗
                </button>
                <button
                    class="toolbar-btn"
                    title="插入图片"
                    @click="insertImage"
                >
                    ▧
                </button>
                <button
                    class="toolbar-btn"
                    title="插入表格"
                    @click="insertTable"
                >
                    ▦
                </button>
            </div>
            <div class="toolbar-divider"></div>
            <!-- 历史 -->
            <div class="toolbar-group history-group">
                <button
                    class="toolbar-btn"
                    title="撤销"
                    :disabled="!editor?.can().undo()"
                    @click="undo"
                >
                    ↶
                </button>
                <button
                    class="toolbar-btn"
                    title="重做"
                    :disabled="!editor?.can().redo()"
                    @click="redo"
                >
                    ↷
                </button>
            </div>
        </div>
        <!-- ==================== Editor ==================== -->
        <div class="editor-container">
            <EditorContent
                v-if="editor"
                :editor="editor"
                class="tiptap-content"
            />
        </div>
        <!-- ==================== Status Bar ==================== -->
        <div class="editor-status">
            <div class="status-left">
                <span v-if="editor"> {{ characterCount }} 字 </span>
            </div>
            <div class="status-right">
                <span v-if="editor?.isActive('bulletList')"> 项目列表 </span>
                <span v-else-if="editor?.isActive('orderedList')">
                    编号列表
                </span>
                <span v-else> 编辑中 </span>
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import { computed, onBeforeUnmount, ref, watch } from "vue";
import { EditorContent, useEditor } from "@tiptap/vue-3";
import { FullFeaturedTiptapExtensions } from "./extensions";
interface Props {
    modelValue?: string;
    placeholder?: string;
    editable?: boolean;
}
const props = withDefaults(defineProps<Props>(), {
    modelValue: "",
    editable: true,
    placeholder: "请输入正文内容...",
});
const emit = defineEmits<{
    "update:modelValue": [value: string];
    change: [value: string];
}>(); /**
 * ================================
 * 字体
 * ================================
 */
const fontFamilies = [
    {
        label: "微软雅黑",
        value: "Microsoft YaHei",
    },
    {
        label: "宋体",
        value: "SimSun",
    },
    {
        label: "黑体",
        value: "SimHei",
    },
    {
        label: "楷体",
        value: "KaiTi",
    },
    {
        label: "Arial",
        value: "Arial",
    },
    {
        label: "Times New Roman",
        value: "Times New Roman",
    },
    {
        label: "Georgia",
        value: "Georgia",
    },
];
const fontSizes = [
    "10px",
    "11px",
    "12px",
    "14px",
    "16px",
    "18px",
    "20px",
    "22px",
    "24px",
    "26px",
    "28px",
    "32px",
    "36px",
    "40px",
    "48px",
]; /**
 * ================================
 * 状态
 * ================================
 */
const currentFontFamily = ref("");
const currentFontSize = ref("16px");
const currentBlock = ref("paragraph");
const textColor = ref("#333333");
const highlightColor = ref("#fff2a8");
const editor = useEditor({
    extensions: FullFeaturedTiptapExtensions,
    content: props.modelValue,
    editable: props.editable,
    onUpdate({ editor }) {
        const html = editor.getHTML();
        emit("update:modelValue", html);
        emit("change", html);
    },
    onSelectionUpdate({ editor }) {
        updateToolbarState(editor);
    },
}); /**
 * ================================
 * 当前文字颜色
 * ================================
 */
const currentColor = computed(() => {
    if (!editor.value) {
        return "";
    }
    return editor.value.getAttributes("textStyle").color || "";
}); /**
 * ================================
 * 字数
 * ================================
 */
const characterCount = computed(() => {
    if (!editor.value) {
        return 0;
    }
    return editor.value.state.doc.textContent.length;
}); /**
 * ================================
 * 同步外部 v-model
 * ================================
 */
watch(
    () => props.modelValue,
    (value) => {
        if (!editor.value) {
            return;
        }
        if (value !== editor.value.getHTML()) {
            editor.value.commands.setContent(value || "", {
                emitUpdate: false,
            });
        }
    },
);
watch(
    () => props.editable,
    (value) => {
        editor.value?.setEditable(value);
    },
); /**
 * ================================
 * Toolbar 状态
 * ================================
 */
function updateToolbarState(currentEditor: any) {
    const fontFamily = currentEditor.getAttributes("textStyle").fontFamily;
    const fontSize = currentEditor.getAttributes("textStyle").fontSize;
    currentFontFamily.value = fontFamily || "";
    currentFontSize.value = fontSize || "16px";
    if (currentEditor.isActive("heading", { level: 1 })) {
        currentBlock.value = "heading1";
    } else if (currentEditor.isActive("heading", { level: 2 })) {
        currentBlock.value = "heading2";
    } else if (currentEditor.isActive("heading", { level: 3 })) {
        currentBlock.value = "heading3";
    } else {
        currentBlock.value = "paragraph";
    }
} /**
 * ================================
 * 字体
 * ================================
 */
function setFontFamily() {
    if (!editor.value) return;
    if (!currentFontFamily.value) {
        editor.value.chain().focus().unsetFontFamily().run();
        return;
    }
    editor.value.chain().focus().setFontFamily(currentFontFamily.value).run();
} /**
 * ================================
 * 字号
 * ================================
 */
function setFontSize() {
    if (!editor.value) return;
    editor.value.chain().focus().setFontSize(currentFontSize.value).run();
}
function increaseFontSize() {
    const current = parseInt(currentFontSize.value, 10);
    const next =
        fontSizes.find((size) => parseInt(size, 10) > current) || "48px";
    currentFontSize.value = next;
    editor.value?.chain().focus().setFontSize(next).run();
}
function decreaseFontSize() {
    const current = parseInt(currentFontSize.value, 10);
    const previous =
        [...fontSizes].reverse().find((size) => parseInt(size, 10) < current) ||
        "10px";
    currentFontSize.value = previous;
    editor.value?.chain().focus().setFontSize(previous).run();
} /**
 * ================================
 * 标题
 * ================================
 */
function setBlockType() {
    if (!editor.value) return;
    const chain = editor.value.chain().focus();
    switch (currentBlock.value) {
        case "heading1":
            chain.toggleHeading({ level: 1 }).run();
            break;
        case "heading2":
            chain.toggleHeading({ level: 2 }).run();
            break;
        case "heading3":
            chain.toggleHeading({ level: 3 }).run();
            break;
        default:
            chain.setParagraph().run();
            break;
    }
} /**
 * ================================
 * 基础文字
 * ================================
 */
function toggleBold() {
    editor.value?.chain().focus().toggleBold().run();
}
function toggleItalic() {
    editor.value?.chain().focus().toggleItalic().run();
}
function toggleUnderline() {
    editor.value?.chain().focus().toggleUnderline().run();
}
function toggleStrike() {
    editor.value?.chain().focus().toggleStrike().run();
} /**
 * ================================
 * 颜色
 * ================================
 */
function applyTextColor() {
    editor.value?.chain().focus().setColor(textColor.value).run();
}
function applyHighlight() {
    editor.value
        ?.chain()
        .focus()
        .toggleHighlight({
            color: highlightColor.value,
        })
        .run();
} /**
 * ================================
 * 清除格式
 * ================================
 */
function clearFormatting() {
    editor.value?.chain().focus().clearNodes().unsetAllMarks().run();
} /**
 * ================================
 * 对齐
 * ================================
 */
function setTextAlign(align: "left" | "center" | "right" | "justify") {
    editor.value?.chain().focus().setTextAlign(align).run();
} /**
 * ================================
 * 列表
 * ================================
 */
function toggleBulletList() {
    editor.value?.chain().focus().toggleBulletList().run();
}
function toggleOrderedList() {
    editor.value?.chain().focus().toggleOrderedList().run();
}
function toggleTaskList() {
    editor.value?.chain().focus().toggleTaskList().run();
} /**
 * ================================
 * 链接
 * ================================
 */
function setLink() {
    if (!editor.value) return;
    const previousUrl = editor.value.getAttributes("link").href || "";
    const url = window.prompt("请输入链接地址", previousUrl);
    if (url === null) {
        return;
    }
    if (url === "") {
        editor.value.chain().focus().unsetLink().run();
        return;
    }
    editor.value
        .chain()
        .focus()
        .extendMarkRange("link")
        .setLink({
            href: url,
        })
        .run();
} /**
 * ================================
 * 图片
 * ================================
 */
function insertImage() {
    if (!editor.value) return;
    const url = window.prompt("请输入图片地址");
    if (!url) {
        return;
    }
    editor.value
        .chain()
        .focus()
        .setImage({
            src: url,
            alt: "图片",
        })
        .run();
} /**
 * ================================
 * 表格
 * ================================
 */
function insertTable() {
    if (!editor.value) return;
    const rows = Number(window.prompt("请输入行数", "3"));
    const cols = Number(window.prompt("请输入列数", "3"));
    if (!rows || !cols || rows < 1 || cols < 1) {
        return;
    }
    editor.value
        .chain()
        .focus()
        .insertTable({
            rows,
            cols,
            withHeaderRow: true,
        })
        .run();
} /**
 * ================================
 * 历史
 * ================================
 */
function undo() {
    editor.value?.chain().focus().undo().run();
}
function redo() {
    editor.value?.chain().focus().redo().run();
}
onBeforeUnmount(() => {
    editor.value?.destroy();
});
</script>
<style scoped>
/* =========================================================
   Root
   ========================================================= */
.tiptap-wrapper {
    width: 100%;
    height: 100%;
    min-height: 600px;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: #f7f7f5;
    border: 1px solid #e8e6e1;
    border-radius: 10px;
    box-shadow:
        0 1px 2px rgba(0, 0, 0, 0.02),
        0 8px 30px rgba(0, 0, 0, 0.04);
} /* =========================================================
   Toolbar
   ========================================================= */
.editor-toolbar {
    flex-shrink: 0;
    min-height: 48px;
    padding: 6px 10px;
    display: flex;
    align-items: center;
    gap: 3px;
    background: rgba(255, 255, 255, 0.96);
    border-bottom: 1px solid #ebe9e4;
    user-select: none;
}
.toolbar-group {
    display: flex;
    align-items: center;
    gap: 2px;
}
.toolbar-divider {
    width: 1px;
    height: 24px;
    margin: 0 5px;
    background: #e9e7e2;
}
.toolbar-btn {
    position: relative;
    width: 32px;
    height: 32px;
    padding: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: 5px;
    background: transparent;
    color: #45433f;
    font-size: 15px;
    cursor: pointer;
    transition:
        background 0.15s ease,
        color 0.15s ease;
}
.toolbar-btn:hover {
    background: #f3f1ed;
}
.toolbar-btn.active {
    background: #ece9e3;
    color: #1f1e1b;
}
.toolbar-btn:disabled {
    opacity: 0.35;
    cursor: not-allowed;
}
.toolbar-select {
    height: 32px;
    padding: 0 26px 0 8px;
    border: 1px solid transparent;
    border-radius: 5px;
    background-color: transparent;
    color: #3f3d39;
    outline: none;
    cursor: pointer;
    font-family: inherit;
    font-size: 13px;
    transition:
        background 0.15s ease,
        border-color 0.15s ease;
}
.toolbar-select:hover,
.toolbar-select:focus {
    background: #f6f4f0;
    border-color: #e7e3dc;
}
.font-select {
    width: 108px;
}
.size-select {
    width: 65px;
}
.style-select {
    width: 88px;
}
.text-size-btn {
    font-family: Georgia, serif;
}
.text-size-btn sup {
    position: relative;
    top: -4px;
    font-size: 8px;
}
.bold-btn {
    font-weight: 700;
}
.italic-btn {
    font-family: Georgia, serif;
    font-style: italic;
    font-weight: 600;
}
.underline-btn {
    text-decoration: underline;
}
.strike-btn {
    text-decoration: line-through;
}
.center-align {
    text-align: center;
}
.right-align {
    text-align: right;
}
.list-btn {
    font-size: 14px;
} /* =========================================================
   Color
   ========================================================= */
.color-control {
    position: relative;
    display: inline-flex;
}
.native-color {
    position: absolute;
    width: 1px;
    height: 1px;
    opacity: 0;
    pointer-events: none;
}
.color-btn,
.highlight-btn {
    flex-direction: column;
    gap: 0;
}
.color-btn span,
.highlight-btn span {
    line-height: 16px;
    font-family: Georgia, serif;
    font-size: 16px;
    font-weight: 600;
}
.color-line,
.highlight-line {
    width: 16px;
    height: 3px;
    display: block;
    border-radius: 2px;
}
.highlight-a {
    background: #fff2a8;
} /* =========================================================
   Editor
   ========================================================= */
.editor-container {
    flex: 1;
    min-height: 0;
    overflow: auto;
    background:
        radial-gradient(
            circle at 50% 0%,
            rgba(255, 255, 255, 0.9),
            transparent 45%
        ),
        #f7f7f5;
}
.tiptap-content {
    min-height: 100%;
}
:deep(.ProseMirror) {
    width: min(920px, calc(100% - 80px));
    min-height: calc(100vh - 220px);
    margin: 32px auto 60px;
    padding: 56px 68px;
    box-sizing: border-box;
    background: #ffffff;
    border: 1px solid #eeeae4;
    border-radius: 3px;
    box-shadow:
        0 2px 4px rgba(0, 0, 0, 0.02),
        0 14px 45px rgba(0, 0, 0, 0.045);
    color: #292825;
    font-family:
        "Microsoft YaHei", "PingFang SC", "Helvetica Neue", Arial, sans-serif;
    font-size: 16px;
    line-height: 1.9;
    outline: none;
}
:deep(.ProseMirror:focus) {
    border-color: #e6e1d8;
} /* =========================================================
   Placeholder
   ========================================================= */
:deep(.ProseMirror p.is-editor-empty:first-child::before) {
    color: #b7b3ab;
    content: attr(data-placeholder);
    float: left;
    height: 0;
    pointer-events: none;
} /* =========================================================
   Typography
   ========================================================= */
:deep(.ProseMirror p) {
    margin: 0 0 12px;
}
:deep(.ProseMirror h1) {
    margin: 26px 0 18px;
    color: #22211f;
    font-size: 30px;
    line-height: 1.35;
    font-weight: 650;
    letter-spacing: -0.5px;
}
:deep(.ProseMirror h2) {
    margin: 24px 0 15px;
    color: #292825;
    font-size: 24px;
    line-height: 1.4;
    font-weight: 650;
}
:deep(.ProseMirror h3) {
    margin: 20px 0 12px;
    color: #33312e;
    font-size: 20px;
    line-height: 1.5;
    font-weight: 600;
}
:deep(.ProseMirror strong) {
    font-weight: 700;
}
:deep(.ProseMirror a) {
    color: #806b45;
    text-decoration: underline;
    text-decoration-color: rgba(128, 107, 69, 0.35);
    text-underline-offset: 3px;
} /* =========================================================
   Lists
   ========================================================= */
:deep(.ProseMirror ul),
:deep(.ProseMirror ol) {
    margin: 10px 0 16px;
    padding-left: 28px;
}
:deep(.ProseMirror li) {
    margin: 4px 0;
}
:deep(.ProseMirror ul[data-type="taskList"]) {
    list-style: none;
    padding: 0;
}
:deep(.ProseMirror ul[data-type="taskList"] li) {
    display: flex;
    align-items: flex-start;
    gap: 8px;
}
:deep(.ProseMirror ul[data-type="taskList"] li > label) {
    flex: 0 0 auto;
    margin-top: 5px;
}
:deep(.ProseMirror ul[data-type="taskList"] li > div) {
    flex: 1;
} /* =========================================================
   Blockquote
   ========================================================= */
:deep(.ProseMirror blockquote) {
    margin: 20px 0;
    padding: 8px 20px;
    border-left: 3px solid #c9bca6;
    color: #77736b;
    background: #faf9f6;
} /* =========================================================
   Image
   ========================================================= */
:deep(.ProseMirror img) {
    max-width: 100%;
    height: auto;
    margin: 12px 0;
    border-radius: 4px;
    box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
}
:deep(.ProseMirror img.ProseMirror-selectednode) {
    outline: 2px solid #b6a17b;
} /* =========================================================
   Table
   ========================================================= */
:deep(.ProseMirror table) {
    width: 100%;
    margin: 22px 0;
    border-collapse: collapse;
    table-layout: fixed;
    overflow: hidden;
    border: 1px solid #e4e0d9;
}
:deep(.ProseMirror th),
:deep(.ProseMirror td) {
    position: relative;
    min-width: 100px;
    padding: 9px 12px;
    border: 1px solid #e4e0d9;
    text-align: left;
    vertical-align: top;
}
:deep(.ProseMirror th) {
    background: #f7f5f1;
    color: #36332e;
    font-weight: 600;
}
:deep(.ProseMirror .selectedCell) {
    background: rgba(190, 170, 130, 0.15);
} /* =========================================================
   Selection
   ========================================================= */
:deep(.ProseMirror ::selection) {
    background: rgba(178, 155, 117, 0.25);
} /* =========================================================
   Horizontal Rule
   ========================================================= */
:deep(.ProseMirror hr) {
    margin: 28px 0;
    border: 0;
    border-top: 1px solid #e5e1da;
} /* =========================================================
   Status
   ========================================================= */
.editor-status {
    flex-shrink: 0;
    height: 30px;
    padding: 0 14px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-top: 1px solid #ebe9e4;
    background: #faf9f7;
    color: #9a968e;
    font-size: 11px;
    letter-spacing: 0.2px;
}
.status-left,
.status-right {
    display: flex;
    align-items: center;
} /* =========================================================
   Scrollbar
   ========================================================= */
.editor-container::-webkit-scrollbar {
    width: 8px;
}
.editor-container::-webkit-scrollbar-track {
    background: transparent;
}
.editor-container::-webkit-scrollbar-thumb {
    background: #d8d4cd;
    border-radius: 10px;
}
.editor-container::-webkit-scrollbar-thumb:hover {
    background: #c4beb4;
} /* =========================================================
   Responsive
   ========================================================= */
@media (max-width: 900px) {
    .editor-toolbar {
        flex-wrap: wrap;
        max-height: 90px;
        overflow-y: auto;
    }
    :deep(.ProseMirror) {
        width: calc(100% - 30px);
        margin: 15px auto 30px;
        padding: 35px 30px;
    }
}
</style>
