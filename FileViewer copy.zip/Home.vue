<template>
    <div class="home-page">
        <header class="page-header">
            <div class="header-main">
                <div class="page-title">
                    <span class="title-mark"></span>

                    <div>
                        <h1>文档编辑器</h1>
                        <p>Write something meaningful.</p>
                    </div>
                </div>

                <div class="header-actions">
                    <button class="header-btn secondary" @click="handlePreview">
                        预览
                    </button>

                    <button class="header-btn primary" @click="handleSave">
                        保存
                    </button>
                </div>
            </div>
        </header>

        <main class="editor-main">
            <TiptapEditor
                v-model="content"
                :editable="true"
                @change="handleContentChange"
            />
        </main>
        <!-- style="display: none" -->
        <!-- <FileViewer ref="fileViewerRef" /> -->
    </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import TiptapEditor from "./TiptapEditor.vue";
import FileViewer from "./FileViewer.vue";

/**
 * 编辑器内容
 *
 * 后续可以直接把这里接 API：
 *
 * const content = ref("")
 *
 * 接口返回 HTML：
 *
 * content.value = response.data.content
 */
const content = ref(`
    <h1>欢迎使用文档编辑器</h1>

    <p>
        这是一个基于
        <strong>Tiptap</strong>
        构建的富文本编辑器。
    </p>

    <p>
        你可以直接开始输入内容，也可以使用上方工具栏进行文字格式化。
    </p>
`);

/**
 * 内容发生变化
 */
function handleContentChange(value: string) {
    content.value = value;
}

/**
 * 保存
 */
function handleSave() {
    console.log("保存文档：", content.value);

    // TODO:
    // 调用后端 API 保存
}

/**
 * 预览
 */
const handlePreview = () => {
    if (!fileViewerRef.value) return;

    // 1. 将 Tiptap 的 HTML 内容包裹成一个完整的 HTML 字符串
    const fullHtmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>打印预览</title>
            <style>
                body { padding: 40px; font-family: sans-serif; line-height: 1.6; max-width: 800px; margin: 0 auto; }
                img { max-width: 100%; }
                table { border-collapse: collapse; width: 100%; }
                th, td { border: 1px solid #ddd; padding: 8px; }
            </style>
        </head>
        <body>
            ${content.value}
        </body>
        </html>
    `;

    // 2. 用 Blob 纯前端生成一个临时的网页文件，丢给组件去预览
    const blob = new Blob([fullHtmlContent], { type: "text/html" });
    const fileUrl = URL.createObjectURL(blob);

    // 3. 构造组件需要的标准文件对象格式，并调用它的内部方法直接呼出全屏预览
    const mockFileItem = {
        id: "tiptap-preview",
        name: "当前编辑器内容实时预览.pdf", // 欺骗解析器走 PDF 纯前端样式渲染，或更改后缀
        file: new File([blob], "preview.html"),
        url: fileUrl,
    };

    // 4. 直接越级触发刚才写好的预览核心方法
    fileViewerRef.value.handlePreview(mockFileItem);
};
</script>

<style scoped>
.home-page {
    width: 100%;
    height: 100vh;

    display: flex;
    flex-direction: column;

    overflow: hidden;

    background: #f7f7f5;
}

/* =========================================================
   Header
   ========================================================= */

.page-header {
    flex-shrink: 0;

    height: 72px;

    padding: 0 28px;

    display: flex;
    align-items: center;

    background: rgba(255, 255, 255, 0.94);

    border-bottom: 1px solid #ebe9e4;

    backdrop-filter: blur(12px);
}

.header-main {
    width: 100%;

    display: flex;
    align-items: center;
    justify-content: space-between;
}

.page-title {
    display: flex;
    align-items: center;
    gap: 13px;
}

.title-mark {
    width: 4px;
    height: 34px;

    display: block;

    border-radius: 3px;

    background: #a28d6c;
}

.page-title h1 {
    margin: 0;

    color: #292825;

    font-family: "Microsoft YaHei", "PingFang SC", sans-serif;

    font-size: 17px;
    font-weight: 600;
    letter-spacing: 0.3px;
}

.page-title p {
    margin: 3px 0 0;

    color: #a09b93;

    font-family: Georgia, serif;

    font-size: 11px;
    letter-spacing: 0.3px;
}

/* =========================================================
   Actions
   ========================================================= */

.header-actions {
    display: flex;
    align-items: center;
    gap: 8px;
}

.header-btn {
    height: 34px;

    padding: 0 17px;

    border-radius: 5px;

    font-size: 13px;

    cursor: pointer;

    transition:
        background 0.15s ease,
        border-color 0.15s ease,
        color 0.15s ease;
}

.header-btn.secondary {
    border: 1px solid #dedbd4;

    background: #ffffff;

    color: #595650;
}

.header-btn.secondary:hover {
    background: #f7f5f1;
}

.header-btn.primary {
    border: 1px solid #8d795a;

    background: #8d795a;

    color: #ffffff;

    box-shadow: 0 2px 5px rgba(100, 80, 50, 0.12);
}

.header-btn.primary:hover {
    background: #806c50;
    border-color: #806c50;
}

/* =========================================================
   Main
   ========================================================= */

.editor-main {
    flex: 1;

    min-height: 0;

    padding: 18px 22px 22px;

    overflow: hidden;
}

/* =========================================================
   Responsive
   ========================================================= */

@media (max-width: 700px) {
    .page-header {
        height: 60px;

        padding: 0 15px;
    }

    .page-title p {
        display: none;
    }

    .page-title h1 {
        font-size: 15px;
    }

    .editor-main {
        padding: 10px;
    }
}
</style>
