<template>
    <div class="file-preview">
        <!-- =========================================================
             上传区域
        ========================================================== -->
        <section
            class="upload-panel"
            :class="{ 'is-dragging': isDragActive }"
            @dragover.prevent="onDragOver"
            @dragleave.prevent="onDragLeave"
            @drop.prevent="onDrop"
            @click="triggerFileInput"
        >
            <input
                ref="fileInputRef"
                class="hidden-file-input"
                type="file"
                multiple
                accept=".docx,.xlsx,.xls,.pdf,.ppt,.pptx,.jpg,.jpeg,.png,.gif,.webp,.txt"
                @change="onFileSelect"
            />

            <div class="upload-inner">
                <div class="upload-symbol">
                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.5"
                    >
                        <path d="M12 16V4" stroke-linecap="round" />
                        <path
                            d="M7 9l5-5 5 5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        />
                        <path
                            d="M4 14v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"
                            stroke-linecap="round"
                        />
                    </svg>
                </div>

                <div class="upload-title">拖拽文件到这里</div>

                <div class="upload-subtitle">或 <span>点击选择文件</span></div>

                <div class="upload-types">
                    Word · Excel · PPT · PDF · 图片 · TXT
                </div>

                <div class="upload-limit">单文件最大 40 MB</div>
            </div>
        </section>

        <!-- =========================================================
             文件列表
        ========================================================== -->
        <section v-if="fileList.length" class="file-panel">
            <div class="file-panel-header">
                <div class="file-panel-title">
                    <span>文件</span>

                    <span class="file-count">
                        {{ fileList.length }}
                    </span>
                </div>

                <button
                    v-if="fileList.length > 1"
                    class="text-button"
                    type="button"
                    @click.stop="clearAll"
                >
                    清空
                </button>
            </div>

            <div class="file-list">
                <div v-for="item in fileList" :key="item.id" class="file-item">
                    <!-- 文件类型 -->
                    <div
                        class="file-type"
                        :class="`file-type--${getFileType(item.name)}`"
                    >
                        <span>
                            {{ getFileTypeLabel(item.name) }}
                        </span>
                    </div>

                    <!-- 文件信息 -->
                    <div class="file-information">
                        <div class="file-name" :title="item.name">
                            {{ item.name }}
                        </div>

                        <div class="file-size">
                            {{ formatSize(item.file?.size || item.size || 0) }}
                        </div>
                    </div>

                    <!-- 操作 -->
                    <div class="file-actions">
                        <button
                            class="action-button action-button--preview"
                            type="button"
                            @click.stop="handlePreview(item)"
                        >
                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.5"
                            >
                                <path
                                    d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"
                                />
                                <circle cx="12" cy="12" r="2.5" />
                            </svg>

                            <span>预览</span>
                        </button>

                        <button
                            class="action-button"
                            type="button"
                            @click.stop="handleDownload(item)"
                        >
                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.5"
                            >
                                <path d="M12 4v11" stroke-linecap="round" />
                                <path
                                    d="M7 11l5 5 5-5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                                <path d="M4 20h16" stroke-linecap="round" />
                            </svg>
                        </button>

                        <button
                            class="action-button action-button--delete"
                            type="button"
                            @click.stop="handleDelete(item.id)"
                        >
                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.5"
                            >
                                <path d="M5 7h14" stroke-linecap="round" />
                                <path d="M9 7V4h6v3" stroke-linecap="round" />
                                <path
                                    d="M7 7l1 13h8l1-13"
                                    stroke-linejoin="round"
                                />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- =========================================================
             全屏预览
        ========================================================== -->
        <Transition name="preview">
            <div
                v-if="isPreviewOpen"
                class="preview-overlay"
                @keydown.esc="closePreview"
            >
                <!-- =================================================
                     预览顶部
                ================================================== -->
                <header class="preview-header">
                    <div class="preview-file">
                        <div
                            class="preview-file-type"
                            :class="`file-type--${previewType}`"
                        >
                            {{ getPreviewTypeLabel() }}
                        </div>

                        <div class="preview-file-information">
                            <div
                                class="preview-file-name"
                                :title="currentPreviewFile?.name"
                            >
                                {{ currentPreviewFile?.name }}
                            </div>

                            <div class="preview-file-description">
                                {{ getPreviewDescription() }}
                            </div>
                        </div>
                    </div>

                    <div class="preview-header-actions">
                        <!-- 图片缩放 -->
                        <template v-if="previewType === 'image'">
                            <button
                                class="header-icon-button"
                                type="button"
                                title="缩小"
                                @click="imageScaleDown"
                            >
                                −
                            </button>

                            <span class="image-scale-value">
                                {{ Math.round(imageScale * 100) }}%
                            </span>

                            <button
                                class="header-icon-button"
                                type="button"
                                title="放大"
                                @click="imageScaleUp"
                            >
                                +
                            </button>

                            <span class="header-divider"></span>

                            <button
                                class="header-text-button"
                                type="button"
                                @click="imageReset"
                            >
                                重置
                            </button>
                        </template>

                        <button
                            v-if="currentPreviewFile"
                            class="header-icon-button"
                            type="button"
                            title="下载"
                            @click="handleDownload(currentPreviewFile)"
                        >
                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.5"
                            >
                                <path d="M12 4v11" stroke-linecap="round" />
                                <path
                                    d="M7 11l5 5 5-5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                                <path d="M4 20h16" stroke-linecap="round" />
                            </svg>
                        </button>

                        <button
                            class="header-close-button"
                            type="button"
                            title="关闭"
                            @click="closePreview"
                        >
                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.6"
                            >
                                <path d="M6 6l12 12" stroke-linecap="round" />
                                <path d="M18 6L6 18" stroke-linecap="round" />
                            </svg>
                        </button>
                    </div>
                </header>

                <!-- =================================================
                     预览内容区域
                ================================================== -->
                <main class="preview-content">
                    <!-- 加载 -->
                    <Transition name="fade">
                        <div v-if="isTemplateLoading" class="preview-loading">
                            <div class="loading-spinner">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>

                            <div class="loading-title">正在解析文件</div>

                            <div class="loading-description">
                                请稍候，文件内容正在加载...
                            </div>
                        </div>
                    </Transition>

                    <!-- 错误 -->
                    <div v-if="previewError" class="preview-error">
                        <div class="error-symbol">!</div>

                        <div class="error-title">文件无法预览</div>

                        <div class="error-description">
                            {{ previewError }}
                        </div>

                        <div class="error-actions">
                            <button
                                class="error-button error-button--primary"
                                type="button"
                                @click="retryPreview"
                            >
                                重新加载
                            </button>

                            <button
                                v-if="currentPreviewFile"
                                class="error-button"
                                type="button"
                                @click="handleDownload(currentPreviewFile)"
                            >
                                下载文件
                            </button>
                        </div>
                    </div>

                    <!-- =================================================
                         实际渲染容器
                    ================================================== -->
                    <div
                        v-show="!isTemplateLoading && !previewError"
                        class="render-container"
                    >
                        <!-- =============================
                             Word
                        ============================== -->
                        <div
                            v-if="previewType === 'docx'"
                            class="office-wrapper office-wrapper--docx"
                        >
                            <VueOfficeDocx
                                :key="renderKey"
                                :src="currentPreviewUrl"
                                :options="docxOptions"
                                class="office-viewer"
                                @rendered="onRenderSuccess"
                                @error="onRenderError"
                            />
                        </div>

                        <!-- =============================
                             Excel
                        ============================== -->
                        <div
                            v-else-if="previewType === 'excel'"
                            class="office-wrapper office-wrapper--excel"
                        >
                            <VueOfficeExcel
                                :key="renderKey"
                                :src="currentPreviewUrl"
                                :options="excelOptions"
                                class="office-viewer excel-viewer"
                                @rendered="onExcelRendered"
                                @error="onRenderError"
                            />
                        </div>

                        <!-- =============================
                             PDF
                        ============================== -->
                        <div
                            v-else-if="previewType === 'pdf'"
                            class="office-wrapper office-wrapper--pdf"
                        >
                            <VueOfficePdf
                                :key="renderKey"
                                :src="currentPreviewUrl"
                                class="office-viewer"
                                @rendered="onRenderSuccess"
                                @error="onRenderError"
                            />
                        </div>

                        <!-- =============================
                             PPT / PPTX
                        ============================== -->
                        <div
                            v-else-if="previewType === 'pptx'"
                            class="office-wrapper office-wrapper--pptx"
                        >
                            <VueOfficePptx
                                :key="renderKey"
                                :src="currentPreviewUrl"
                                class="office-viewer pptx-viewer"
                                @rendered="onPptxRendered"
                                @error="onPptxError"
                            />
                        </div>

                        <!-- =============================
                             图片
                        ============================== -->
                        <div
                            v-else-if="previewType === 'image'"
                            class="image-preview"
                        >
                            <div class="image-stage">
                                <img
                                    :src="currentPreviewUrl"
                                    :alt="
                                        currentPreviewFile?.name || '图片预览'
                                    "
                                    class="preview-image"
                                    :style="{
                                        transform: `scale(${imageScale})`,
                                    }"
                                    draggable="false"
                                />
                            </div>
                        </div>

                        <!-- =============================
                             TXT
                        ============================== -->
                        <div
                            v-else-if="previewType === 'txt'"
                            class="txt-preview"
                        >
                            <div class="txt-toolbar">
                                <div>
                                    <span class="txt-toolbar-title">
                                        Plain Text
                                    </span>

                                    <span class="txt-toolbar-divider"> / </span>

                                    <span> {{ txtLineCount }} 行 </span>
                                </div>

                                <div class="txt-toolbar-right">UTF-8</div>
                            </div>

                            <div class="txt-content">
                                <div class="line-numbers">
                                    <span
                                        v-for="line in txtLineCount"
                                        :key="line"
                                    >
                                        {{ line }}
                                    </span>
                                </div>

                                <pre>{{ txtContent }}</pre>
                            </div>
                        </div>

                        <!-- =============================
                             不支持
                        ============================== -->
                        <div v-else class="unsupported-preview">
                            <div class="unsupported-icon">?</div>

                            <div class="unsupported-title">
                                暂不支持该文件格式
                            </div>

                            <div class="unsupported-description">
                                当前文件无法直接在浏览器中预览
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </Transition>
    </div>
</template>

<script setup>
import {
    ref,
    computed,
    onMounted,
    onUnmounted,
    defineAsyncComponent,
} from "vue";

import "@vue-office/docx/lib/index.css";
import "@vue-office/excel/lib/index.css";

// ============================================================
// Vue Office
// ============================================================

const VueOfficeDocx = defineAsyncComponent(() => import("@vue-office/docx"));

const VueOfficeExcel = defineAsyncComponent(() => import("@vue-office/excel"));

const VueOfficePdf = defineAsyncComponent(() => import("@vue-office/pdf"));

const VueOfficePptx = defineAsyncComponent(() => import("@vue-office/pptx"));

// ============================================================
// 基础配置
// ============================================================

const MAX_FILE_SIZE = 40 * 1024 * 1024;

// Word
const docxOptions = {
    breakPages: true,
    ignoreWidth: false,
    ignoreHeight: false,
    inWrapper: true,
};

// Excel
const excelOptions = {
    minColLength: 0,
    minRowLength: 0,
};

// ============================================================
// 状态
// ============================================================

const fileInputRef = ref(null);

const isDragActive = ref(false);

const fileList = ref([]);

// 预览
const isPreviewOpen = ref(false);

const isTemplateLoading = ref(false);

const previewError = ref("");

const currentPreviewFile = ref(null);

const currentPreviewUrl = ref("");

const previewType = ref("");

const txtContent = ref("");

// 每次重新渲染使用新的 key
const renderKey = ref(0);

// Excel resize observer
const excelResizeObserver = ref(null);

// 图片缩放
const imageScale = ref(1);

// ============================================================
// TXT
// ============================================================

const txtLineCount = computed(() => {
    if (!txtContent.value) {
        return 0;
    }

    return txtContent.value.split(/\r\n|\r|\n/).length;
});

// ============================================================
// 上传
// ============================================================

const triggerFileInput = () => {
    fileInputRef.value?.click();
};

const onDragOver = () => {
    isDragActive.value = true;
};

const onDragLeave = () => {
    isDragActive.value = false;
};

const onDrop = (event) => {
    isDragActive.value = false;

    const files = event.dataTransfer?.files;

    if (files?.length) {
        handleFilesAdded(files);
    }
};

const onFileSelect = (event) => {
    const files = event.target?.files;

    if (files?.length) {
        handleFilesAdded(files);
    }

    if (fileInputRef.value) {
        fileInputRef.value.value = "";
    }
};

// ============================================================
// 添加文件
// ============================================================

const handleFilesAdded = (files) => {
    Array.from(files).forEach((file) => {
        if (file.size > MAX_FILE_SIZE) {
            window.alert(`「${file.name}」超过 40MB，已跳过`);

            return;
        }

        const id = Date.now() + Math.random().toString(36).slice(2, 10);

        const url = URL.createObjectURL(file);

        fileList.value.push({
            id,
            name: file.name,
            file,
            url,
            size: file.size,
            isBase64: false,
        });
    });
};

// ============================================================
// Base64 图片
//
// 可以在父组件中通过 ref 调用：
//
// const previewRef = ref()
//
// previewRef.value.previewBase64Image(
//     'data:image/png;base64,...',
//     'test.png'
// )
//
// ============================================================

const previewBase64Image = (base64, name = "image.png") => {
    if (typeof base64 !== "string" || !base64.trim()) {
        return;
    }

    let mime = "image/png";

    const mimeMatch = base64.match(/^data:(image\/[^;]+);base64,/i);

    if (mimeMatch) {
        mime = mimeMatch[1];
    }

    const pureBase64 = base64.replace(/^data:[^;]+;base64,/i, "");

    let size = 0;

    try {
        size = Math.ceil((pureBase64.length * 3) / 4);
    } catch {
        size = 0;
    }

    const item = {
        id: Date.now() + Math.random().toString(36).slice(2, 10),

        name,

        file: null,

        url: base64.startsWith("data:")
            ? base64
            : `data:${mime};base64,${pureBase64}`,

        size,

        isBase64: true,

        base64,
    };

    fileList.value.push(item);

    return item;
};

// 暴露给父组件
defineExpose({
    previewBase64Image,
});

// ============================================================
// 删除
// ============================================================

const handleDelete = (id) => {
    const index = fileList.value.findIndex((item) => item.id === id);

    if (index === -1) {
        return;
    }

    const item = fileList.value[index];

    if (item.url && !item.isBase64) {
        URL.revokeObjectURL(item.url);
    }

    fileList.value.splice(index, 1);

    if (currentPreviewFile.value?.id === id) {
        closePreview();
    }
};

// ============================================================
// 清空
// ============================================================

const clearAll = () => {
    fileList.value.forEach((item) => {
        if (item.url && !item.isBase64) {
            URL.revokeObjectURL(item.url);
        }
    });

    fileList.value = [];

    closePreview();
};

// ============================================================
// 下载
// ============================================================

const handleDownload = (item) => {
    if (!item) {
        return;
    }

    const url = item.url;

    if (!url) {
        return;
    }

    const link = document.createElement("a");

    link.href = url;

    link.download = item.name || "download";

    link.style.display = "none";

    document.body.appendChild(link);

    link.click();

    document.body.removeChild(link);
};

// ============================================================
// 获取扩展名
// ============================================================

const getExtension = (name = "") => {
    const index = name.lastIndexOf(".");

    if (index === -1) {
        return "";
    }

    return name.slice(index + 1).toLowerCase();
};

// ============================================================
// 文件类型
// ============================================================

const getFileType = (name = "") => {
    const ext = getExtension(name);

    if (["jpg", "jpeg", "png", "gif", "webp", "bmp"].includes(ext)) {
        return "image";
    }

    if (ext === "txt") {
        return "txt";
    }

    if (ext === "pdf") {
        return "pdf";
    }

    if (["doc", "docx"].includes(ext)) {
        return "docx";
    }

    if (["xls", "xlsx", "xlsm"].includes(ext)) {
        return "excel";
    }

    if (["ppt", "pptx", "pps", "ppsx"].includes(ext)) {
        return "pptx";
    }

    return "unknown";
};

// ============================================================
// 类型标签
// ============================================================

const getFileTypeLabel = (name) => {
    const type = getFileType(name);

    const map = {
        image: "IMG",
        txt: "TXT",
        pdf: "PDF",
        docx: "DOC",
        excel: "XLS",
        pptx: "PPT",
        unknown: "FILE",
    };

    return map[type] || "FILE";
};

// ============================================================
// Preview 类型
// ============================================================

const getPreviewTypeLabel = () => {
    const map = {
        image: "IMG",
        txt: "TXT",
        pdf: "PDF",
        docx: "DOC",
        excel: "XLS",
        pptx: "PPT",
    };

    return map[previewType.value] || "FILE";
};

const getPreviewDescription = () => {
    const map = {
        image: "图片预览",
        txt: "纯文本文件",
        pdf: "PDF 文档",
        docx: "Word 文档",
        excel: "Excel 工作簿",
        pptx: "PowerPoint 演示文稿",
    };

    return map[previewType.value] || "文件预览";
};

// ============================================================
// 预览
// ============================================================

const handlePreview = async (fileItem) => {
    if (!fileItem) {
        return;
    }

    cleanupExcelResize();

    currentPreviewFile.value = fileItem;

    currentPreviewUrl.value = fileItem.url;

    previewError.value = "";

    txtContent.value = "";

    imageScale.value = 1;

    const ext = getExtension(fileItem.name);

    // 图片
    if (
        ["jpg", "jpeg", "png", "gif", "webp", "bmp"].includes(ext) ||
        fileItem.isBase64
    ) {
        previewType.value = "image";
    }

    // Word
    else if (["docx"].includes(ext)) {
        previewType.value = "docx";
    }

    // Excel
    else if (["xlsx", "xls", "xlsm"].includes(ext)) {
        previewType.value = "excel";
    }

    // PDF
    else if (ext === "pdf") {
        previewType.value = "pdf";
    }

    // PPT
    else if (["pptx", "ppt", "pps", "ppsx"].includes(ext)) {
        previewType.value = "pptx";
    }

    // TXT
    else if (ext === "txt") {
        previewType.value = "txt";

        try {
            if (fileItem.file) {
                txtContent.value = await fileItem.file.text();
            } else {
                previewError.value = "TXT 文件读取失败";
            }
        } catch (error) {
            console.error(error);

            previewError.value = "TXT 文件读取失败";
        }
    }

    // Unsupported
    else {
        previewType.value = "unsupported";
    }

    isPreviewOpen.value = true;

    isTemplateLoading.value = ["docx", "excel", "pdf", "pptx"].includes(
        previewType.value,
    );

    renderKey.value += 1;

    await new Promise((resolve) => requestAnimationFrame(resolve));

    if (previewType.value === "excel") {
        setupExcelResize();
    }
};

// ============================================================
// 普通 Office 渲染成功
// ============================================================

const onRenderSuccess = () => {
    isTemplateLoading.value = false;

    previewError.value = "";
};

// ============================================================
// Excel 渲染成功
// ============================================================

const onExcelRendered = () => {
    isTemplateLoading.value = false;

    previewError.value = "";

    requestAnimationFrame(() => {
        setupExcelResize();
    });
};

// ============================================================
// PPTX 渲染
// ============================================================

const onPptxRendered = () => {
    /*
     * PPTX renderer 的 rendered 事件只代表
     * renderer 完成了执行。
     *
     * 某些 PPTX 即使触发 rendered，
     * 实际内容仍可能没有正常显示。
     *
     * 因此这里给它一个非常短的 DOM 检查窗口。
     */

    setTimeout(() => {
        if (previewType.value !== "pptx") {
            return;
        }

        const container = document.querySelector(".office-wrapper--pptx");

        if (!container) {
            isTemplateLoading.value = false;

            return;
        }

        /*
         * 不强制判断具体 renderer 的 DOM 结构。
         *
         * 只判断容器内部是否真的产生了内容。
         */

        const hasContent = container.children.length > 0;

        if (!hasContent) {
            isTemplateLoading.value = false;

            previewError.value =
                "当前 PPTX 文件无法在浏览器中正常渲染，建议下载文件或转换为 PDF 后预览。";

            return;
        }

        isTemplateLoading.value = false;

        previewError.value = "";
    }, 300);
};

// ============================================================
// Office Error
// ============================================================

const onRenderError = (error) => {
    console.error("Office preview error:", error);

    isTemplateLoading.value = false;

    if (previewType.value === "excel") {
        previewError.value =
            "Excel 文件解析失败，可能文件损坏或包含当前浏览器暂不支持的复杂内容。";

        return;
    }

    if (previewType.value === "docx") {
        previewError.value = "Word 文件解析失败，可能文件损坏或包含复杂格式。";

        return;
    }

    if (previewType.value === "pdf") {
        previewError.value = "PDF 文件解析失败，请检查文件是否损坏。";

        return;
    }

    previewError.value = "文件解析失败，可能文件损坏或格式过于复杂。";
};

// ============================================================
// PPT Error
// ============================================================

const onPptxError = (error) => {
    console.error("PPTX preview error:", error);

    isTemplateLoading.value = false;

    previewError.value =
        "PPTX 文件无法正常解析，当前浏览器预览引擎对部分 PowerPoint 内容兼容性有限。建议下载文件或转换为 PDF 后预览。";
};

// ============================================================
// 重试
// ============================================================

const retryPreview = () => {
    if (currentPreviewFile.value) {
        handlePreview(currentPreviewFile.value);
    }
};

// ============================================================
// Excel ResizeObserver
// ============================================================

const setupExcelResize = () => {
    cleanupExcelResize();

    if (previewType.value !== "excel") {
        return;
    }

    const container = document.querySelector(".office-wrapper--excel");

    if (!container) {
        return;
    }

    excelResizeObserver.value = new ResizeObserver(() => {
        forceExcelResize(container);
    });

    excelResizeObserver.value.observe(container);

    requestAnimationFrame(() => {
        forceExcelResize(container);
    });
};

const forceExcelResize = (container) => {
    if (!container) {
        return;
    }

    const viewer = container.querySelector(".excel-viewer");

    if (viewer) {
        viewer.style.width = "100%";

        viewer.style.height = "100%";
    }

    const spreadsheet = container.querySelector(".x-spreadsheet");

    if (spreadsheet) {
        spreadsheet.style.width = "100%";

        spreadsheet.style.height = "100%";
    }
};

// ============================================================
// 清理 ResizeObserver
// ============================================================

const cleanupExcelResize = () => {
    if (excelResizeObserver.value) {
        excelResizeObserver.value.disconnect();

        excelResizeObserver.value = null;
    }
};

// ============================================================
// 图片缩放
// ============================================================

const imageScaleUp = () => {
    imageScale.value = Math.min(3, Number((imageScale.value + 0.1).toFixed(2)));
};

const imageScaleDown = () => {
    imageScale.value = Math.max(
        0.2,
        Number((imageScale.value - 0.1).toFixed(2)),
    );
};

const imageReset = () => {
    imageScale.value = 1;
};

// ============================================================
// 关闭
// ============================================================

const closePreview = () => {
    cleanupExcelResize();

    isPreviewOpen.value = false;

    isTemplateLoading.value = false;

    previewError.value = "";

    currentPreviewFile.value = null;

    currentPreviewUrl.value = "";

    previewType.value = "";

    txtContent.value = "";

    imageScale.value = 1;
};

// ============================================================
// ESC
// ============================================================

const handleKeydown = (event) => {
    if (event.key === "Escape" && isPreviewOpen.value) {
        closePreview();
    }
};

// ============================================================
// 文件大小
// ============================================================

const formatSize = (bytes) => {
    if (!bytes) {
        return "0 B";
    }

    if (bytes < 1024) {
        return `${bytes} B`;
    }

    if (bytes < 1024 * 1024) {
        return `${(bytes / 1024).toFixed(1)} KB`;
    }

    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
};

// ============================================================
// 生命周期
// ============================================================

onMounted(() => {
    window.addEventListener("keydown", handleKeydown);
});

onUnmounted(() => {
    cleanupExcelResize();

    window.removeEventListener("keydown", handleKeydown);

    fileList.value.forEach((item) => {
        if (item.url && !item.isBase64) {
            URL.revokeObjectURL(item.url);
        }
    });
});
</script>

<style scoped>
/* ============================================================
   Root
============================================================ */

.file-preview {
    width: 100%;
    min-height: 100%;

    box-sizing: border-box;

    color: #262522;

    font-family:
        -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC",
        "Microsoft YaHei", sans-serif;
}

/* ============================================================
   Upload
============================================================ */

.upload-panel {
    position: relative;

    width: 100%;
    min-height: 230px;

    box-sizing: border-box;

    border: 1px solid #e5e2dc;

    border-radius: 14px;

    background: linear-gradient(145deg, #ffffff 0%, #faf9f7 100%);

    cursor: pointer;

    overflow: hidden;

    transition:
        border-color 0.25s ease,
        box-shadow 0.25s ease,
        transform 0.25s ease;
}

.upload-panel::before {
    content: "";

    position: absolute;

    inset: 12px;

    border: 1px dashed #dedad2;

    border-radius: 10px;

    pointer-events: none;

    transition: border-color 0.25s ease;
}

.upload-panel:hover {
    border-color: #c9c3b8;

    box-shadow: 0 12px 35px rgba(40, 35, 28, 0.06);
}

.upload-panel:hover::before,
.upload-panel.is-dragging::before {
    border-color: #b39b72;
}

.upload-panel.is-dragging {
    border-color: #b39b72;

    background: linear-gradient(145deg, #fffdf8 0%, #f7f2e8 100%);

    transform: translateY(-1px);

    box-shadow: 0 15px 40px rgba(104, 83, 49, 0.1);
}

.hidden-file-input {
    display: none;
}

.upload-inner {
    position: relative;

    z-index: 1;

    min-height: 230px;

    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;
}

.upload-symbol {
    width: 48px;
    height: 48px;

    margin-bottom: 17px;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #806d50;

    border-radius: 13px;

    background: #f2eee6;

    box-shadow: inset 0 0 0 1px rgba(128, 109, 80, 0.08);
}

.upload-symbol svg {
    width: 24px;
    height: 24px;
}

.upload-title {
    font-size: 16px;

    font-weight: 500;

    letter-spacing: 0.02em;

    color: #2c2a27;
}

.upload-subtitle {
    margin-top: 8px;

    font-size: 13px;

    color: #8c8881;
}

.upload-subtitle span {
    color: #856f4d;

    font-weight: 500;
}

.upload-types {
    margin-top: 19px;

    font-size: 11px;

    letter-spacing: 0.08em;

    color: #aaa49b;
}

.upload-limit {
    margin-top: 6px;

    font-size: 10px;

    color: #b5b0a8;
}

/* ============================================================
   File Panel
============================================================ */

.file-panel {
    margin-top: 24px;

    border: 1px solid #e7e4de;

    border-radius: 13px;

    background: #ffffff;

    overflow: hidden;
}

.file-panel-header {
    height: 54px;

    padding: 0 18px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    border-bottom: 1px solid #eeece8;
}

.file-panel-title {
    display: flex;

    align-items: center;

    gap: 8px;

    font-size: 14px;

    font-weight: 500;

    color: #34312c;
}

.file-count {
    min-width: 20px;
    height: 20px;

    padding: 0 6px;

    box-sizing: border-box;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    border-radius: 10px;

    background: #f1eee8;

    color: #88775b;

    font-size: 11px;

    font-weight: 500;
}

.text-button {
    border: 0;

    padding: 5px 8px;

    background: transparent;

    color: #9a948b;

    font-size: 12px;

    cursor: pointer;

    transition: color 0.2s ease;
}

.text-button:hover {
    color: #786344;
}

/* ============================================================
   File List
============================================================ */

.file-list {
    width: 100%;
}

.file-item {
    min-height: 70px;

    padding: 10px 18px;

    box-sizing: border-box;

    display: flex;

    align-items: center;

    gap: 14px;

    border-bottom: 1px solid #f0eeeb;

    transition: background 0.2s ease;
}

.file-item:last-child {
    border-bottom: 0;
}

.file-item:hover {
    background: #faf9f7;
}

/* ============================================================
   File Type
============================================================ */

.file-type {
    width: 42px;
    height: 42px;

    flex: 0 0 42px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 10px;

    font-size: 10px;

    font-weight: 600;

    letter-spacing: 0.02em;
}

.file-type--image {
    color: #667b70;

    background: #edf2ef;
}

.file-type--txt {
    color: #74716c;

    background: #f0efed;
}

.file-type--pdf {
    color: #a16c68;

    background: #f5ebea;
}

.file-type--docx {
    color: #607795;

    background: #edf1f6;
}

.file-type--excel {
    color: #617b6a;

    background: #edf2ee;
}

.file-type--pptx {
    color: #977a59;

    background: #f4efe8;
}

.file-type--unknown {
    color: #77736c;

    background: #f0efec;
}

/* ============================================================
   File Information
============================================================ */

.file-information {
    min-width: 0;

    flex: 1;
}

.file-name {
    overflow: hidden;

    text-overflow: ellipsis;

    white-space: nowrap;

    font-size: 13px;

    color: #34312d;
}

.file-size {
    margin-top: 5px;

    font-size: 11px;

    color: #aaa59d;
}

/* ============================================================
   Actions
============================================================ */

.file-actions {
    display: flex;

    align-items: center;

    gap: 4px;
}

.action-button {
    height: 34px;

    min-width: 34px;

    padding: 0 9px;

    border: 0;

    border-radius: 7px;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 5px;

    color: #8d8981;

    background: transparent;

    cursor: pointer;

    transition:
        background 0.2s ease,
        color 0.2s ease;
}

.action-button svg {
    width: 16px;
    height: 16px;
}

.action-button:hover {
    background: #f4f2ee;

    color: #615747;
}

.action-button--preview {
    padding: 0 12px;

    background: #f3f0e9;

    color: #796748;
}

.action-button--preview:hover {
    background: #ebe5d9;

    color: #665437;
}

.action-button--delete:hover {
    color: #a06d69;

    background: #f7efee;
}

/* ============================================================
   Preview Overlay
============================================================ */

.preview-overlay {
    position: fixed;

    z-index: 9999;

    inset: 0;

    display: flex;

    flex-direction: column;

    background: #f1f0ee;

    overflow: hidden;
}

/* ============================================================
   Preview Header
============================================================ */

.preview-header {
    height: 62px;

    flex: 0 0 62px;

    box-sizing: border-box;

    padding: 0 20px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    background: rgba(255, 255, 255, 0.97);

    border-bottom: 1px solid #e5e3df;

    box-shadow: 0 1px 8px rgba(40, 36, 30, 0.03);
}

.preview-file {
    min-width: 0;

    display: flex;

    align-items: center;

    gap: 12px;
}

.preview-file-type {
    width: 34px;
    height: 34px;

    flex: 0 0 34px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 9px;

    font-size: 9px;

    font-weight: 600;
}

.preview-file-information {
    min-width: 0;
}

.preview-file-name {
    max-width: min(60vw, 720px);

    overflow: hidden;

    text-overflow: ellipsis;

    white-space: nowrap;

    font-size: 14px;

    font-weight: 500;

    color: #2d2a26;
}

.preview-file-description {
    margin-top: 3px;

    font-size: 10px;

    color: #a29d95;

    letter-spacing: 0.02em;
}

.preview-header-actions {
    display: flex;

    align-items: center;

    gap: 3px;
}

.header-icon-button,
.header-close-button {
    width: 36px;
    height: 36px;

    padding: 0;

    border: 0;

    border-radius: 8px;

    display: flex;

    align-items: center;
    justify-content: center;

    background: transparent;

    color: #88837b;

    cursor: pointer;

    transition:
        background 0.2s ease,
        color 0.2s ease;
}

.header-icon-button svg,
.header-close-button svg {
    width: 17px;
    height: 17px;
}

.header-icon-button:hover {
    background: #f2f0ec;

    color: #5e5549;
}

.header-close-button {
    margin-left: 7px;

    color: #716b62;
}

.header-close-button:hover {
    background: #eeeae4;

    color: #2e2b27;
}

.image-scale-value {
    min-width: 40px;

    text-align: center;

    font-size: 11px;

    color: #777169;
}

.header-divider {
    width: 1px;
    height: 18px;

    margin: 0 6px;

    background: #e4e1dc;
}

.header-text-button {
    height: 34px;

    padding: 0 9px;

    border: 0;

    background: transparent;

    color: #827a70;

    font-size: 11px;

    cursor: pointer;
}

/* ============================================================
   Preview Content
============================================================ */

.preview-content {
    position: relative;

    flex: 1 1 auto;

    width: 100%;
    height: 0;

    min-width: 0;
    min-height: 0;

    overflow: hidden;
}

/* ============================================================
   Render Container
============================================================ */

.render-container {
    position: absolute;

    inset: 0;

    width: 100%;
    height: 100%;

    min-width: 0;
    min-height: 0;

    overflow: hidden;
}

/* ============================================================
   Office Wrapper
============================================================ */

.office-wrapper {
    position: relative;

    width: 100%;
    height: 100%;

    min-width: 0;
    min-height: 0;

    overflow: hidden;
}

.office-viewer {
    display: block;

    width: 100% !important;
    height: 100% !important;

    min-width: 0 !important;
    min-height: 0 !important;
}

/* ============================================================
   Word
============================================================ */

.office-wrapper--docx {
    overflow: auto;

    background: #eae9e7;
}

.office-wrapper--docx .office-viewer {
    width: 100% !important;

    height: auto !important;

    min-height: 100% !important;
}

/* ============================================================
   Excel
============================================================ */

.office-wrapper--excel {
    width: 100%;
    height: 100%;

    overflow: hidden;

    background: #f5f5f3;
}

.office-wrapper--excel .office-viewer {
    position: absolute;

    inset: 0;

    width: 100% !important;
    height: 100% !important;

    min-width: 100% !important;
    min-height: 100% !important;
}

.office-wrapper--excel :deep(.x-spreadsheet) {
    width: 100% !important;
    height: 100% !important;

    min-width: 100% !important;
    min-height: 100% !important;
}

.office-wrapper--excel :deep(.x-spreadsheet-sheet) {
    width: 100% !important;
    height: 100% !important;
}

.office-wrapper--excel :deep(.x-spreadsheet-overlayer) {
    width: 100% !important;
    height: 100% !important;
}

/* ============================================================
   PDF
============================================================ */

.office-wrapper--pdf {
    width: 100%;
    height: 100%;

    overflow: auto;

    background: #555452;
}

/* ============================================================
   PPT
============================================================ */

.office-wrapper--pptx {
    width: 100%;
    height: 100%;

    overflow: auto;

    background: #e9e8e6;
}

.office-wrapper--pptx .office-viewer {
    width: 100% !important;

    height: auto !important;

    min-width: 100% !important;
    min-height: 100% !important;
}

/* ============================================================
   Image
============================================================ */

.image-preview {
    position: absolute;

    inset: 0;

    width: 100%;
    height: 100%;

    overflow: auto;

    background: #ecebea;
}

.image-stage {
    width: 100%;
    min-height: 100%;

    padding: 40px;

    box-sizing: border-box;

    display: flex;

    align-items: center;
    justify-content: center;
}

.preview-image {
    max-width: 100%;

    max-height: calc(100vh - 150px);

    object-fit: contain;

    transform-origin: center center;

    user-select: none;

    box-shadow: 0 12px 35px rgba(30, 28, 24, 0.12);

    transition: transform 0.18s ease;
}

/* ============================================================
   TXT
============================================================ */

.txt-preview {
    position: absolute;

    inset: 0;

    display: flex;

    flex-direction: column;

    background: #faf9f7;

    overflow: hidden;
}

.txt-toolbar {
    height: 42px;

    flex: 0 0 42px;

    padding: 0 18px;

    box-sizing: border-box;

    display: flex;

    align-items: center;

    justify-content: space-between;

    border-bottom: 1px solid #e7e4de;

    background: #ffffff;

    color: #9b958c;

    font-size: 11px;
}

.txt-toolbar-title {
    color: #6d665d;

    font-weight: 500;
}

.txt-toolbar-divider {
    margin: 0 7px;

    color: #d2cec7;
}

.txt-toolbar-right {
    letter-spacing: 0.04em;

    color: #b0aaa1;
}

.txt-content {
    flex: 1;

    min-height: 0;

    display: flex;

    overflow: auto;

    background: #fbfaf8;
}

.line-numbers {
    flex: 0 0 auto;

    padding: 20px 14px 20px 18px;

    box-sizing: border-box;

    text-align: right;

    color: #bdb8b0;

    background: #f5f3ef;

    border-right: 1px solid #e8e5df;

    font-family: "SFMono-Regular", Consolas, "Liberation Mono", monospace;

    font-size: 12px;

    line-height: 1.8;

    user-select: none;
}

.line-numbers span {
    display: block;
}

.txt-content pre {
    margin: 0;

    padding: 20px 24px;

    min-width: max-content;

    color: #3f3c37;

    font-family: "SFMono-Regular", Consolas, "Liberation Mono", monospace;

    font-size: 13px;

    line-height: 1.8;

    white-space: pre;
}

/* ============================================================
   Loading
============================================================ */

.preview-loading {
    position: absolute;

    z-index: 20;

    inset: 0;

    display: flex;

    flex-direction: column;

    align-items: center;
    justify-content: center;

    background: rgba(245, 244, 242, 0.94);

    backdrop-filter: blur(5px);
}

.loading-spinner {
    width: 42px;
    height: 42px;

    display: flex;

    align-items: center;
    justify-content: center;

    gap: 4px;
}

.loading-spinner span {
    width: 4px;
    height: 16px;

    border-radius: 3px;

    background: #9b8768;

    animation: loading 1s infinite ease-in-out;
}

.loading-spinner span:nth-child(2) {
    animation-delay: 0.12s;
}

.loading-spinner span:nth-child(3) {
    animation-delay: 0.24s;
}

.loading-title {
    margin-top: 16px;

    font-size: 13px;

    color: #4a453e;

    font-weight: 500;
}

.loading-description {
    margin-top: 6px;

    font-size: 11px;

    color: #aaa49b;
}

@keyframes loading {
    0%,
    80%,
    100% {
        transform: scaleY(0.6);

        opacity: 0.45;
    }

    40% {
        transform: scaleY(1);

        opacity: 1;
    }
}

/* ============================================================
   Error
============================================================ */

.preview-error {
    position: absolute;

    z-index: 30;

    inset: 0;

    display: flex;

    flex-direction: column;

    align-items: center;
    justify-content: center;

    background: #f5f4f2;
}

.error-symbol {
    width: 42px;
    height: 42px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: #f2e7e5;

    color: #a3756f;

    font-family: Georgia, serif;

    font-size: 21px;
}

.error-title {
    margin-top: 16px;

    color: #49443e;

    font-size: 14px;

    font-weight: 500;
}

.error-description {
    max-width: 480px;

    margin-top: 8px;

    text-align: center;

    color: #a19b93;

    font-size: 12px;

    line-height: 1.7;
}

.error-actions {
    margin-top: 22px;

    display: flex;

    align-items: center;

    gap: 8px;
}

.error-button {
    height: 34px;

    padding: 0 16px;

    border: 1px solid #ddd8d0;

    border-radius: 7px;

    background: #ffffff;

    color: #777066;

    font-size: 12px;

    cursor: pointer;
}

.error-button:hover {
    background: #f8f6f2;
}

.error-button--primary {
    border-color: #907957;

    background: #907957;

    color: #ffffff;
}

.error-button--primary:hover {
    background: #7e694c;
}

/* ============================================================
   Unsupported
============================================================ */

.unsupported-preview {
    position: absolute;

    inset: 0;

    display: flex;

    flex-direction: column;

    align-items: center;
    justify-content: center;

    background: #f5f4f2;
}

.unsupported-icon {
    width: 44px;
    height: 44px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: #eeece8;

    color: #9c958c;

    font-size: 18px;
}

.unsupported-title {
    margin-top: 16px;

    color: #514c45;

    font-size: 14px;
}

.unsupported-description {
    margin-top: 7px;

    color: #aaa49b;

    font-size: 11px;
}

/* ============================================================
   Transition
============================================================ */

.preview-enter-active,
.preview-leave-active {
    transition: opacity 0.22s ease;
}

.preview-enter-from,
.preview-leave-to {
    opacity: 0;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.18s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}

/* ============================================================
   Responsive
============================================================ */

@media (max-width: 700px) {
    .upload-panel {
        min-height: 200px;
    }

    .upload-inner {
        min-height: 200px;
    }

    .file-item {
        padding: 10px 12px;
    }

    .action-button--preview span {
        display: none;
    }

    .action-button--preview {
        width: 34px;

        padding: 0;
    }

    .preview-header {
        padding: 0 10px;
    }

    .preview-file-name {
        max-width: 45vw;
    }

    .image-stage {
        padding: 20px;
    }
}
</style>
