// src/components/Tiptap/tiptap-bundle.ts
import { Extension } from "@tiptap/core";
import StarterKit from "@tiptap/starter-kit";
import { Placeholder } from "@tiptap/extension-placeholder";
import { Link } from "@tiptap/extension-link";
import { Color } from "@tiptap/extension-color";
import { TextStyle } from "@tiptap/extension-text-style";
import { TextAlign } from "@tiptap/extension-text-align";
import { Underline } from "@tiptap/extension-underline";
import { Highlight } from "@tiptap/extension-highlight";
import { Image } from "@tiptap/extension-image";

// 表格与任务列表
import { Table } from "@tiptap/extension-table";
import { TableRow } from "@tiptap/extension-table-row";
import { TableCell } from "@tiptap/extension-table-cell";
import { TableHeader } from "@tiptap/extension-table-header";
import { TaskList } from "@tiptap/extension-task-list";
import { TaskItem } from "@tiptap/extension-task-item";

// 💡 截图新增：官方字体扩展
import { FontFamily } from "@tiptap/extension-font-family";

/**
 * 💡 截图新增：极其轻量、对 TypeScript 完美的自定义“字号扩展”
 * 它会让 Tiptap 认识 font-size 样式，并允许通过命令随意修改
 */
const FontSize = Extension.create({
    name: "fontSize",
    addOptions() {
        return {
            types: ["textStyle"],
        };
    },
    addGlobalAttributes() {
        return [
            {
                types: this.options.types,
                attributes: {
                    fontSize: {
                        default: null,
                        parseHTML: (element) =>
                            element.style.fontSize?.replace(/['"]/g, ""),
                        renderHTML: (attributes) => {
                            if (!attributes.fontSize) return {};
                            return {
                                style: `font-size: ${attributes.fontSize}`,
                            };
                        },
                    },
                },
            },
        ];
    },
    addCommands() {
        return {
            setFontSize:
                (fontSize: string) =>
                ({ chain }) => {
                    return chain().setMark("textStyle", { fontSize }).run();
                },
            unsetFontSize:
                () =>
                ({ chain }) => {
                    return chain()
                        .setMark("textStyle", { fontSize: null })
                        .run();
                },
        };
    },
});

// 为全局让 TypeScript 认识我们的 setFontSize 命令提示
declare module "@tiptap/core" {
    interface Commands<ReturnType> {
        fontSize: {
            setFontSize: (size: string) => ReturnType;
            unsetFontSize: () => ReturnType;
        };
    }
}

/**
 * 🚀 已经将你的配置升级为：Office 级全功能全家桶大包
 */
export const FullFeaturedTiptapExtensions = [
    // 1. 核心大包
    StarterKit.configure({
        codeBlock: false,
    }),

    // 2. 基础文本增强
    Underline,
    Highlight.configure({ multicolor: true }),
    Color,
    TextStyle,
    FontFamily, // 💡 激活微软雅黑等字体能力
    FontSize, // 💡 激活数字字号能力

    // 3. 布局与媒体
    TextAlign.configure({
        types: ["heading", "paragraph"],
    }),
    Image.configure({
        inline: true,
        HTMLAttributes: { class: "custom-image" },
    }),
    Link.configure({
        openOnClick: false,
        HTMLAttributes: { class: "custom-link" },
    }),

    // 4. 强大的表格支持
    Table.configure({
        resizable: true,
    }),
    TableRow,
    TableHeader,
    TableCell,

    // 5. 待办任务列表 (Checklist)
    TaskList,
    TaskItem.configure({
        nested: true,
    }),

    // 6. 交互优化
    Placeholder.configure({
        placeholder: "请输入正文内容...",
    }),
];
