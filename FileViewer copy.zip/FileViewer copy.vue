<template>
    <div class="file-manager">
        <!-- ==================== 上传区域 ==================== -->
        <section
            class="upload-panel"
            :class="{ 'is-dragging': isDragActive }"
            @dragenter.prevent="onDragEnter"
            @dragover.prevent="onDragOver"
            @dragleave.prevent="onDragLeave"
            @drop.prevent="onDrop"
            @click="triggerFileInput"
        >
            <input
                ref="fileInputRef"
                class="hidden-input"
                type="file"
                multiple
                :accept="ACCEPT"
                @change="onFileSelect"
            />
            <div class="upload-inner">
                <div class="upload-symbol">
                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.5"
                    >
                        <path
                            d="M12 16V4"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        />
                        <path
                            d="M7 9l5-5 5 5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        />
                        <path
                            d="M4 16v2.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V16"
                            stroke-linecap="round"
                        />
                    </svg>
                </div>
                <div class="upload-title">上传文件</div>
                <div class="upload-description">
                    拖拽文件至此，或
                    <span class="upload-link">点击选择文件</span>
                </div>
                <div class="upload-tip">
                    Word · Excel · PPT · PDF · 图片 · TXT
                    <span class="dot">·</span>
                    单文件最大 {{ MAX_FILE_SIZE_MB }}MB
                </div>
            </div>
        </section>
        <!-- ==================== 文件列表 ==================== -->
        <section v-if="fileList.length" class="file-section">
            <div class="section-head">
                <div>
                    <div class="section-title">
                        文件
                        <span class="file-count">
                            {{ fileList.length }}
                        </span>
                    </div>
                    <div class="section-subtitle">已添加的文件</div>
                </div>
                <button
                    v-if="fileList.length > 1"
                    class="text-button"
                    type="button"
                    @click.stop="clearAll"
                >
                    清空全部
                </button>
            </div>
            <div class="file-list">
                <div v-for="item in fileList" :key="item.id" class="file-card">
                    <div class="file-type-icon" :class="`type-${item.type}`">
                        <span>{{ getFileIcon(item.name) }}</span>
                    </div>
                    <div class="file-main">
                        <div class="file-name" :title="item.name">
                            {{ item.name }}
                        </div>
                        <div class="file-detail">
                            <span>{{ getFileTypeName(item.name) }}</span>
                            <span class="detail-dot">·</span>
                            <span>{{ formatSize(item.file.size) }}</span>
                        </div>
                    </div>
                    <div class="file-actions">
                        <button
                            class="action-button primary"
                            type="button"
                            @click="handlePreview(item)"
                        >
                            预览
                        </button>
                        <button
                            class="action-button"
                            type="button"
                            @click="handleDownload(item)"
                        >
                            下载
                        </button>
                        <button
                            class="action-button danger"
                            type="button"
                            @click="handleDelete(item.id)"
                        >
                            删除
                        </button>
                    </div>
                </div>
            </div>
        </section>
        <!-- ==================== 预览窗口 ==================== -->
        <Teleport to="body">
            <Transition name="preview">
                <div
                    v-if="isPreviewOpen"
                    class="preview-modal"
                    @click.self="closePreview"
                >
                    <div class="preview-window">
                        <!-- 顶部 -->
                        <header class="preview-header">
                            <div class="preview-file-info">
                                <div
                                    class="preview-file-icon"
                                    :class="`type-${previewType}`"
                                >
                                    {{ getFileIcon(currentPreviewFile?.name) }}
                                </div>
                                <div class="preview-file-meta">
                                    <div
                                        class="preview-file-name"
                                        :title="currentPreviewFile?.name"
                                    >
                                        {{ currentPreviewFile?.name }}
                                    </div>
                                    <div class="preview-file-type">
                                        {{
                                            getFileTypeName(
                                                currentPreviewFile?.name,
                                            )
                                        }}
                                    </div>
                                </div>
                            </div>
                            <div class="preview-header-actions">
                                <button
                                    v-if="currentPreviewFile"
                                    class="header-button"
                                    type="button"
                                    title="下载"
                                    @click="handleDownload(currentPreviewFile)"
                                >
                                    <svg
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor"
                                        stroke-width="1.6"
                                    >
                                        <path
                                            d="M12 4v11"
                                            stroke-linecap="round"
                                        />
                                        <path
                                            d="M7 11l5 5 5-5"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        />
                                        <path
                                            d="M4 20h16"
                                            stroke-linecap="round"
                                        />
                                    </svg>
                                </button>
                                <button
                                    class="header-button close"
                                    type="button"
                                    title="关闭"
                                    @click="closePreview"
                                >
                                    <svg
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor"
                                        stroke-width="1.6"
                                    >
                                        <path
                                            d="M6 6l12 12M18 6L6 18"
                                            stroke-linecap="round"
                                        />
                                    </svg>
                                </button>
                            </div>
                        </header>
                        <!-- 内容区域 -->
                        <main class="preview-content">
                            <!-- Loading -->
                            <Transition name="fade">
                                <div
                                    v-if="isTemplateLoading"
                                    class="preview-loading"
                                >
                                    <div class="loading-orbit">
                                        <span></span>
                                    </div>

                                    <div class="loading-title">
                                        正在解析文件
                                    </div>

                                    <div class="loading-text">
                                        请稍候，文件内容正在加载...
                                    </div>
                                </div>
                            </Transition>

                            <!-- Error -->
                            <div v-if="previewError" class="preview-error">
                                <div class="error-icon">!</div>

                                <div class="error-title">文件无法预览</div>

                                <div class="error-message">
                                    {{ previewError }}
                                </div>

                                <div class="error-actions">
                                    <button
                                        class="retry-button"
                                        type="button"
                                        @click="retryPreview"
                                    >
                                        重新加载
                                    </button>

                                    <button
                                        v-if="currentPreviewFile"
                                        class="download-error-button"
                                        type="button"
                                        @click="
                                            handleDownload(currentPreviewFile)
                                        "
                                    >
                                        下载文件
                                    </button>
                                </div>
                            </div>

                            <!-- 真正渲染区域 -->
                            <div
                                v-show="!isTemplateLoading && !previewError"
                                class="render-container"
                            >
                                <!-- Word -->
                                <div
                                    v-if="previewType === 'docx'"
                                    class="office-wrapper office-wrapper--docx"
                                >
                                    <VueOfficeDocx
                                        :key="renderKey"
                                        :src="currentPreviewUrl"
                                        :options="docxOptions"
                                        class="office-viewer"
                                        @rendered="onRenderSuccess"
                                        @error="onRenderError"
                                    />
                                </div>

                                <!-- Excel -->
                                <div
                                    v-else-if="previewType === 'excel'"
                                    class="office-wrapper office-wrapper--excel"
                                >
                                    <VueOfficeExcel
                                        :key="renderKey"
                                        :src="currentPreviewUrl"
                                        :options="excelOptions"
                                        class="office-viewer excel-viewer"
                                        @rendered="onRenderSuccess"
                                        @error="onRenderError"
                                    />
                                </div>

                                <!-- PDF -->
                                <div
                                    v-else-if="previewType === 'pdf'"
                                    class="office-wrapper office-wrapper--pdf"
                                >
                                    <VueOfficePdf
                                        :key="renderKey"
                                        :src="currentPreviewUrl"
                                        class="office-viewer"
                                        @rendered="onRenderSuccess"
                                        @error="onRenderError"
                                    />
                                </div>

                                <!-- PPTX -->
                                <div
                                    v-else-if="previewType === 'pptx'"
                                    class="office-wrapper office-wrapper--pptx"
                                >
                                    <VueOfficePptx
                                        :key="renderKey"
                                        :src="currentPreviewUrl"
                                        class="office-viewer pptx-viewer"
                                        @rendered="onPptxRendered"
                                        @error="onPptxError"
                                    />
                                </div>

                                <!-- Image -->
                                <div
                                    v-else-if="previewType === 'image'"
                                    class="image-preview"
                                >
                                    <div class="image-toolbar">
                                        <button
                                            type="button"
                                            @click="imageScaleDown"
                                        >
                                            −
                                        </button>

                                        <span>
                                            {{ Math.round(imageScale * 100) }}%
                                        </span>

                                        <button
                                            type="button"
                                            @click="imageScaleUp"
                                        >
                                            +
                                        </button>

                                        <i></i>

                                        <button
                                            type="button"
                                            @click="imageReset"
                                        >
                                            重置
                                        </button>
                                    </div>

                                    <div class="image-stage">
                                        <img
                                            :src="currentPreviewUrl"
                                            :alt="currentPreviewFile?.name"
                                            class="preview-image"
                                            :style="{
                                                transform: `scale(${imageScale})`,
                                            }"
                                        />
                                    </div>
                                </div>

                                <!-- TXT -->
                                <div
                                    v-else-if="previewType === 'txt'"
                                    class="txt-preview"
                                >
                                    <div class="txt-toolbar">
                                        <span> {{ txtLineCount }} 行 </span>

                                        <span class="txt-language">
                                            Plain Text
                                        </span>
                                    </div>

                                    <div class="txt-content">
                                        <div class="line-numbers">
                                            <span
                                                v-for="line in txtLineCount"
                                                :key="line"
                                            >
                                                {{ line }}
                                            </span>
                                        </div>

                                        <pre>{{ txtContent }}</pre>
                                    </div>
                                </div>
                            </div>
                        </main>
                    </div>
                </div>
            </Transition>
        </Teleport>
    </div>
</template>
<script setup>
import {
    computed,
    defineAsyncComponent,
    onMounted,
    onUnmounted,
    ref,
} from "vue";
import "@vue-office/docx/lib/index.css";
import "@vue-office/excel/lib/index.css";
const VueOfficeDocx = defineAsyncComponent(() => import("@vue-office/docx"));
const VueOfficeExcel = defineAsyncComponent(() => import("@vue-office/excel"));
const VueOfficePdf = defineAsyncComponent(() => import("@vue-office/pdf"));
const VueOfficePptx = defineAsyncComponent(() => import("@vue-office/pptx"));
/* =========================================================
 * 配置
 * ========================================================= */ const MAX_FILE_SIZE =
    40 * 1024 * 1024;
const MAX_FILE_SIZE_MB = 40;
const ACCEPT = [
    ".docx",
    ".xlsx",
    ".xls",
    ".pdf",
    ".pptx",
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".webp",
    ".txt",
].join(","); /*
 * Word
 */
const docxOptions = {
    breakPages: true,
    ignoreWidth: false,
    ignoreHeight: false,
    inWrapper: true,
}; /*
 * Excel
 */
const excelOptions = {
    minColLength: 0,
    minRowLength: 0,
};
/* =========================================================
 * 状态
 * ========================================================= */ const fileInputRef =
    ref(null);
const isDragActive = ref(false);
const dragCounter = ref(0);
const fileList = ref([]);
const isPreviewOpen = ref(false);
const isTemplateLoading = ref(false);
const previewError = ref("");
const currentPreviewFile = ref(null);
const currentPreviewUrl = ref("");
const previewType = ref("");
const txtContent = ref("");
const renderKey = ref(0); /* 图片缩放 */
const imageScale = ref(1);
/* =========================================================
 * Computed
 * ========================================================= */ const txtLineCount =
    computed(() => {
        if (!txtContent.value) {
            return 1;
        }
        return txtContent.value.split(/\r\n|\r|\n/).length;
    });
/* =========================================================
 * 上传
 * ========================================================= */ const triggerFileInput =
    () => {
        fileInputRef.value?.click();
    };
const onDragEnter = () => {
    dragCounter.value++;
    isDragActive.value = true;
};
const onDragOver = () => {
    isDragActive.value = true;
};
const onDragLeave = () => {
    dragCounter.value--;
    if (dragCounter.value <= 0) {
        dragCounter.value = 0;
        isDragActive.value = false;
    }
};
const onDrop = (event) => {
    dragCounter.value = 0;
    isDragActive.value = false;
    const files = event.dataTransfer?.files;
    if (files?.length) {
        handleFilesAdded(files);
    }
};
const onFileSelect = (event) => {
    const files = event.target?.files;
    if (files?.length) {
        handleFilesAdded(files);
    }
    if (fileInputRef.value) {
        fileInputRef.value.value = "";
    }
};
/* =========================================================
 * 添加 File
 * ========================================================= */ const handleFilesAdded =
    (files) => {
        Array.from(files).forEach((file) => {
            addFile(file);
        });
    };
const addFile = (file) => {
    if (!(file instanceof File)) {
        return;
    }
    if (file.size > MAX_FILE_SIZE) {
        window.alert(`「${file.name}」超过 ${MAX_FILE_SIZE_MB}MB，已跳过`);
        return;
    }
    const existing = fileList.value.some(
        (item) => item.name === file.name && item.file.size === file.size,
    );
    if (existing) {
        return;
    }
    const item = createFileItem(file);
    fileList.value.push(item);
};
/* =========================================================
 * Base64
 *
 * 可以：
 *
 * addBase64File("demo.png", "data:image/png;base64,...")
 *
 * 或：
 *
 * addBase64File(
 *     "demo.png",
 *     "iVBORw0KGgoAAAANSUhEUg..."
 * )
 *
 * ========================================================= */ const addBase64File =
    (name, base64) => {
        try {
            if (!name || !base64) {
                throw new Error("Base64 文件参数不能为空");
            }
            const { blob, mimeType } = base64ToBlob(base64);
            if (blob.size > MAX_FILE_SIZE) {
                window.alert(`「${name}」超过 ${MAX_FILE_SIZE_MB}MB`);
                return null;
            }
            const file = new File([blob], name, {
                type: mimeType || blob.type || "application/octet-stream",
            });
            const item = createFileItem(file);
            fileList.value.push(item);
            return item;
        } catch (error) {
            console.error("Base64 文件转换失败:", error);
            return null;
        }
    };
const base64ToBlob = (base64) => {
    let mimeType = "";
    let rawBase64 = base64; /*
     * data:image/png;base64,xxxx
     */
    const dataUrlMatch = base64.match(
        /^data:([^;,]+)?(?:;charset=[^;,]+)?;base64,(.*)$/s,
    );
    if (dataUrlMatch) {
        mimeType = dataUrlMatch[1] || "";
        rawBase64 = dataUrlMatch[2];
    } /*
     * 处理可能存在的换行
     */
    rawBase64 = rawBase64.replace(/\s/g, "");
    const byteCharacters = atob(rawBase64);
    const sliceSize = 1024 * 1024;
    const byteArrays = [];
    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
        const slice = byteCharacters.slice(offset, offset + sliceSize);
        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }
        byteArrays.push(new Uint8Array(byteNumbers));
    }
    return {
        blob: new Blob(byteArrays, {
            type: mimeType,
        }),
        mimeType,
    };
};
/* =========================================================
 * 创建文件对象
 * ========================================================= */ const createFileItem =
    (file) => {
        return {
            id: `${Date.now()}-` + Math.random().toString(36).slice(2, 10),
            name: file.name,
            file,
            url: URL.createObjectURL(file),
            type: detectFileType(file.name, file.type),
        };
    };
/* =========================================================
 * 文件类型
 * ========================================================= */ const detectFileType =
    (name = "", mimeType = "") => {
        const lowerName = name.toLowerCase();
        const ext = lowerName.includes(".") ? lowerName.split(".").pop() : "";
        if (["jpg", "jpeg", "png", "gif", "webp"].includes(ext)) {
            return "image";
        }
        if (ext === "docx") {
            return "docx";
        }
        if (["xls", "xlsx"].includes(ext)) {
            return "excel";
        }
        if (ext === "pdf") {
            return "pdf";
        }
        if (ext === "pptx") {
            return "pptx";
        }
        if (ext === "txt") {
            return "txt";
        } /*
         * Base64 图片没有扩展名时，
         * 根据 MIME 判断
         */
        if (mimeType.startsWith("image/")) {
            return "image";
        }
        if (mimeType.includes("wordprocessingml")) {
            return "docx";
        }
        if (mimeType.includes("spreadsheetml")) {
            return "excel";
        }
        if (mimeType.includes("presentationml")) {
            return "pptx";
        }
        if (mimeType === "application/pdf") {
            return "pdf";
        }
        if (mimeType === "text/plain") {
            return "txt";
        }
        return "unsupported";
    };
/* =========================================================
 * 文件删除
 * ========================================================= */ const handleDelete =
    (id) => {
        const index = fileList.value.findIndex((item) => item.id === id);
        if (index === -1) {
            return;
        }
        const item = fileList.value[index];
        URL.revokeObjectURL(item.url);
        fileList.value.splice(index, 1);
        if (currentPreviewFile.value?.id === id) {
            closePreview();
        }
    };
const clearAll = () => {
    fileList.value.forEach((item) => {
        URL.revokeObjectURL(item.url);
    });
    fileList.value = [];
    closePreview();
};
/* =========================================================
 * 下载
 * ========================================================= */ const handleDownload =
    (item) => {
        if (!item) {
            return;
        }
        const link = document.createElement("a");
        link.href = item.url;
        link.download = item.name;
        document.body.appendChild(link);
        link.click();
        link.remove();
    };
/* =========================================================
 * 预览
 * ========================================================= */ const handlePreview =
    async (item) => {
        if (!item) {
            return;
        }
        currentPreviewFile.value = item;
        currentPreviewUrl.value = item.url;
        previewError.value = "";
        txtContent.value = "";
        imageScale.value = 1;
        previewType.value = item.type;
        renderKey.value++;
        isPreviewOpen.value = true; /*
         * TXT 不需要加载动画
         */
        if (item.type === "txt") {
            isTemplateLoading.value = true;
            try {
                txtContent.value = await item.file.text();
                isTemplateLoading.value = false;
            } catch (error) {
                console.error(error);
                isTemplateLoading.value = false;
                previewError.value = "TXT 文件读取失败";
            }
            return;
        } /*
         * 图片直接显示
         */
        if (item.type === "image") {
            isTemplateLoading.value = false;
            return;
        } /*
         * 不支持格式
         */
        if (item.type === "unsupported") {
            isTemplateLoading.value = false;
            return;
        } /*
         * Office / PDF
         */
        isTemplateLoading.value = true;
    };
/* =========================================================
 * Vue Office
 * ========================================================= */ const onRenderSuccess =
    () => {
        isTemplateLoading.value = false;
        previewError.value = "";
    };
const onRenderError = (error) => {
    console.error("文件预览失败:", error);
    isTemplateLoading.value = false;
    const messages = {
        docx: "Word 文件解析失败，文件可能损坏或包含当前版本暂不支持的内容。",
        excel: "Excel 文件解析失败，文件可能损坏或包含复杂公式、图表或特殊格式。",
        pdf: "PDF 文件解析失败，请检查文件是否损坏。",
        pptx: "PPTX 文件解析失败，复杂动画、字体或部分特殊元素可能无法解析。",
    };
    previewError.value =
        messages[previewType.value] || "文件解析失败，请检查文件是否损坏。";
};
/* =========================================================
 * 重试
 * ========================================================= */ const retryPreview =
    () => {
        if (!currentPreviewFile.value) {
            return;
        }
        handlePreview(currentPreviewFile.value);
    };
/* =========================================================
 * 关闭预览
 * ========================================================= */ const closePreview =
    () => {
        isPreviewOpen.value = false;
        isTemplateLoading.value = false;
        previewError.value = "";
        currentPreviewFile.value = null;
        currentPreviewUrl.value = "";
        previewType.value = "";
        txtContent.value = "";
        imageScale.value = 1;
    };
/* =========================================================
 * 图片
 * ========================================================= */ const onImageLoaded =
    () => {
        imageScale.value = 1;
    };
const imageScaleUp = () => {
    imageScale.value = Math.min(3, Number((imageScale.value + 0.1).toFixed(2)));
};
const imageScaleDown = () => {
    imageScale.value = Math.max(
        0.2,
        Number((imageScale.value - 0.1).toFixed(2)),
    );
};
const imageReset = () => {
    imageScale.value = 1;
};
/* =========================================================
 * 文件信息
 * ========================================================= */ const getFileTypeName =
    (name = "") => {
        const ext = name.split(".").pop()?.toLowerCase();
        const map = {
            docx: "Word 文档",
            xlsx: "Excel 工作簿",
            xls: "Excel 工作簿",
            pptx: "PowerPoint 演示文稿",
            pdf: "PDF 文档",
            txt: "文本文件",
            jpg: "图片",
            jpeg: "图片",
            png: "图片",
            gif: "图片",
            webp: "图片",
        };
        return map[ext] || "文件";
    };
const getFileIcon = (name = "") => {
    const ext = name.split(".").pop()?.toLowerCase();
    const map = {
        docx: "W",
        xlsx: "X",
        xls: "X",
        pptx: "P",
        pdf: "PDF",
        txt: "TXT",
        jpg: "IMG",
        jpeg: "IMG",
        png: "IMG",
        gif: "IMG",
        webp: "IMG",
    };
    return map[ext] || "FILE";
};
const formatSize = (bytes) => {
    if (!bytes) {
        return "0 B";
    }
    if (bytes < 1024) {
        return `${bytes} B`;
    }
    if (bytes < 1024 * 1024) {
        return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
};
/* =========================================================
 * ESC 关闭
 * ========================================================= */ const handleKeydown =
    (event) => {
        if (event.key === "Escape" && isPreviewOpen.value) {
            closePreview();
        }
    };
onMounted(() => {
    window.addEventListener("keydown", handleKeydown);
});
/* =========================================================
 * 暴露给父组件
 *
 * 父组件可以：
 *
 * const fileManager = ref()
 *
 * fileManager.value.addBase64File(
 *     "demo.png",
 *     base64
 * )
 *
 * ========================================================= */ defineExpose({
    addFile,
    addBase64File,
    clearAll,
    closePreview,
});
/* =========================================================
 * 销毁
 * ========================================================= */ onUnmounted(
    () => {
        window.removeEventListener("keydown", handleKeydown);
        fileList.value.forEach((item) => {
            URL.revokeObjectURL(item.url);
        });
    },
);
</script>
<style scoped>
/* =========================================================
   基础
   ========================================================= */
.file-manager {
    width: 100%;
    min-height: 100%;
    box-sizing: border-box;
    color: #252525;
    background: #fafaf9;
} /* =========================================================
   上传区域
   ========================================================= */
.upload-panel {
    position: relative;
    width: 100%;
    min-height: 220px;
    box-sizing: border-box;
    border: 1px dashed #d7d3ce;
    border-radius: 18px;
    background: linear-gradient(135deg, #ffffff 0%, #faf9f7 100%);
    cursor: pointer;
    transition:
        border-color 0.25s ease,
        background 0.25s ease,
        box-shadow 0.25s ease,
        transform 0.25s ease;
}
.upload-panel:hover {
    border-color: #aaa39b;
    box-shadow: 0 12px 40px rgba(43, 37, 31, 0.06);
}
.upload-panel.is-dragging {
    border-color: #9a8a78;
    background: #f6f2ed;
    box-shadow: 0 18px 50px rgba(43, 37, 31, 0.1);
}
.upload-inner {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}
.upload-symbol {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 54px;
    height: 54px;
    margin-bottom: 18px;
    border-radius: 15px;
    color: #665d54;
    background: #f1eeea;
}
.upload-symbol svg {
    width: 25px;
    height: 25px;
}
.upload-title {
    margin-bottom: 8px;
    font-size: 17px;
    font-weight: 600;
    letter-spacing: 0.2px;
}
.upload-description {
    color: #77716b;
    font-size: 14px;
}
.upload-link {
    color: #6c5d4d;
    font-weight: 600;
}
.upload-tip {
    margin-top: 13px;
    color: #aaa49d;
    font-size: 12px;
}
.dot {
    margin: 0 5px;
}
.hidden-input {
    display: none;
} /* =========================================================
   文件列表
   ========================================================= */
.file-section {
    margin-top: 28px;
}
.section-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 14px;
}
.section-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 16px;
    font-weight: 600;
}
.file-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 22px;
    height: 22px;
    padding: 0 6px;
    box-sizing: border-box;
    border-radius: 11px;
    color: #70675f;
    background: #efebe6;
    font-size: 11px;
    font-weight: 600;
}
.section-subtitle {
    margin-top: 4px;
    color: #aaa49d;
    font-size: 12px;
}
.text-button {
    border: none;
    background: none;
    padding: 6px 4px;
    color: #8b8178;
    font-size: 12px;
    cursor: pointer;
    transition: color 0.2s ease;
}
.text-button:hover {
    color: #3e3935;
} /* =========================================================
   文件卡片
   ========================================================= */
.file-list {
    display: flex;
    flex-direction: column;
    gap: 9px;
}
.file-card {
    display: flex;
    align-items: center;
    min-height: 76px;
    padding: 12px 14px;
    box-sizing: border-box;
    border: 1px solid #ebe8e4;
    border-radius: 14px;
    background: #fff;
    transition:
        border-color 0.2s ease,
        box-shadow 0.2s ease,
        transform 0.2s ease;
}
.file-card:hover {
    border-color: #ddd7d0;
    box-shadow: 0 7px 24px rgba(43, 37, 31, 0.055);
    transform: translateY(-1px);
}
.file-type-icon {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 46px;
    height: 46px;
    margin-right: 14px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: -0.3px;
}
.file-type-icon.type-docx {
    color: #536b84;
    background: #edf2f7;
}
.file-type-icon.type-excel {
    color: #587262;
    background: #edf4ef;
}
.file-type-icon.type-pptx {
    color: #846956;
    background: #f6efe9;
}
.file-type-icon.type-pdf {
    color: #8b5f5b;
    background: #f7eeee;
}
.file-type-icon.type-image {
    color: #6d6478;
    background: #f1eef5;
}
.file-type-icon.type-txt {
    color: #716b62;
    background: #f1efeb;
}
.file-main {
    flex: 1;
    min-width: 0;
}
.file-name {
    overflow: hidden;
    color: #302d2a;
    font-size: 14px;
    font-weight: 500;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.file-detail {
    display: flex;
    align-items: center;
    margin-top: 6px;
    color: #aaa49d;
    font-size: 11px;
}
.detail-dot {
    margin: 0 7px;
}
.file-actions {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-left: 20px;
}
.action-button {
    height: 32px;
    padding: 0 12px;
    border: 1px solid #e5e1dc;
    border-radius: 8px;
    color: #6f6962;
    background: #fff;
    font-size: 12px;
    cursor: pointer;
    transition:
        color 0.2s ease,
        background 0.2s ease,
        border-color 0.2s ease;
}
.action-button:hover {
    color: #393530;
    border-color: #cfc8c0;
    background: #faf9f7;
}
.action-button.primary {
    color: #fff;
    border-color: #4e4842;
    background: #4e4842;
}
.action-button.primary:hover {
    border-color: #37322e;
    background: #37322e;
}
.action-button.danger:hover {
    color: #9b625d;
    border-color: #dfc5c1;
    background: #fbf4f3;
} /* =========================================================
   预览 Modal
   ========================================================= */
.preview-modal {
    position: fixed;
    z-index: 99999;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 28px;
    box-sizing: border-box;
    background: rgba(27, 24, 21, 0.56);
    backdrop-filter: blur(8px);
}
.preview-window {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    max-width: 1600px;
    max-height: 94vh;
    overflow: hidden;
    border-radius: 18px;
    background: #f7f7f6;
    box-shadow: 0 30px 100px rgba(0, 0, 0, 0.25);
} /* =========================================================
   预览头部
   ========================================================= */
.preview-header {
    flex: 0 0 66px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px;
    border-bottom: 1px solid #e7e4e0;
    background: rgba(255, 255, 255, 0.96);
}
.preview-file-info {
    display: flex;
    align-items: center;
    min-width: 0;
}
.preview-file-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 38px;
    height: 38px;
    margin-right: 11px;
    border-radius: 10px;
    font-size: 10px;
    font-weight: 700;
}
.preview-file-icon.type-docx {
    color: #536b84;
    background: #edf2f7;
}
.preview-file-icon.type-excel {
    color: #587262;
    background: #edf4ef;
}
.preview-file-icon.type-pptx {
    color: #846956;
    background: #f6efe9;
}
.preview-file-icon.type-pdf {
    color: #8b5f5b;
    background: #f7eeee;
}
.preview-file-icon.type-image {
    color: #6d6478;
    background: #f1eef5;
}
.preview-file-icon.type-txt {
    color: #716b62;
    background: #f1efeb;
}
.preview-file-meta {
    min-width: 0;
}
.preview-file-name {
    max-width: 600px;
    overflow: hidden;
    color: #2e2b28;
    font-size: 14px;
    font-weight: 600;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.preview-file-type {
    margin-top: 4px;
    color: #aaa49d;
    font-size: 11px;
}
.preview-header-actions {
    display: flex;
    align-items: center;
    gap: 6px;
}
.header-button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    padding: 0;
    border: 1px solid transparent;
    border-radius: 9px;
    color: #746e67;
    background: transparent;
    cursor: pointer;
    transition:
        background 0.2s ease,
        color 0.2s ease;
}
.header-button svg {
    width: 18px;
    height: 18px;
}
.header-button:hover {
    background: #f1efec;
    color: #35312d;
}
.header-button.close:hover {
    color: #9a5f59;
    background: #f8eeee;
} /* =========================================================
   预览内容
   ========================================================= */
.preview-content {
    position: relative;
    flex: 1;
    min-height: 0;
    overflow: hidden;
    background: #eee;
}
.render-container {
    width: 100%;
    height: 100%;
    overflow: auto;
} /* =========================================================
   Vue Office
   ========================================================= */
.office-viewer {
    width: 100%;
    height: 100%;
    min-height: 100%;
}
.excel-viewer {
    overflow: auto;
}
.docx-viewer {
    background: #ecebea;
}
.pdf-viewer {
    background: #525252;
}
.pptx-viewer {
    background: #e8e6e3;
} /* =========================================================
   Loading
   ========================================================= */
.preview-loading {
    position: absolute;
    z-index: 20;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: rgba(247, 247, 246, 0.96);
}
.loading-orbit {
    position: relative;
    width: 36px;
    height: 36px;
    margin-bottom: 18px;
    border: 1px solid #ddd8d2;
    border-radius: 50%;
}
.loading-orbit::before {
    content: "";
    position: absolute;
    inset: 5px;
    border: 1px solid #bbb3aa;
    border-top-color: transparent;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}
.loading-orbit span {
    position: absolute;
    top: -2px;
    left: 50%;
    width: 5px;
    height: 5px;
    margin-left: -2.5px;
    border-radius: 50%;
    background: #74695e;
}
.loading-title {
    color: #514b45;
    font-size: 14px;
    font-weight: 600;
}
.loading-text {
    margin-top: 7px;
    color: #aaa49e;
    font-size: 12px;
}
@keyframes spin {
    to {
        transform: rotate(360deg);
    }
} /* =========================================================
   Error
   ========================================================= */
.preview-error {
    position: absolute;
    z-index: 30;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 30px;
    box-sizing: border-box;
    background: #f7f7f6;
}
.error-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 42px;
    height: 42px;
    margin-bottom: 16px;
    border-radius: 50%;
    color: #9a6c66;
    background: #f5e9e7;
    font-size: 18px;
    font-weight: 600;
}
.error-title {
    color: #4b4540;
    font-size: 15px;
    font-weight: 600;
}
.error-message {
    max-width: 480px;
    margin-top: 8px;
    color: #aaa49d;
    font-size: 12px;
    line-height: 1.7;
    text-align: center;
}
.retry-button {
    margin-top: 20px;
    height: 34px;
    padding: 0 16px;
    border: 1px solid #d9d3cd;
    border-radius: 8px;
    color: #5f574f;
    background: #fff;
    font-size: 12px;
    cursor: pointer;
}
.retry-button:hover {
    border-color: #bbb2a9;
    background: #faf8f6;
} /* =========================================================
   图片预览
   ========================================================= */
.image-preview {
    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background:
        linear-gradient(45deg, #e9e8e6 25%, transparent 25%),
        linear-gradient(-45deg, #e9e8e6 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #e9e8e6 75%),
        linear-gradient(-45deg, transparent 75%, #e9e8e6 75%);
    background-size: 24px 24px;
    background-position:
        0 0,
        0 12px,
        12px -12px,
        -12px 0;
}
.image-toolbar {
    position: absolute;
    z-index: 10;
    top: 18px;
    left: 50%;
    display: flex;
    align-items: center;
    height: 36px;
    padding: 0 5px;
    border: 1px solid #ddd8d1;
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.94);
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
    transform: translateX(-50%);
}
.image-toolbar button {
    min-width: 30px;
    height: 28px;
    padding: 0 8px;
    border: none;
    border-radius: 6px;
    color: #6b645d;
    background: transparent;
    font-size: 13px;
    cursor: pointer;
}
.image-toolbar button:hover {
    background: #f1efec;
    color: #312d29;
}
.image-toolbar span {
    min-width: 48px;
    color: #777069;
    font-size: 11px;
    text-align: center;
}
.image-toolbar i {
    width: 1px;
    height: 16px;
    margin: 0 5px;
    background: #e3dfda;
}
.image-stage {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    overflow: auto;
}
.preview-image {
    max-width: 90%;
    max-height: 90%;
    object-fit: contain;
    user-select: none;
    transition: transform 0.15s ease;
} /* =========================================================
   TXT
   ========================================================= */
.txt-preview {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background: #fafafa;
}
.txt-toolbar {
    flex: 0 0 38px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 16px;
    border-bottom: 1px solid #e7e4e0;
    color: #99928b;
    background: #f5f4f2;
    font-size: 11px;
}
.txt-language {
    padding: 3px 7px;
    border: 1px solid #e2ded9;
    border-radius: 5px;
    background: #fff;
}
.txt-content {
    display: flex;
    flex: 1;
    min-height: 0;
    overflow: auto;
    font-family: "SFMono-Regular", Consolas, "Liberation Mono", monospace;
    font-size: 13px;
    line-height: 1.7;
}
.line-numbers {
    flex: 0 0 54px;
    padding: 18px 10px;
    box-sizing: border-box;
    color: #bbb5ae;
    background: #f5f4f2;
    text-align: right;
    user-select: none;
}
.line-numbers span {
    display: block;
}
.txt-content pre {
    flex: 1;
    margin: 0;
    padding: 18px 20px;
    box-sizing: border-box;
    color: #44403b;
    white-space: pre;
} /* =========================================================
   Unsupported
   ========================================================= */
.unsupported-preview {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    background: #f7f7f6;
}
.unsupported-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 48px;
    height: 48px;
    margin-bottom: 15px;
    border-radius: 14px;
    color: #81786e;
    background: #eeeae5;
    font-size: 20px;
    font-weight: 600;
}
.unsupported-title {
    color: #514b45;
    font-size: 15px;
    font-weight: 600;
}
.unsupported-text {
    margin-top: 7px;
    color: #aaa49d;
    font-size: 12px;
} /* =========================================================
   Transition
   ========================================================= */
.preview-enter-active,
.preview-leave-active {
    transition: opacity 0.22s ease;
}
.preview-enter-active .preview-window,
.preview-leave-active .preview-window {
    transition:
        transform 0.22s ease,
        opacity 0.22s ease;
}
.preview-enter-from,
.preview-leave-to {
    opacity: 0;
}
.preview-enter-from .preview-window,
.preview-leave-to .preview-window {
    opacity: 0;
    transform: scale(0.98);
}
.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.18s ease;
}
.fade-enter-from,
.fade-leave-to {
    opacity: 0;
} /* =========================================================
   Responsive
   ========================================================= */
@media (max-width: 768px) {
    .preview-modal {
        padding: 0;
    }
    .preview-window {
        max-height: 100vh;
        border-radius: 0;
    }
    .file-actions {
        margin-left: 10px;
    }
    .action-button {
        padding: 0 8px;
    }
    .action-button:not(.primary) {
        font-size: 0;
        width: 32px;
        padding: 0;
    }
    .preview-file-name {
        max-width: 240px;
    }
}

.preview-content {
    position: relative;

    flex: 1 1 auto;

    min-width: 0;
    min-height: 0;

    width: 100%;
    height: 0;

    overflow: hidden;

    background: #f0efed;
}

.render-container {
    position: absolute;

    inset: 0;

    width: 100%;
    height: 100%;

    min-width: 0;
    min-height: 0;

    overflow: hidden;
}

/* =========================================================
   Office 通用容器
   ========================================================= */

.office-wrapper {
    position: relative;

    width: 100%;
    height: 100%;

    min-width: 0;
    min-height: 0;

    overflow: hidden;
}

.office-viewer {
    display: block;

    width: 100% !important;
    height: 100% !important;

    min-width: 0 !important;
    min-height: 0 !important;
}

/* =========================================================
   Word
   ========================================================= */

.office-wrapper--docx {
    overflow: auto;

    background: #e9e8e6;
}

.office-wrapper--docx .office-viewer {
    width: 100% !important;
    min-height: 100% !important;

    height: auto !important;
}

/* =========================================================
   Excel
   ========================================================= */

.office-wrapper--excel {
    width: 100%;
    height: 100%;

    overflow: hidden;

    background: #f5f5f4;
}

.office-wrapper--excel .office-viewer {
    position: absolute;

    inset: 0;

    width: 100% !important;
    height: 100% !important;

    min-width: 100% !important;
    min-height: 100% !important;
}

/*
 * Vue Office Excel 内部结构
 *
 * x-data-spreadsheet
 */

.office-wrapper--excel :deep(.x-spreadsheet) {
    width: 100% !important;
    height: 100% !important;

    min-width: 100% !important;
    min-height: 100% !important;
}

.office-wrapper--excel :deep(.x-spreadsheet-sheet) {
    width: 100% !important;
    height: 100% !important;
}

/* Excel 顶部工具区域 */

.office-wrapper--excel :deep(.x-spreadsheet-toolbar) {
    height: 38px;
}

/* Excel 主体 */

.office-wrapper--excel :deep(.x-spreadsheet-overlayer) {
    width: 100% !important;
    height: 100% !important;
}

/* =========================================================
   PDF
   ========================================================= */

.office-wrapper--pdf {
    width: 100%;
    height: 100%;

    overflow: auto;

    background: #525252;
}

/* =========================================================
   PPTX
   ========================================================= */

.office-wrapper--pptx {
    position: relative;

    width: 100%;
    height: 100%;

    overflow: auto;

    background: #e9e8e6;
}

.office-wrapper--pptx .office-viewer {
    width: 100% !important;
    min-width: 100% !important;

    height: auto !important;
    min-height: 100% !important;
}
</style>
