package com.cmall.shop.config;

import org.jooq.conf.Settings;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JooqConfig {

    // 直接通过 BeanPostProcessor 或简单的 Bean 定义来配置 Settings
    @Bean
    public Settings jooqSettings() {
        return new Settings().withMapRecordComponentParameterNames(true) // 解决 Record 映射的关键
                .withMapConstructorParameterNames(true).withRenderFormatted(true); // 顺便让打印的 SQL 更漂亮
    }
}
