package com.cmall.shop.common;



import com.cmall.shop.dto.PageResult;
import org.jooq.DSLContext;
import org.jooq.SelectLimitStep;
import java.util.List;

public class JooqUtils {
    public static <T> PageResult<T> fetchPage(DSLContext dsl, SelectLimitStep<?> select, int page, int size, Class<T> type) {
        long total = dsl.fetchCount(select);
        List<T> content = select
                .limit(size)
                .offset((page - 1) * size)
                .fetchInto(type);
        return PageResult.of(content, total, page, size);
    }
}