package com.cmall.shop.respository;

import com.cmall.shop.vo.OrderDetailVO;
import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.jooq.Record;
import org.springframework.stereotype.Repository;

import java.util.List;


import static com.cmall.shop.generated.Tables.*;

@Repository
@RequiredArgsConstructor
public class OrderRepository {

    private final DSLContext dsl;

    public List<Record> getOrderDetailByOrderId(String orderId) {
        return dsl.select(
                        ORDERS.ID,
                        ORDERS.ORDER_NO,
                        ORDERS.AMOUNT,
                        PRODUCT.TITLE,
                        ORDER_ITEM.QUANTITY,
                        ORDER_ITEM.UNIT_PRICE
                )
                .from(ORDERS)
                .join(ORDER_ITEM).on(ORDERS.ID.eq(ORDER_ITEM.ORDER_ID))
                .join(PRODUCT).on(PRODUCT.ID.eq(ORDER_ITEM.PRODUCT_ID))
                .where(ORDERS.ORDER_NO.eq(orderId))
                .fetch() // 得到 Result<Record6<...>>
                .map(r -> r); // 显式地将每一行强转为 org.jooq.Record
    }
}
