package com.cmall.shop.component;

import com.cmall.shop.dto.PageResult;
import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.jooq.SelectLimitStep;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class Pager {
    private final DSLContext dsl;

    public <T> PageResult<T> fetchPage(SelectLimitStep<?> query, int page, int size, Class<T> type) {
        long total = dsl.fetchCount(query);
        List<T> content = query.limit(size).offset((page - 1) * size).fetchInto(type);
        return new PageResult<>(content, total, page, size);
    }
}
