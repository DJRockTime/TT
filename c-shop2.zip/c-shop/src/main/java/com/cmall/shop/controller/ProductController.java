package com.cmall.shop.controller;



import com.cmall.shop.dto.Result;
import com.cmall.shop.service.ProductService;
import com.cmall.shop.vo.ProductHealthVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 商品业务接口
 */
@RestController
@RequestMapping("/products")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    /**
     * 挑战接口：查看店铺商品健康诊断报告
     * 测试地址：http://localhost:8080/products/health?shopId=1
     */
    @GetMapping("/health")
    public Result<List<ProductHealthVO>> getProductHealthReport(@RequestParam Long shopId) {
        // 调用你刚刚写好的 Service 逻辑
        List<ProductHealthVO> report = productService.checkShopProductsHealth(shopId);

        // 返回统一的 Result 格式
        return Result.success(report);
    }
}