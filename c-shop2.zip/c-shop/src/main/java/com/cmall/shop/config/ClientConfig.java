package com.cmall.shop.config;

// c-shop/src/main/java/com/cmall/shop/cfg/ClientConfig.java
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

@Configuration
public class ClientConfig {
    @Bean
    public RestClient managerClient() {
        // 设置 c-manager 的基础地址
        return RestClient.builder().baseUrl("http://localhost:8066").build();
    }
}
