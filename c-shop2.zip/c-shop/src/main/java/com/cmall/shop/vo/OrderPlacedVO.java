package com.cmall.shop.vo;

import java.math.BigDecimal;

/**
 * 下单成功返回 VO
 */
public record OrderPlacedVO(
        String orderNo,      // 业务订单号
        BigDecimal totalAmount, // 实付总金额
        String status        // 订单状态（如：待支付）
) {}
