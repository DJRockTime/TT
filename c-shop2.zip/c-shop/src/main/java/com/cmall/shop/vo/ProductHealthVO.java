package com.cmall.shop.vo;

import java.util.List;

public record ProductHealthVO(
        String title,
        Integer stock,
        List<String> tags
) {}
