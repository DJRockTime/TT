package com.cmall.shop.service;

import com.cmall.shop.dto.PageResult;
import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.jooq.SelectLimitStep;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@RequiredArgsConstructor
public abstract class BaseService {
    protected final DSLContext dsl;



    // 将方法放在这里，子类直接继承使用
    public <T> PageResult<T> fetchPage(SelectLimitStep<?> select, int page, int size, Class<T> type) {
        // 注意：fetchCount 会把原本的 select 包装成子查询来算总数
        long total = dsl.fetchCount(select);

        List<T> content = select
                .limit(size)
                .offset((page - 1) * size)
                .fetchInto(type);

        return PageResult.of(content, total, page, size);
    }
}