package com.cmall.shop.service;


import com.cmall.shop.component.Pager;
import com.cmall.shop.dto.OrderDTO;
import com.cmall.shop.dto.PageResult;
import com.cmall.shop.respository.OrderRepository;
import com.cmall.shop.vo.OrderDetailVO;
import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.jooq.Record;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.cmall.shop.generated.Tables.*;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final DSLContext dsl;

    private final Pager pager;

    private final OrderRepository orderRepository;

    public List<OrderDTO> getOrderByShop(Long shopId, int page, int size) {
        return dsl.select(ORDERS.ID, ORDERS.ORDER_NO, ORDERS.AMOUNT, ORDERS.STATUS, ORDERS.CREATED_AT).from(ORDERS).where(ORDERS.SHOP_ID.eq(shopId)).orderBy(ORDERS.CREATED_AT.desc()).limit(size).offset((page - 1) * size).fetchInto(OrderDTO.class);
    }

    public PageResult<OrderDTO> getOrderByShop2(Long shopId, int page, int size) {
        var query = dsl.selectFrom(ORDERS).where(ORDERS.SHOP_ID.eq(shopId)).orderBy(ORDERS.CREATED_AT.desc());
        return pager.fetchPage(query, page, size, OrderDTO.class);
    }


    public OrderDetailVO getOrderDetail(String orderId) {
        var records = orderRepository.getOrderDetailByOrderId(orderId);
        if (records.isEmpty()) {
            return null;
        }

        Record first = records.getFirst();
        List<OrderDetailVO.OrderItemDetailVO> items = records.stream().map(i -> new OrderDetailVO.OrderItemDetailVO(i.get(PRODUCT.TITLE), i.get(ORDER_ITEM.QUANTITY), i.get(ORDER_ITEM.UNIT_PRICE))).toList();

        return new OrderDetailVO(first.get(ORDERS.ID), first.get(ORDERS.ORDER_NO), first.get(ORDERS.AMOUNT), items);
    }
}
