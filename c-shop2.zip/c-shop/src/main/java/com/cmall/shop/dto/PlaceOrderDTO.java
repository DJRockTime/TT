package com.cmall.shop.dto;

import java.math.BigDecimal;

/**
 * 下单请求 DTO
 */
public record PlaceOrderDTO(
        Long userId,
        Long shopId,      // 改为 Long 匹配数据库 ID 类型
        Long productId,   // 改为 Long 匹配数据库 ID 类型
        Integer quantity,
        BigDecimal expectedPrice // 扩展：前端看到的单价，后端用来校验是否发生变价
) {}
