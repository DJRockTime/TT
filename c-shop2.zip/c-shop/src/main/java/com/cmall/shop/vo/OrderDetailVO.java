package com.cmall.shop.vo;

import java.math.BigDecimal;
import java.util.List;

public record OrderDetailVO(Long orderId, String orderNo, BigDecimal totalAmount, List<OrderItemDetailVO> items) {
    public record OrderItemDetailVO(String productName, Integer quantity, BigDecimal unitPrice) {
    }
}
