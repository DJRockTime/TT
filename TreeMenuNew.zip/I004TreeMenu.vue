<template>
  <section class="aside-menu">
    <!-- 搜索框 -->
    <article class="search-box">
      <div class="search-input-wrapper">
        <input
          type="search"
          v-model="searchKeyword"
          placeholder="搜索菜单..."
          @input="filterMenus"
        />
        <i class="icon-search">🔍</i>
      </div>
    </article>

    <!-- 菜单栏 -->
    <article class="main-menu">
      <MenuItem
        v-for="item in filteredRoutes"
        :key="item.meta.id"
        :item="item"
        :level="startLevel"
      />
    </article>
  </section>
</template>

<script setup lang="ts">
import { ref, computed, provide } from "vue";
import MenuItem from "@/views/MenuItem.vue";

interface Props {
  routes?: any[];
  iconLevels?: number[]; // 控制哪些层级显示 icon
  defaultExpanded?: boolean; // 是否默认全部展开
  accordion?: boolean; // 是否手风琴模式
}

const props = withDefaults(defineProps<Props>(), {
  routes: () => [],
  iconLevels: () => [2],
  defaultExpanded: false,
  accordion: true,
});

const emit = defineEmits<{
  (e: "click", item: any): void;
}>();

const activeMenuId = ref<string>(localStorage.getItem("activeMenuId") || "");

const setActiveMenu = (id: string) => {
  activeMenuId.value = id;
  localStorage.setItem("activeMenuId", id);
};

provide("menuActive", {
  activeMenuId,
  setActiveMenu,
});

// ==================== 路由数据（包含 level 1）===================
const systemChildren = [
  {
    path: "#",
    name: "System",
    component: "", // 主布局（包含左侧菜单栏区域）
    redirect: "/system/user", // 默认跳转到第一个子菜单
    meta: {
      id: "1000",
      title: "系统管理",
      icon: "setting",
      label: "系统管理",
      level: 1,
      isShow: true,
      pageId: "system",
      permission: "system:view",
      showInTag: true,
      order: 1,
      auth: true,
    },
    children: [
      // ==================== 模块1：用户管理（三层） ====================
      {
        path: "#",
        name: "UserManage",
        component: "", // 空壳组件，只为占位承载子路由
        meta: {
          id: "1100",
          title: "用户管理",
          icon: "user",
          label: "用户管理",
          level: 2,
          isShow: true,
          pageId: "user-manage",
          permission: "system:user:view",
          showInTag: false, // 一级菜单可不显示在标签页
          order: 1,
          auth: true,
        },
        children: [
          {
            path: "#",
            name: "UserList",
            component: "",
            meta: {
              id: "1110",
              title: "用户列表",
              icon: "list",
              label: "用户列表",
              level: 3,
              isShow: true,
              pageId: "user-list",
              permission: "system:user:list",
              showInTag: true,
              order: 1,
              auth: true,
            },
            children: [
              {
                path: "#",
                name: "UserDetail",
                component: "", // 可以先用空页面
                meta: {
                  id: "1111",
                  title: "用户详情",
                  icon: "",
                  label: "用户详情",
                  level: 4,
                  isShow: false, // 详情页不显示在左侧菜单
                  pageId: "user-detail",
                  permission: "system:user:detail",
                  showInTag: true,
                  order: 1,
                  auth: true,
                },
              },
            ],
          },
          {
            path: "#",
            name: "UserAdd",
            component: "", // 纯空页面用于测试
            meta: {
              id: "1120",
              title: "新增用户",
              icon: "plus",
              label: "新增用户",
              level: 3,
              isShow: true,
              pageId: "user-add",
              permission: "system:user:add",
              showInTag: true,
              order: 2,
              auth: true,
            },
          },
        ],
      },

      // ==================== 模块2：角色管理（三层） ====================
      {
        path: "#",
        name: "RoleManage",
        component: "",
        meta: {
          id: "1200",
          title: "角色管理",
          icon: "team",
          label: "角色管理",
          level: 2,
          isShow: true,
          pageId: "role-manage",
          permission: "system:role:view",
          showInTag: false,
          order: 2,
          auth: true,
        },
        children: [
          {
            path: "#",
            name: "RoleList",
            component: "",
            meta: {
              id: "1210",
              title: "角色列表",
              icon: "unordered-list",
              label: "角色列表",
              level: 3,
              isShow: true,
              pageId: "role-list",
              permission: "system:role:list",
              showInTag: true,
              order: 1,
              auth: true,
            },
            children: [
              {
                path: "#",
                name: "RoleAssign",
                component: "",
                meta: {
                  id: "1211",
                  title: "权限分配",
                  icon: "",
                  label: "权限分配",
                  level: 4,
                  isShow: false,
                  pageId: "role-assign",
                  permission: "system:role:assign",
                  showInTag: true,
                  order: 1,
                  auth: true,
                },
              },
            ],
          },
        ],
      },

      // ==================== 模块3：权限管理（三层） ====================
      {
        path: "#",
        name: "PermissionManage",
        component: "",
        meta: {
          id: "1300",
          title: "权限管理",
          icon: "lock",
          label: "权限管理",
          level: 2,
          isShow: true,
          pageId: "permission-manage",
          permission: "system:permission:view",
          showInTag: false,
          order: 3,
          auth: true,
        },
        children: [
          {
            path: "#",
            name: "MenuManage",
            component: "",
            meta: {
              id: "1310",
              title: "菜单权限",
              icon: "menu",
              label: "菜单权限",
              level: 3,
              isShow: true,
              pageId: "menu-permission",
              permission: "system:permission:menu",
              showInTag: true,
              order: 1,
              auth: true,
            },
          },
          {
            path: "#",
            name: "ApiManage",
            component: "",
            meta: {
              id: "1320",
              title: "接口权限",
              icon: "api",
              label: "接口权限",
              level: 3,
              isShow: true,
              pageId: "api-permission",
              permission: "system:permission:api",
              showInTag: true,
              order: 2,
              auth: true,
            },
          },
        ],
      },
    ],
  },
];

const originalRoutes = ref(systemChildren);
const filteredRoutes = ref([...systemChildren]);
const searchKeyword = ref("");

// 计算起始层级
const startLevel = computed(() => {
  return Math.min(...originalRoutes.value.map((i: any) => i.meta.level));
});

// 搜索过滤（保持不变）
const filterMenus = () => {
  const kw = searchKeyword.value.trim().toLowerCase();
  if (!kw) {
    filteredRoutes.value = [...originalRoutes.value];
    return;
  }
  const deepFilter = (items: any[]): any[] => {
    return items
      .map((item) => {
        if (item.meta.title?.toLowerCase().includes(kw)) return { ...item };
        if (item.children?.length) {
          const children = deepFilter(item.children);
          if (children.length > 0) return { ...item, children };
        }
        return null;
      })
      .filter(Boolean) as any[];
  };
  filteredRoutes.value = deepFilter(originalRoutes.value);
};

// ==================== provide 配置（全部传下去）===================
provide("menuConfig", {
  iconLevels: props.iconLevels,
  defaultExpanded: props.defaultExpanded,
  accordion: props.accordion,
  collapsedArrow: "▶",
  expandedArrow: "▼",
});
</script>

<!-- <style lang="less" scoped>
/* 白色主题样式保持不变（之前已优化） */
.aside-menu {
  width: 240px;
  height: 100%;
  background: #ffffff;
  color: #333333;
  box-shadow: 2px 0 8px rgba(0, 0, 0, 0.05);
  display: flex;
  flex-direction: column;
}
.search-box {
  padding: 16px;
  border-bottom: 1px solid #f0f0f0;
}
.search-input-wrapper {
  position: relative;
}
input[type="search"] {
  width: 100%;
  padding: 10px 36px;
  border-radius: 8px;
  border: 1px solid #e0e0e0;
  background: #f9f9f9;
}
input[type="search"]:focus {
  border-color: #409eff;
  background: #fff;
}
.icon-search {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: #999;
}
.main-menu {
  flex: 1;
  overflow-y: auto;
  padding: 8px 0;
}
</style> -->
<style lang="less" scoped>
.aside-menu {
  width: 240px;
  height: 100%;
  background: #ffffff;
  display: flex;
  flex-direction: column;
  font-size: 14px;
  border-right: 1px solid #eef0f3;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
  // transition: width 0.25s ease;
  will-change: width;
  overflow: hidden;
  flex-shrink: 0; // ★
  transition: width 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

.aside-menu.collapsed {
  width: 0px;
  border-right: none;
  box-shadow: none;
  pointer-events: none;

  .menu-label {
    opacity: 0;
    pointer-events: none;
    transform: translateX(-10px);
  }

  .icon-wrapper {
    width: 100% !important;
    justify-content: center;
  }

  .arrow {
    opacity: 0;
  }

  .menu-slide-enter-active,
  .menu-slide-leave-active {
    transition: none !important;
  }
}

.search-box {
  padding: 20px 16px 16px;
}

.search-input-wrapper {
  position: relative;
}

input[type="search"] {
  width: 100%;
  height: 40px;
  padding: 0 12px 0 40px;
  border-radius: 12px;
  border: 1px solid #dcdee2;
  background: #f8f9fb;
  color: #333;
  font-size: 14px;
  transition: all 0.3s;
  outline: none;

  &:focus {
    border-color: #3963f5;
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(57, 99, 245, 0.1);
  }
}

.icon-search {
  position: absolute;
  left: 14px;
  top: 50%;
  transform: translateY(-50%);
  color: #999;
  font-size: 16px;
}

.main-menu {
  flex: 1;
  overflow-y: auto;
  padding: 8px 0;

  // 自定义滚动条（可选美化）
  &::-webkit-scrollbar {
    width: 6px;
  }
  &::-webkit-scrollbar-thumb {
    background: #c8d0dc;
    border-radius: 3px;
  }
  &::-webkit-scrollbar-thumb:hover {
    background: #a8b5c8;
  }
}
</style>
