<template>
  <div v-if="item.meta.isShow" class="menu-item" :class="{ active: isActive }">
    <div class="menu-title" @click="handleTitleClick">
      <!-- 图标容器：层级缩进 -->
      <div class="icon-wrapper" :style="{ width: `${level * 20 + 40}px` }">
        <i v-if="showIcon" class="menu-icon">
          {{ iconMap[item.meta.icon || ""] }}
        </i>
      </div>

      <!-- 文字 -->
      <span class="menu-label">
        {{ item.meta.title }}
      </span>

      <!-- SVG 箭头 -->
      <svg
        v-if="hasVisibleChildren"
        class="arrow"
        :class="{ expanded: isExpanded }"
        viewBox="0 0 1024 1024"
        width="12"
        height="12"
      >
        <path
          d="M761.056 532.128L421.248 872.064a64 64 0 0 1-90.496-90.56l339.712-339.712a64 64 0 0 1 90.56 90.56z m-90.56-90.56L330.624 101.696A64 64 0 0 1 421.184 11.2l339.776 339.712a64 64 0 0 1-90.56 90.56z"
          fill="#999999"
        />
      </svg>
    </div>

    <transition name="menu-slide">
      <div v-show="hasVisibleChildren && isExpanded" class="submenu">
        <MenuItem
          v-for="child in item.children"
          :key="child.meta.id"
          :item="child"
          :level="level + 1"
        />
      </div>
    </transition>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, inject } from "vue";

const props = defineProps<{
  item: any;
  level: number;
}>();

const emit = defineEmits(["click"]);

const menuConfig = inject("menuConfig", {
  iconLevels: [2],
  defaultExpanded: false,
  accordion: true,
});

const menuActive = inject<{
  activeMenuId: any;
  setActiveMenu: (id: string) => void;
}>("menuActive")!;

// ==================== 本地高亮（互斥、持久）===================
const activeMenuId = ref<string>(
  localStorage.getItem("activeMenuId") || "" // 读取上次高亮
);

// 设置高亮（只在叶子节点点击时调用）
const setActive = (id: string) => {
  activeMenuId.value = id;
  localStorage.setItem("activeMenuId", id);
};

// 当前项是否高亮（严格匹配 ID）
const isActive = computed(() => {
  return props.item.meta.id === menuActive.activeMenuId.value;
});

// ==================== 是否有可见子菜单 ====================
const hasVisibleChildren = computed(() => {
  return props.item.children?.some((c: any) => c.meta.isShow);
});

// ==================== 自动展开：高亮项所在路径全部打开 ====================
const hasActiveInTree = (item: any): boolean => {
  if (item.meta.id === activeMenuId.value) return true;
  if (item.children) {
    return item.children.some(hasActiveInTree);
  }
  return false;
};

const isExpanded = ref(
  menuConfig.defaultExpanded ||
    (hasVisibleChildren.value && hasActiveInTree(props.item))
);

// ==================== 图标控制 ====================
const showIcon = computed(() => {
  return props.item.meta.icon && menuConfig.iconLevels.includes(props.level);
});

// ==================== 点击逻辑 ====================
const handleTitleClick = () => {
  if (hasVisibleChildren.value) {
    // 有子菜单（二级结构层）：只展开/收起，不设置高亮
    isExpanded.value = !isExpanded.value;
  } else {
    // 叶子节点（三级真实页面）：设置高亮 + 触发事件
    menuActive.setActiveMenu(props.item.meta.id);
    emit("click", props.item);
  }
};

const iconMap: Record<string, string> = {
  user: "👤",
  list: "📋",
  plus: "➕",
  team: "👥",
  "unordered-list": "📑",
  lock: "🔒",
  menu: "📖",
  api: "🔌",
  setting: "⚙️",
};
</script>

<style lang="less" scoped>
.menu-item {
  &.active > .menu-title {
    background: linear-gradient(to right, #3963f5, #3963f522);
    color: #3963f5 !important;
    font-weight: 600;
    box-shadow: inset 0 1px 3px rgba(57, 99, 245, 0.15);
  }
}

.menu-title {
  display: flex;
  align-items: center;
  height: 48px;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;

  &:hover {
    background: #f0f4ff;
    color: #3963f5;
    transform: translateX(4px);
  }

  .icon-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-shrink: 0;
    height: 100%;
  }

  .menu-icon {
    font-size: 18px;
    opacity: 0.8;
  }

  .menu-label {
    flex: 1;
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding-left: 20px;
    margin-right: 40px;
  }

  .arrow {
    position: absolute;
    right: 16px;
    transition: transform 0.35s cubic-bezier(0.4, 0, 0.2, 1);

    &.expanded {
      transform: rotate(90deg);
    }
  }
}

.submenu {
  background: #fafbfe;
  overflow: hidden;
}

.menu-slide-enter-active,
.menu-slide-leave-active {
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  max-height: 1200px;
}

.menu-slide-enter-from,
.menu-slide-leave-to {
  max-height: 0;
  opacity: 0;
  transform: translateY(-6px);
}

.menu-slide-enter-to,
.menu-slide-leave-from {
  max-height: 1200px;
  opacity: 1;
  transform: translateY(0);
}
</style>
