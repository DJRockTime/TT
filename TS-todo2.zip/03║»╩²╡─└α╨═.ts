{

    /**
     * 函数中
     * 参数类型，返回值类型，类型推导方式，可选，默认值，this，剩余参数、重载
     */


    // 函数类型
    // 函数function 关键字定义函数
    // 表达式定义
    // 函数入参和返回值（针对这个部分,掌握类型）
    function sum(a: string, b: string): string {
        return a + b;
    }


    type TSum = (a: string, b: string) => string;
    let sum2: TSum = (a: string, b: string): string => {
        return a + b;
    }

    // 常简的类型推导方式
    let name = "rock"

    // 根据返回值来进行类型推导
    type TCallback = (a: string, b: number, c: string) => void


    // void 表示不关心返回的具体类型
    function fn(callback: TCallback) {

    }

    fn((a, b,c) => {
        return "abc"
    })


    let r = [1, 2, 3].forEach((item) => item)


    /**
     * 函数的可选参数 (增加？ 表示可选）（增加 = 表示默认值)
     */
    let toSum = (a: string = "a", b?: string): string => {
        return a + b
    }

    toSum(undefined, 'c')


    /**
     * 函数的剩余参数 (剩余运算符， 类型是数组）
     */
    let total = (...rest: number[]): number => {
        return [...rest].reduce((a, b) => a + b, 0)
    }

    let person = {
        name: 'rock',
        age: 30,
    }

    // 可以采用ts中的typeof, 来获取变量的类型, (ts中的this类型需要手动指定，默认是函数的第一个参数

    function getVal(this: typeof person, key: keyof typeof person)   {
        return this[key]
    }

    getVal.call(person, 'name')


    type TThis = typeof person;
    function getTown(this: TThis, key: keyof TThis): string | number   { // keyof 索引类型查询， 只能查询类型
        return this[key]
    }

    /**
     * 函数的重载 （一般是有限的操作）ts中的重载是伪重载，（类型的俄重载， 而不是逻辑的重载）
     */
    function toArray(value: number): number[];
    function toArray(value: string): string[];
    function toArray(value: number | string): string[] | number[] {
        if(typeof value === 'string') {
            return value.split("");
        } else  {
            return value.toString().split("").map(Number);
        }
    }

    let arr = toArray(123)
}