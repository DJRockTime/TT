/**
 * unknow  是 any 的安全类型， 泛型没有赋予值的时候， 默认就是unknow
 *  TS中 被认为是高级类型 取代 any
 */

{

    let val: unknown = true;


// 默认情况下 unknow 必须要吸纳进行累心过检测才能使用 （类型检查 ， 类型断言）

    function processInput(val: unknown) {
        if (typeof val === 'string') {
            val.toLocaleUpperCase()
        } else if (typeof val === 'number') {
            val.toFixed();
        }
    }

    let name: unknown = 'BEIJING';
    (name as string).toUpperCase();

    type Unionunknow = unknown | string | null | undefined; // unknow 和任何类型 做联合类型都是unknow

    type InterfaceUnknow = unknown & string; // 获取的类型是string 如果是any ，则返回的是any

    type IKeyOf = keyof unknown;  // 不能用keyof 来取unknow 的类型


    // keyof any (string number symbol 可以充当key)

}

