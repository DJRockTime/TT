{
    // & 交叉类型
    // | => ||
    // & => &&

    // | 并集
    // & 交集  ts中的类型交集


    interface Person1 {
        handsome: string;
        n: {
            n: number
        }
    }

    interface Person2 {
        high: string;
        n: {
            b: string
        }
    }

    interface Person3 {
        rich: string;
    }


    let a: string | number;

    type Person4 = Person1 & Person2 & Person3;

    let person3: Person4 = {
        handsome: "handsome",
        high: "high",
        rich: 'rich',
        n: {
            n: 0,
            b: 'b',  // 如果类型冲突，会出现never 情况
        }
    }

    function mixin<T, K> (o1: T, o2: K) {
        return {...o1, ...o2}
    }
    let result =  mixin({a: "abc"}, {a: 123});

    type IMixin = typeof result;
    type IVal = IMixin['a']

    type a = ('number' | 'string') & {}

    type Union<T = boolean> = T | number | string;
    let union: Union<boolean> = true;

}

