{
    /**
     * TS中的类
     * 类本身就可以充当类型， 可以描述实例（类类型）
     * public       （父子，外界）
     * protected   （父子）
     * private  父
     * readonly  仅读属性，只能初始化的时候赋值，后续不能修改（类似const）
     *
     *
     * 类的功能： 主要是实例属性，原型属性，静态属性，属性访问器  get set
     */

    // TS中要求所有的属性，先声明，再使用 （采用修饰符在使用）
    class Circle {


        public x!: number;
        public y?: number;

        constructor( x: number = 0,  y: number = 0) {
            this.x = x;
            this.y = y || 100;
        }
    }

    class Animal {
        constructor(protected readonly name: string = '', public age: number = 0, ...res: any[]) {
        }
    }

    class Cat extends Animal {
        constructor(public name: string = '', public age: number = 0, circle?: typeof Circle) {
            super();
        }
    }

    const tom = new Cat('tom', 18, Circle)
    console.log(tom['name']) // 通过这种方式可以访问私有属性，绕过TS检测
    const animal = new Animal("animal", 100);


    // 类中的Object.defineProperty === 属性访问器
    class Animal2 {
        static habitat = 'earth'
        private sound! : string;
        constructor(protected name: string, public age: number = 0, ...res: any[]) {

        }

        static getHabitat() {
            return Animal2.habitat
        }

        get getSound() {
            return this.sound;
        }

        set setSound(value: string) {
            this.sound  =value
        }

        eat(food: string) {
            console.log('eating...' + food)
        }
    }

    class Cat2 extends Animal2 {
        constructor(protected name: string, public age: number = 0, ...res: any[]) {
            super(name,age);
        }

        eat(food: string) {
            console.log('eating...' + food)
        }
    }


    let anima2 = new Cat2('anima', 18)
    anima2.getSound

    anima2.eat('狗粮食');
    Cat2.getHabitat();


    class Singleton {
        private static instance = new Singleton();
        private constructor() {}

        static getSingleton() {
            return this.instance
        }
    }

    // 抽象类
    // 不能 new
    // 2 抽象类中可以创建属性和方法，让子类来实现，但是静态方法，属性不可以
    // 3 抽象类中可以有具体实现
    abstract class Person {
        static habitat: string = 'rock';
        abstract habitat: string;
        abstract eat() : void; // 没有具体实现，一般表示原型属性
        abstract play: () => void;  // ts中不做区分，但是一般，这种情况描述的是实例方法
    }

    class Girls extends Person {
        public habitat: string = 'rock'
        play!: () => void;
        eat() : void {
            throw new Error('Method not implemented');
        }
    }


    class ToArray {
        convert(value: string ): string[];
        convert(value: number): number[];
        convert(value: number | string) : string[] | number[] {
            if(typeof value === 'string') {
                return value.split("")
            } else {
                return value.toString().split("").map(Number);
            }
        }
    }

}