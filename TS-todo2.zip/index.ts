/**
 * 条件分发
 *
 * 正常情况下，可以通过 A extends B A是B的子类型
 *
 * A欸行是通过泛型传入的
 * 2 A类型如果是联合类型进行分发
 * 3 泛型参数A，必须是全裸露的，才具备分发的能力 （只要让A不是裸类型，就会丧失分发机制）
 *
 */


interface Fish {
    name: 'fish'
}

interface Bird {
    name: 'bird'
}

interface Water {
    name: 'water'
}

interface Sky {
    name: 'sky'
}

type Conditional = Fish | Bird extends Fish ? Water : Sky // 此情况并未产生分发

type Conditional2<T> = T extends Fish ? Water : Sky;

type R1 = Conditional2<Fish>
type R2 = Conditional2<Fish | Bird>  // 将联合类型每一项单独进行比较


// 默认情况下，有些时候我们需要关闭这种分发能能力， 会造成判断不准确

type Conditional3<T, U> = T extends U ? true : false;

// true | false -> boolean
type R3 = Condition3<1 | 2, 1>


// 禁止分发
type NoDistribute<T> = T & {} // 只是为了让这个T产生一个类型
type Conditional4<T, U> = NoDistribute<T> extends U ? true : false;
type Conditional5<T, U> = T[] extends U ? true : false;
type R4 = Conditional4<1 | 2, 1>


// 运算结果进行比较
type Conditional5<T, U> = [T] extends [U] ? true : false;
type R5 = Conditional4<1 | 2, 1>

// 条件判断注意事项
type isNever<T> = [T] extends [never] ? true : false;
type isNever1<T> = T extends never ? true : false;
type isNever2<T> = T & {} extends never ? true : false;
type R6 = isNever2<never> // never 直接比较的时候无法返回正确的值


// 我们在今心类型父子关系比较时，默认请胯下都应该关闭分发

// 分发就是挨个比较， 不想分发就是将结果运算后再比较

// 通过条件类型，ts实现了一些常见内置类型
// 我们在使用TS 的时候，需要安装typescript模块 （包含了很多内置类型）

// 内置1 Extract
type MyExtract<T, U> = T extends U ? T : never;

//  T 和 U 没有硬性关系
type R6 = Extract<1 | 2 | 3, 1 | 2 | 4>

// 内置 Exclude
type MyExclude<T, U> = T extends U ? never : T;
type R7 = Exclude<1 | 2 | 3 | 4 | 5, 2 | 4>

type MyExtract2<T, U> = T extends null | undefined ? never : T;
type x1 = null & {};
type x2 = undefined & {}
type NonNullable<T> = T & {}
type R8 = NonNullable<1 | 2 | null | undefined>

let ele = document.getElementById('app')
type x = NonNullable<typeof ele>


// 可以求联合类型的交集和差集 Extract  Exclude


// infer 类型推断
// 可以再条件类型中提取类型的某一个部分，在使用的时候获取什么类型将他卸载什么 ”地方“ 加一个变量可以自动的来推导, 类型推导都是基于位置的

// 1. 获取函数的返回值类型
function getObj(name: string, age: number) {
    return {name, age}
}

type ReturnType<T extends  (...args: any[]) => any> = T extends (...args: any[]) => infer R ? R : never;

type ReturnType<T> = T extends (...args : any[]) => infer R ? R : never;
type R9 = ReturnType<typeof getObj>;

type ReturnType<T extends  (...args: any[]) => any> = T extends (...args: infer P) => infer P ? P : never;
type R10 = Parameters<typeof getObj>


class A {
    constructor(name: string, age: number) {
    }
}

type ConstructorParameters<T extends new (...args: any[]) => any> = T extends new (...args: infer P) => any ? P : never;

type R11 = ConstructorParameters<typeof A>



abstract  class B {
    constructor(name: string, age: number) ;
}

type ConstructorParameters<T extends abstract new (...args: any[]) => any> = T extends abstract new (...args: infer P) => any ? P : never;

type ConstructorParameters<T extends new (...args: any) => any> = T extends new (...args: infer P) => infer Q ? [P, Q] : never;


type InstanceType<T extends abstract new (...args: any[]) => any> = T extends new (...args: any[]) => infer Q ? Q : never;

type R12 = InstanceType<typeof A>

// 用在创建实例的类型上
function createInstance<T extends new (...args: any[]) => any>(target: T, ...args: ConstructorParameters<T>): InstanceType<T> {
    return new target(...args);
}

createInstance(MyPerson, 'rock', 20)

class MyPerson {
    constructor(public name: string, public  age: number) {}
}

// infer 中实现了很多内置的类型 (ReturnType, Parameters, ConstructorParameters, InstanceType)


// swap
type Swap<T, U> = T extends [infer A1, infer A2] ? [A2, A1] : never;
type R13 = Swap<['jw', 30]>;

type SwapHeadTail<T> = T extends [infer H, ... infer N, infer T] ? [T, ...N, H] : never;
type R14 = SwapHeadTail<1 , 2, 3, 4, 5, 6, 7>; // push pop


// promise 如果翻译一个promise， 会不停的解析这个promise
function getValue(): Promise<100> {
    return new Promsie((resolve) => {
         resolve(100);
    })
}


// 通过infer 来实现递归推导
type PromiseReturnValue<T> = T extends Promise<infer P> ? PromiseReturnValue<P> : T;


type R15 = PromiseReturnValue<Promise<Promise<Promise<100>>>>


// 将元组转化成联合类型 [number, boolean, string] => number | boolean | string;
type TupleToArray = [number, boolean, string ][number];

// 根据位置推导 [number, boolean, string] -> [E
type ElementToUnion<T> = T extends Array<infer E> ? E: never;
type TupleToArray2 = ElementToUnion<[number, boolean, string]>;


// 重构类型的结构 T & K
interface IAddress {
    no: 501;
    x: 100;
    y: 100;
}
interface Person {
    name: string;
    age: number;
    address: IAddress;
}

type Partial<T> = { // for key in name | age
    [K in keyof T]?: T[K]; // 通过索引查询，拿到值
}

type DeepPartial<T> = {
    [K in keyof T]?: T[k] extends object ? DeepPartial<T[K]> : T[K]
}

type PartialPerson = DeepPartial<Person>; // 循环所有的属性 增加可选参数
let person: PartialPerson= {
    name: 'rock',
    address: {
        n: 501,
        a: 101
    }
}

type Required<T> = {
    [K in keyof T]-?:  T[K]
}
// Required 只有第一层  就是将可选属性去掉
let person2 : Required<PartialPerson> = {
    name: 'rock',
    age: 30,
    address: {

    }
}

type Readonly<T> = {
   readonly [K in keyof T]:  T[K]
}
let person3: Readonly<Required<PartialPerson>> = {
    name: 'rock',
    age: 30,
    address: {},
}

type Mutate<T> = {
    -readonly [K in keyof T]: T[K]
}

let person4: Mutate<Required<PartialPerson>> = {
    name: 'rock',
    age: 30,
    address: {},
}


// Pick Omit 重构对象结构， 可以采用这两个类型




type Pick<T, K extends keyof T> = {
    [Key in K]: T[K]
}

type PickPerson = Pick<Person, 'name' | 'age'>
let pesron: PickPerson;


// 在很多属性中挑选需要的， 在很多属性中排除不需要的

type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>

type OmitPerson = Omit<Person, 'address'>
let person5: OmitPerson;

// 映射类型， Pick + Omit 配合 Extract 和 Exclude 可以实现各种各样的类型


// 针对这种情况， 应该将B有的属性， 再A里面移除掉
function mixin<T extends object, K extends object>(a: T, b: K): Omit<T, keyof K>  & K {
    return {...a, ...b};
}

let x = mixin({name: "rock", age: 30, c: 3}, {name: 123, age: 30, b: 2});


type Computed<T> = { // 通过这种创建一个新的对象方式更加直观的看结果
    [K in keyof T]: T[K];
}

type nameType = (typeof x)['name'];
type nameType = Computed<typeof x>


// keyof 取 Key
// typeof 取类型
// 索引查询 []
// in 循环
// extends 条件


// 一些映射类型可以采用Record类型
// 只想要 key value 格式的，可以采用 Record
type Record<K extends keyof any, V> = {[P in K]: V}
// 任意对象接口
let person6: Record<string, any> = []


function map(obj: any, callback:(...args: any[]) => any) {
    let result = {} as any
    for (let k in obj) {
        result[key] = callback(obj[key], key)
    }
    return result;
}

let mapResult = map({name: 'rock', age: 30}, (value, index) => {
    return 'abc'
})

// 内置类型： 基于循环： （映射类型 xxx in ）
// Partial Required Readonly 属性修饰符 ？ readonly
// Pick Omit Record








