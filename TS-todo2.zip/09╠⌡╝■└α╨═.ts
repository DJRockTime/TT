/**
 * 条件类型
 * 和泛型约束通常一起使用，类似三元运算符
 *
 *
 * 类型兼容
 */

{
    type ResStatusMessage<T extends number> = T extends 200 | 204 | 206 ? 'success' : 'fail'

    type R1 = ResStatusMessage<200>

    type Conditional<T, U> = T extends U ? 'success' : 'fail'
    type R2 = Conditional<'rock', string>
    type R3 = Conditional<'rock', number>


    interface Fish {
        name: 'fish'
    }

    interface Bird {
        name: 'bird'
    }

    interface Water {
        name: 'water'
    }

    interface Sky {
        name: 'sky'
    }

    type Conditional1<T> = T extends Bird ? Sky : Water;
    type R4 = Conditional1<Fish>

    type FormatReturnVal<T extends string | number | boolean> = T extends string ? string : T extends number ? number : never

    // 泛型一般代表输入不确定的（无限的）约束， 函数重载一般是有限的
    function sum<T extends number | string>(a: T, b: T): FormatReturnVal<T> {
        // 泛型类型之间蹦年做 数学运算
        return a + (b as any); // T + T
    }

    let r = sum(1, 2)


    // 我们知道了 条件运算符，既可以掌握ts中的兼容性，以及类型的层级
    // 兼容性 ： 就是可有将一个值赋予给某个值
    // 类型层级： 低的层级可以赋予给高的层级

    type k1 = 'abc' extends string ? true : false;
    type K2 = 123 extends number ? true : false;
    type K3 = true extends boolean ? true : false;

    let k1: string = 'abc'
    let k2: number = 123;

    type kk = 'abc' extends string ? true : false;
    type kk2 = '123' extends number ? true : false;
    type kk3 = true extends boolean ? true : false;

    type kk11 = 'abc' extends 'a' | 'b' | 'c' ? true : false;
    type kk222 = '123' extends 1 | 2 | 3 ? true : false;
    type kk333 = true extends true | false ? true : false;


    // never 是最小的类型
    // 字面类型可以赋予给字面量的联合类型
    // 字面量类型可以赋予给基础类型
    // any unknow 是最大的类型
    // 基础类型是包装类型的子类型

    // never < 字面量 < 字面量联合类型 | 字面量类型 < 基础数据类型 < 包装类型 < Object < any | unknow
    let r4: 'a' | 'b' | 'c' = 'a'

    type $7 = string extends String ? true : false;
    type $8 = number extends Number ? true : false;
    type $9 = boolean extends Boolean ? true : false;
    type $10 = Object extends any ? true : false;
    type $11 = Object extends unknown ? true : false;


    // never < 字面量 < 字面量联合类型 | 字面量类型 < 基础数据类型 < 包装类型 < Object < any | unknow
    type $14 = any extends Object ? true : false; // true | false; -> boolean
    // 针对 any 来说， 永远返回的是成功和失败的联合类型

    type $15 = unknown extends 'abc' ? true : false;
    let a: unknown = 'abc'

    type $16 = any extends any ? true : false; // 自己和自己比不会出错


    // 类型层面上， 第类型 可以赋予高类型
    // 从结构上考虑， 交叉类型，可以赋予交叉前的类型

    // {} （字面量， 也是一个空对象） object （只能赋予对象） Object (万物皆对象）
    type $17 = {} extends object ? true : false;
    type $18 = {} extends Object ? true : false;

    // 结构上考虑
    type $19 = object extends {} ? true : false;
    type $20 = Object extends {} ? true : false;

    // ts 默认小的object 和 Object 都可以相互赋值
    type $21 = Object extends object ? true : false;
    type $22 = object extends Object ? true : false;
}