// 字符串 number 布尔
let username: string = "rock"
let age: number = 30;
let handsome: boolean = false;


// 数组
let arr: number[] = [1, 2, 3]
let arr2: string[] = ["1", "2", "3"];
let arr3: (number | string)[] = [1, "2", 2]
let arr4: Array<number | string> = [1, 2, 3];


// 元组   规定长度和存储的类型
let tuple1: [string, number, boolean] = ['rock', 30, true]
let tuple2: readonly [string, number, boolean] = ['rock', 30, true] // 只读
// 添加智能添加元素中已经存在的类型
tuple1.push("abc") // 为了安全， 因为不确定这个值是否存在
tuple1.push(3);


// 枚举类型 自带类型的对象, 自动增长, 数字里欸选哪个的美剧，可以反举
enum USER_ROLE {
    USER,
    ADMIN,
    MANAGER,
    OTHER = "ABD" // 异构枚举
}

console.log(USER_ROLE[0]);


const enum BOOKMARK_ROLE {
    USER,
    ADMIN,
    MANAGER,
    OTHER,
}

console.log(BOOKMARK_ROLE.ADMIN);


// null 和 undefined
// 任何类型的子烈性，一般情况下 都是严格模式， null 和 undefined 只能赋值给 null 和 undefined


// void 代表函数的返回值为空， 旨在函数中使用
function fn(): void {
    return undefined;
}


// never 类型
// 任何类型的子类型  1. 报错， 2. 永远达不到， 3. 类型保护
// function fn1(): never {
//     return new Error();
// }

// 类型保护，保障程序的不缺失
// function fn2(value: string | number | boolean): never {
//     if (typeof value === "string") {
//         return value;
//     }
//     if (typeof value === "number") {
//         return value;
//     }
//     if (typeof value === `boolean`) {
//         return value;
//     }
// }

// never 和其它类型做联合类型最终是不显示的
let union: string | number | boolean | never;

// object: 对象类型
// object, {} , Object
// {} Object 不采用，偶尔使用{} 表示对象上任何属性

let obj: Object = {} // 最大范围
let obj2: {} = '123'
let obj3: {} = {}


// object 非基础类型
const create = (target: object) => {}
create(function (){})
create({})
create([])


// Symbol BigIng es6新增的
let s1  = Symbol("1")
let s2  = Symbol("2")


let b1 = Symbol.for("3")
let b2 = Symbol.for("3")
console.log(b1 === b2)


// bigint
let bb: bigint = BigInt(Number.MAX_SAFE_INTEGER + 100)


// any 任何类型， anyScript  有时候我们要对类型做转化， 无法直接转化， 认为这个值可以赋予任何类型
// 出问题自己管

let anyVariable; // 生命一个变量，不给类型默认就是any类型
// ts 会根据你赋予的值来进行类型推导

// string number boolean null undefined array tuple never object symbol bigint any void




