{
    // let 和 const 的区别
    const age: number | string = 30
    let ss: number | string;

    // 默认没有赋值的时候可以 联合类型可以调用公共的方法，why ？
    ss!.toString();

    let tt: string | number;

    tt = 'rock'
    tt.toUpperCase();
    tt = 30
    tt.toFixed(); // 复制后会推断类型

    // li安和类型 一般我们会基于联合类型。来扩展额外的类型

    // 字面量的类型， type 可以声明一个类型
    type Direction = "UP" | "DOWN" | "LEFT" | "RIGHT";
    let direction: Direction = "UP";

    // type 中定义的是类型，不是js中的对象
    type  women = | {
        wealthy: true;
        waste: string;
    }
        | {
        wealthy: false;
        norality: string
    }

    let richWoman: women = {
        wealthy: true,
        waste: "购物和消费"
    };
    let poorwoman: women = {
        wealthy: false,
        norality: "勤俭持家"
    }

    // 可以利用联合类型来做属性之间的互斥（可辨识联合类型）


    // 断言 (非空断言)
    let name2: string | number;


    let ele: HTMLElement | null = document.querySelector(("app"))
    ele!.style.background = 'red'


    // as 断言可以强制把某个类型断言成已经存在的俄某个类型
    let cc: HTMLElement | null = document.querySelector("#app");
    (cc as HTMLElement).style.background = 'red';
    (<HTMLElement>cc).style.background = 'red'; // 不推荐回合 jsx 语法冲突


    // 断言除了问题，后果需要自付， 有可能会出问题


    // 双重断言 我们可以把一个值 断雁城any 再断雁城某个类型
    // any 类型可以赋值任何类型

    let str: string | number | boolean;
    str! as any as boolean


}