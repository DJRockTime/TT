{
    class Animal {
        constructor(public name: string, public age: number) {

        }
    }

    class Person {
        constructor(public name: string, public age: number) {
        }
    }


    // 1
    type IClass = new (name: string, age: number) => any;

    // 2
    interface IClazz<T> {
        new(name: string, age: number): T
    }

    // function createInstance(target: typeof Animal, name: string, age: number) {
    function createInstance<T, K>(target: IClazz<T>, name: K, age: number) {
        return new target(name as string, age);
    }

    // ts中再使用的时候确定类型，可以通过反省，（传递的是类型)  T K U M N O P
    const animal = createInstance<Person, string>(Person, 'Cat', 18)


    // 根据提供的数据生成对应长度的数组
    function createArray<T>(len: number, val: T) {
        let result = [] as T[]
        for (let i = 0; i < len; i++) {
            result.push(val);
        }

        return result;
    }

    let r = createArray(3, 'abc');

    // 多个泛型 > 2
    createArray(3, 'abc')


    type TSwap = <T, K>(tuple: [T, K]) => [K, T];

    function swap<T, K>(tuple: [T, K]): [K, T] {
        return [tuple[1], tuple[0]];
    }

    let swap2: TSwap = (tuple) => {
        return [tuple[1], tuple[0]];
    }

    swap(['abc', 123])

    /**
     * 泛型使用的时候直接传递累心给，可以直接推导，但是内部调用的时候没有确定类型
     */
    type ICallback<T> = (item: T, index: number) => void;
    type IforEach = <T>(arr: T[], callback: ICallback<T>) => void;
    const forEach: IforEach = (arr, callback) => {
        for (let i = 0; i < arr.length; i++) {
            callback(arr[i], i)
        }
    }
    // const forEach = <T>(arr: any[], callback: (item: T, index: number) => void) => {
    //     for (let i = 0; i < arr.length; i++) {
    //         callback(arr[i], i)
    //     }
    // }
    // 写在前面， 就是表示适用类型的时候传参，写道函数的前面意味着调用函数的时候传递参数
    forEach([1, 2, 3, 'a', 'b', 'c'], function (item, index) {
    })



    // 泛型是有默认值的
    // 在一些联合类型的时候，会使用泛型

    type Union<T = boolean> = T | number | string;
    let union: Union = true;

    // 泛型约束 要求传递的参数必须符合要求， A extends B 要求， A 是 B的子类型或者同类型

    function handle<T extends string | number>(val: T):T {
        return val;
    }

    let right = handle('abc');

    interface IWithLen {
        length: number;
    }

    function handle2<T extends IWithLen> (val: T) { // 只要泛型中有length 属性即可
        return val.length;
    }

    handle2({a: 1, b: 2, length: 23})


    class Parent {
        house(){}
    }

    class Child extends Parent {
        car() {

        }
    }

    // K extends 'name' | 'age'
    function getVal<T, K extends keyof T>(obj: T, key: K) {
        return obj[key]
    }

    // 父子继承， 对于对象而言，儿子的类型结构是比父亲多的
    getVal({name: 'rock', age: 30}, 'name')


    interface IResponse<T> {
        code: number;
        message?: string;
        data: T
    }


    interface ILoginData {
        token: string;
        roles: number[]
    }

    // 通过泛型坑位 来占位置
    function toLogin(): IResponse<ILoginData> {
        return {
            code: 200,
            data: {
                token: "token",
                roles: [1, 2, 3]
            }
        }
    }

    class MyArray<T> {
        private array: T[] = [];
        set(val: T) {
            this.array.push(val)
        }
        getMax():T {
            let arr = this.array;
            let max=  arr[0];
            for (let i = 0; i < arr.length; i++) {
                let current = arr[i]
                current > max ? max = current : void 0;
            }

            return max;
        }
    }

    // 获取最大值
    let myArray = new MyArray<number | string>();
    myArray.set(200);
    myArray.set(100);
    myArray.set(300);
    console.log(myArray.getMax())

}