{
    /**
     * 不能有具体实现，可以描述对象，类，函数，混合类型
     *
     * type 和 interface 的区别
     * 1. 如果只是用来描述结构，我们采用interface
     * 2. 如果涉及的联合类型，我们使用 type 来进行生命
     * 3. type 不能进行扩展， interface 是可以扩展
     * 4. type 不能重名， interface 重名可以合并
     * 5. type 再后学的学习中可以使用循环和条件，interface 不行
     * 其他情况下无所谓，可以互换， （函数类型一般采用type来声明）
     */

    type TFullName = {
        firstName: string,
        lastName: string,
    }

    interface IFullName {
        firstName: string;
        lastName: string;
    }

    type TFn = (obj: IFullName) => string;

    const fullname: TFn = ({firstName, lastName}: IFullName): string => {
        return firstName + lastName;
    }

    // 可以通过接口来声明混合类型
    type TFn2 = {
        (): Number;
        count: number;
    }
    const click: TFn2 = () => {
        return click.count++

    }
    // 为了防止这个click函数 ，被重新赋值，let是可以修改的，如果使用const就不一样了
    click.count = 0;

    // 一般情况下 使用接口大概率都是描述对象
    interface IVeg {  // 接口中声明的都是抽象的，而且必须要实现
        readonly color: string
        size: number
        taste?: 'sweet' | 'sour' // 可选属性
        [key: string]: any // 任意类型， key类型为string 时，可以赋予number， string， symbol
    }

    interface IVeg {
        a: number
    }

    interface IV extends IVeg {
        b?: 1
    }

    const tomato: IVeg = {
        color: 'red',
        size: 20,
        taste: 'sour',
        a: 1,
        1: 999,
        [Symbol()]: 'abc'
    } as IVeg


    let obj = {
        color: 'red',
        size: 20,
        taste: 'sour',
        a: 1
    }

    // 1. 如果对象中的属性，多于接口可以直接采用断言方式来赋值
    // 2. 可以基于原接口扩展
    // 3. 产生新的类型，通过继承原有属性的方式
    // 4. 类型兼容  const aa: IVeg = obj;
    // 5. 交叉类型 &
    // 6. 通过任意类型扩展（常用于一部分格式的的固定，一部分不固定）


    interface Person {
        name: string;

        [key: string]: any;// 值只能是string
    }

    let p: Person = {
        name: 'rock',
        age: 30,
    }

    let p2: Person = {name: 'rock', age: 30}

    interface IArr {
        [key: number]: any;
    }

    let arr1: IArr = {
        0: 1,
        1: 2,
        2: 3
    }

    let arr2: IArr = [1, 2, 3]


    // 通过索引访问符号， 可以取值的类型
    type PersonNameType = Person['name']
    type PersonAnyType= Person[string];

    // 通过keyof 取一个对象中的key 的集合， valueOf （自己实现） 取值的类型集合
    interface ICar {
        color: string;
        a: 1;
        b: 2;
    }
    type ValueOf = keyof Person & {};
    type valueOfB = ICar[keyof ICar] // 通过索引操作符获取值的集合

    // 接口 readonly ? 任意类型 [key:string]  : any  接口[属性key]

    interface ChineseSpeakable {
        speakChinese : () => void;
    }

    interface EnglishSpeakable {
        speakEnglish: () => void;
    }

    class Speak implements ChineseSpeakable, EnglishSpeakable{
        speakChinese(): void {
            throw new Error("methods not implemented.");
        }

        speakEnglish(): void {
            throw new Error("methods not implemented.");
        }
    }

    // 接口可以被类实现多个接口，描述类中的原型方法 和 实例属性
    interface MySpeak extends Speak { // 可以通过接口基于类来扩展

    }

}