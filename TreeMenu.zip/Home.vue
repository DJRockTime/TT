<template>
  <div style="height: 100vh; background: #f0f2f5; padding: 20px">
    <AsideMenu
      :icon-levels="[2]"
      :default-expanded="false"
      :accordion="true"
      @click="onMenuClick"
    />
  </div>
</template>

<script setup lang="ts">
import AsideMenu from "@/views/I004TreeMenu.vue";

const onMenuClick = (data: any) => {
  console.log("🚀 点击菜单项:", data);
};

// src/utils/generateMenuRoutes.ts  (推荐单独文件，便于复用)

function generateMenuRoutes(startLevel: number = 1): any[] {
  // 原始完整路由数据（四层结构）
  const fullRoutes = [
    {
      path: "#",
      meta: {
        id: "1000",
        title: "系统管理",
        icon: "setting",
        level: 1,
        isShow: true,
      },
      children: [
        {
          path: "#",
          name: "UserManage",
          meta: {
            id: "1100",
            title: "用户管理",
            icon: "user",
            level: 2,
            isShow: true,
          },
          children: [
            {
              path: "#",
              name: "UserList",
              meta: {
                id: "1110",
                title: "用户列表",
                icon: "list",
                level: 3,
                isShow: true,
              },
              children: [
                {
                  path: "#",
                  name: "UserDetail",
                  meta: {
                    id: "1111",
                    title: "用户详情",
                    level: 4,
                    isShow: false,
                  },
                },
              ],
            },
            {
              path: "#",
              name: "UserAdd",
              meta: {
                id: "1120",
                title: "新增用户",
                icon: "plus",
                level: 3,
                isShow: true,
              },
            },
          ],
        },
        {
          path: "#",
          name: "RoleManage",
          meta: {
            id: "1200",
            title: "角色管理",
            icon: "team",
            level: 2,
            isShow: true,
          },
          children: [
            {
              path: "#",
              name: "RoleList",
              meta: {
                id: "1210",
                title: "角色列表",
                icon: "unordered-list",
                level: 3,
                isShow: true,
              },
              children: [
                {
                  path: "#",
                  name: "RoleAssign",
                  meta: {
                    id: "1211",
                    title: "权限分配",
                    level: 4,
                    isShow: false,
                  },
                },
              ],
            },
          ],
        },
        {
          path: "#",
          name: "PermissionManage",
          meta: {
            id: "1300",
            title: "权限管理",
            icon: "lock",
            level: 2,
            isShow: true,
          },
          children: [
            {
              path: "#",
              name: "MenuManage",
              meta: {
                id: "1310",
                title: "菜单权限",
                icon: "menu",
                level: 3,
                isShow: true,
              },
            },
            {
              path: "#",
              name: "ApiManage",
              meta: {
                id: "1320",
                title: "接口权限",
                icon: "api",
                level: 3,
                isShow: true,
              },
            },
          ],
        },
      ],
    },
  ];

  // 如果要从二级开始，直接返回一级菜单的 children
  if (startLevel === 2) {
    return fullRoutes[0]!.children || [];
  }

  // 默认返回完整路由（level 1 开始）
  return fullRoutes;
}

void generateMenuRoutes;
</script>

<style scoped></style>
