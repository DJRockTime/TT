<!-- <template>
  <div
    v-if="item.meta.isShow"
    class="menu-item"
    :class="{ active: isActive, [`level-${level}`]: true }"
  >
    <div
      class="menu-title"
      :style="{ paddingLeft: `${(level - startLevel) * 20}px` }"
      @click="handleTitleClick"
    >
      <i v-if="showIcon" class="menu-icon">{{
        iconMap[item.meta.icon || ""]
      }}</i>
      <span class="menu-label">{{ item.meta.title }}</span>
      <i
        v-if="hasVisibleChildren"
        class="arrow"
        :class="{ expanded: isExpanded }"
      >
        {{ isExpanded ? expandedArrow : collapsedArrow }}
      </i>
    </div>

    <transition name="menu-slide">
      <div v-show="hasVisibleChildren && isExpanded" class="submenu">
        <MenuItem
          v-for="child in item.children"
          :key="child.meta.id"
          :item="child"
          :level="level + 1"
        />
      </div>
    </transition>
  </div>
</template> -->

<template>
  <div v-if="item.meta.isShow" class="menu-item" :class="{ active: isActive }">
    <div class="menu-title" @click="handleTitleClick">
      <!-- 图标容器：层级缩进 -->
      <div class="icon-wrapper" :style="{ width: `${level * 20 + 40}px` }">
        <i v-if="showIcon" class="menu-icon">{{
          iconMap[item.meta.icon || ""]
        }}</i>
      </div>

      <!-- 文字：固定起点，所有文字完美垂直对齐 -->
      <span class="menu-label">
        {{ item.meta.title }}
      </span>

      <!-- SVG 箭头：固定在文字右侧 -->
      <svg
        v-if="hasVisibleChildren"
        class="arrow"
        :class="{ expanded: isExpanded }"
        viewBox="0 0 1024 1024"
        width="12"
        height="12"
      >
        <path
          d="M761.056 532.128L421.248 872.064a64 64 0 0 1-90.496-90.56l339.712-339.712a64 64 0 0 1 90.56 90.56z m-90.56-90.56L330.624 101.696A64 64 0 0 1 421.184 11.2l339.776 339.712a64 64 0 0 1-90.56 90.56z"
          fill="#999999"
        />
      </svg>
    </div>

    <transition name="menu-slide">
      <div v-show="hasVisibleChildren && isExpanded" class="submenu">
        <MenuItem
          v-for="child in item.children"
          :key="child.meta.id"
          :item="child"
          :level="level + 1"
        />
      </div>
    </transition>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, inject } from "vue";

const props = defineProps<{
  item: any;
  level: number;
}>();

const emit = defineEmits(["click"]);

const menuConfig = inject("menuConfig", {
  iconLevels: [2],
  defaultExpanded: false,
  accordion: true,
  collapsedArrow: "▶",
  expandedArrow: "▼",
});

const startLevel = inject("startLevel", 1);

// ==================== 本地高亮（测试阶段）===================
const activeMenuId = ref(localStorage.getItem("activeMenuId") || "");

const setActiveMenu = (id: string) => {
  activeMenuId.value = id;
  localStorage.setItem("activeMenuId", id);
};

const isActive = computed(() => props.item.meta.id === activeMenuId.value);

// ==================== 展开状态 ====================
const hasVisibleChildren = computed(() =>
  props.item.children?.some((c: any) => c.meta.isShow)
);

const isChildActive = (item: any): boolean => {
  if (item.meta.id === activeMenuId.value) return true;
  return item.children?.some(isChildActive) || false;
};

const isExpanded = ref(
  menuConfig.defaultExpanded ||
    (hasVisibleChildren.value && isChildActive(props.item))
);

// ==================== 图标控制 ====================
const showIcon = computed(() => {
  return props.item.meta.icon && menuConfig.iconLevels.includes(props.level);
});

// ==================== 点击处理 ====================
const handleTitleClick = () => {
  if (hasVisibleChildren.value) {
    isExpanded.value = !isExpanded.value;
  } else {
    setActiveMenu(props.item.meta.id);
    emit("click", props.item);
  }
};

// const { collapsedArrow, expandedArrow } = menuConfig;

const iconMap: Record<string, string> = {
  user: "👤",
  list: "📋",
  plus: "➕",
  team: "👥",
  "unordered-list": "📑",
  lock: "🔒",
  menu: "📖",
  api: "🔌",
  setting: "⚙️",
};
</script>

<!-- <style lang="less" scoped>
/* 高亮、hover、动画样式保持之前优化版 */
.menu-item.active > .menu-title {
  background: #e6f7ff !important;
  color: #409eff !important;
  font-weight: 600;
  border-left: 3px solid #409eff;
}
.menu-title {
  display: flex;
  align-items: center;
  height: 44px;
  cursor: pointer;
  transition: all 0.2s;
  border-left: 3px solid transparent;
  &:hover {
    background: #f5f7fa;
    color: #409eff;
  }
}
.menu-icon {
  width: 24px;
  text-align: center;
  margin-right: 8px;
}
.menu-label {
  flex: 1;
}
.arrow {
  margin-right: 12px;
  font-size: 12px;
  transition: transform 0.3s;
  &.expanded {
    transform: rotate(90deg);
  }
}
.submenu {
  background: #fafafa;
  overflow: hidden;
}

/* 丝滑动画 */
.menu-slide-enter-active,
.menu-slide-leave-active {
  transition: max-height 0.4s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.35s ease,
    transform 0.4s ease;
  overflow: hidden;
  max-height: 1000px;
}
.menu-slide-enter-from,
.menu-slide-leave-to {
  max-height: 0;
  opacity: 0;
  transform: translateY(-8px);
}
.menu-slide-enter-to,
.menu-slide-leave-from {
  max-height: 1000px;
  opacity: 1;
  transform: translateY(0);
}
</style> -->
<!-- <style lang="less" scoped>
.menu-item {
  &.active > .menu-title {
    background: linear-gradient(to right, #3963f5, #3963f522);
    color: #3963f5 !important;
    font-weight: 600;
    border-left: 4px solid #3963f5;
    box-shadow: inset 0 1px 3px rgba(57, 99, 245, 0.15);
  }
}

.menu-title {
  display: flex;
  align-items: center;
  height: 48px;
  padding: 0 16px;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  border-left: 4px solid transparent;
  position: relative;

  &:hover {
    background: #f0f4ff;
    color: #3963f5;
    transform: translateX(4px); // 轻微右移，超有质感
  }

  .menu-icon {
    width: 24px;
    text-align: center;
    margin-right: 12px;
    font-size: 18px;
    opacity: 0.8;
  }

  .menu-label {
    flex: 1;
    font-weight: 500;
  }

  .arrow {
    margin-left: auto;
    margin-right: 8px;
    font-size: 12px;
    transition: transform 0.3s ease;
    color: #999;

    &.expanded {
      transform: rotate(90deg);
    }
  }
}

.submenu {
  background: #fafbfe;
  border-left: 1px solid #eef0f3;
  margin-left: 16px;
  overflow: hidden;
}

/* 超丝滑展开动画 */
.menu-slide-enter-active,
.menu-slide-leave-active {
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  max-height: 1200px;
}

.menu-slide-enter-from,
.menu-slide-leave-to {
  max-height: 0;
  opacity: 0;
  transform: translateY(-6px);
}

.menu-slide-enter-to,
.menu-slide-leave-from {
  max-height: 1200px;
  opacity: 1;
  transform: translateY(0);
}
</style> -->
<!-- <style lang="less" scoped>
.menu-item {
  &.active > .menu-title {
    background: linear-gradient(to right, #3963f5, #3963f522);
    color: #3963f5 !important;
    font-weight: 600;
    border-left: 4px solid #3963f5;
    box-shadow: inset 0 1px 3px rgba(57, 99, 245, 0.15);
  }
}

.menu-title {
  display: flex;
  align-items: center;
  height: 48px;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;

  &:hover {
    background: #f0f4ff;
    color: #3963f5;
    transform: translateX(4px);
  }

  .menu-icon {
    width: 24px;
    text-align: center;
    margin-right: 12px;
    font-size: 18px;
    opacity: 0.8;
  }

  .menu-label {
    flex: 1;
    font-weight: 500;
  }

  /* SVG 箭头样式 */
  .arrow {
    margin-left: auto;
    margin-right: 16px;
    transition: transform 0.35s cubic-bezier(0.4, 0, 0.2, 1);
    flex-shrink: 0;

    &.expanded {
      transform: rotate(90deg); /* 右 → 下 */
    }
  }
}

.submenu {
  background: #fafbfe;
  overflow: hidden;
}

/* 保持原来的丝滑动画 */
.menu-slide-enter-active,
.menu-slide-leave-active {
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  max-height: 1200px;
}

.menu-slide-enter-from,
.menu-slide-leave-to {
  max-height: 0;
  opacity: 0;
  transform: translateY(-6px);
}

.menu-slide-enter-to,
.menu-slide-leave-from {
  max-height: 1200px;
  opacity: 1;
  transform: translateY(0);
}
</style> -->
<!-- <style lang="less" scoped>
.menu-item {
  &.active > .menu-title {
    background: linear-gradient(to right, #3963f5, #3963f522);
    color: #3963f5 !important;
    font-weight: 600;
    border-left: 4px solid #3963f5;
    box-shadow: inset 0 1px 3px rgba(57, 99, 245, 0.15);
  }
}

.menu-title {
  display: flex;
  align-items: center;
  height: 48px;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;

  &:hover {
    background: #f0f4ff;
    color: #3963f5;
    transform: translateX(4px);
  }

  /* 图标：固定宽度，紧贴文字左侧，不参与缩进 */
  .menu-icon {
    width: 24px;
    text-align: center;
    font-size: 18px;
    opacity: 0.8;
    flex-shrink: 0;
    margin-left: 8px; /* 可微调图标与左边界的距离 */
  }

  /* 文字：纯文字缩进基准，每层 +20px */
  .menu-label {
    flex: 1;
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* SVG 箭头 */
  .arrow {
    margin-left: auto;
    margin-right: 16px;
    transition: transform 0.35s cubic-bezier(0.4, 0, 0.2, 1);
    flex-shrink: 0;

    &.expanded {
      transform: rotate(90deg);
    }
  }
}

.submenu {
  background: #fafbfe;
  overflow: hidden;
}

/* 动画保持不变 */
.menu-slide-enter-active,
.menu-slide-leave-active {
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  max-height: 1200px;
}

.menu-slide-enter-from,
.menu-slide-leave-to {
  max-height: 0;
  opacity: 0;
  transform: translateY(-6px);
}

.menu-slide-enter-to,
.menu-slide-leave-from {
  max-height: 1200px;
  opacity: 1;
  transform: translateY(0);
}
</style> -->
<style lang="less" scoped>
.menu-item {
  &.active > .menu-title {
    background: linear-gradient(to right, #3963f5, #3963f522);
    color: #3963f5 !important;
    font-weight: 600;
    box-shadow: inset 0 1px 3px rgba(57, 99, 245, 0.15);
  }
}

.menu-title {
  display: flex;
  align-items: center;
  height: 48px;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;

  &:hover {
    background: #f0f4ff;
    color: #3963f5;
    transform: translateX(4px);
  }

  /* 图标容器：负责层级缩进，图标居中 */
  .icon-wrapper {
    width: 40px; /* 图标区固定宽度 */
    display: flex;
    justify-content: center;
    align-items: center;
    flex-shrink: 0;
  }

  .menu-icon {
    font-size: 18px;
    opacity: 0.8;
  }

  /* 文字：固定左边距，所有文字对齐同一垂直线 */
  .menu-label {
    flex: 1;
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-left: 8px; /* 文字与图标间距，可微调 */
    padding-left: 20px; /* 关键：一级文字起点固定 20px + 8px间距 */
  }

  /* SVG 箭头 */
  .arrow {
    margin-left: auto;
    margin-right: 16px;
    transition: transform 0.35s cubic-bezier(0.4, 0, 0.2, 1);
    flex-shrink: 0;

    &.expanded {
      transform: rotate(90deg);
    }
  }
}

.submenu {
  background: #fafbfe;
  overflow: hidden;
}

/* 动画不变 */
.menu-slide-enter-active,
.menu-slide-leave-active {
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  max-height: 1200px;
}

.menu-slide-enter-from,
.menu-slide-leave-to {
  max-height: 0;
  opacity: 0;
  transform: translateY(-6px);
}

.menu-slide-enter-to,
.menu-slide-leave-from {
  max-height: 1200px;
  opacity: 1;
  transform: translateY(0);
}
</style>
<!-- <style lang="less" scoped>
.menu-item {
  &.active > .menu-title {
    background: linear-gradient(to right, #3963f5, #3963f522);
    color: #3963f5 !important;
    font-weight: 600;
    box-shadow: inset 0 1px 3px rgba(57, 99, 245, 0.15);
  }
}

.menu-title {
  display: flex;
  align-items: center;
  height: 48px;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  &:hover {
    background: #f0f4ff;
    color: #3963f5;
    transform: translateX(4px);
  }

  /* 图标容器：动态宽度，随层级缩进 + 固定图标区 */
  .icon-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-shrink: 0;
    height: 100%;
  }

  .menu-icon {
    font-size: 18px;
    opacity: 0.8;
  }

  /* 文字：固定起点，所有层级文字垂直对齐 */
  .menu-label {
    flex: 1;
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding-left: 20px; /* 文字统一起点 */
    margin-right: 40px; /* 为箭头预留空间 */
  }

  /* SVG 箭头：固定在文字右侧，不靠最右边 */
  .arrow {
    position: absolute;
    right: 16px;
    transition: transform 0.35s cubic-bezier(0.4, 0, 0.2, 1);

    &.expanded {
      transform: rotate(90deg);
    }
  }
}

.submenu {
  background: #fafbfe;
  overflow: hidden;
}

/* 动画不变 */
.menu-slide-enter-active,
.menu-slide-leave-active {
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  max-height: 1200px;
}

.menu-slide-enter-from,
.menu-slide-leave-to {
  max-height: 0;
  opacity: 0;
  transform: translateY(-6px);
}

.menu-slide-enter-to,
.menu-slide-leave-from {
  max-height: 1200px;
  opacity: 1;
  transform: translateY(0);
}
</style> -->
