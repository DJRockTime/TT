<template>
  <section class="checkbox-transfer">
    <!-- 左侧面板 -->
    <div class="left-panel">
      <div class="input-search">
        <div class="search-bar">
          <input
            type="search"
            v-model="searchValue"
            placeholder="搜索..."
            @input="handleSearch"
          />

          <!-- 新增：全局展开/收起按钮 -->
          <button
            class="toggle-all-btn"
            @click="toggleAllExpand"
            :title="isAllExpanded ? '全部收起' : '全部展开'"
          >
            <span class="expand-arrow" :class="{ expanded: isAllExpanded }"
              >▶</span
            >
            {{ isAllExpanded ? "收起" : "展开" }}
          </button>
        </div>
      </div>
      <div class="checkbox-tree-container">
        <div
          v-for="node in displayedNodes"
          :key="node.id"
          class="tree-node-wrapper"
        >
          <div v-if="!node.pid" class="tree-node level-0">
            <!-- 展开/折叠箭头，仅父级有 -->
            <span
              class="expand-arrow"
              :class="{ expanded: expandedNodes.has(node.id) }"
              @click="toggleExpand(node)"
            >
              <!-- ▶ -->
              <svg
                :class="{ expanded: expandedNodes.has(node.id) }"
                width="12"
                height="12"
                viewBox="0 0 1024 1024"
                style="transition: transform 0.25s ease"
              >
                <path
                  d="M366.336 772.48l348.16-348.16-348.16-348.16 59.904-59.904 408.064 408.064L428.24 832.384z"
                />
              </svg>
            </span>
            <!-- Checkbox with three states -->
            <label class="checkbox-label">
              <input
                type="checkbox"
                :checked="node.checked"
                :indeterminate.prop="node.indeterminate"
                @change="handleCheck(node, $event.target.checked)"
              />
              <!-- Label with highlight -->
              <span
                class="node-label"
                v-html="highlightLabel(node.label)"
              ></span>
            </label>
          </div>
          <transition name="expand">
            <div
              v-if="!node.pid && (expandedNodes.has(node.id) || searchValue)"
              class="children-group"
            >
              <div
                v-for="child in getChildren(node)"
                :key="child.id"
                class="tree-node level-1"
              >
                <label class="checkbox-label">
                  <input
                    type="checkbox"
                    :checked="child.checked"
                    :indeterminate.prop="child.indeterminate"
                    @change="handleCheck(child, $event.target.checked)"
                  />
                  <span
                    class="node-label"
                    v-html="highlightLabel(child.label)"
                  ></span>
                </label>
              </div>
            </div>
          </transition>
          <div
            v-if="node.pid"
            class="tree-node level-1"
            v-show="isChildVisible(node)"
          >
            <label class="checkbox-label">
              <input
                type="checkbox"
                :checked="node.checked"
                :indeterminate.prop="node.indeterminate"
                @change="handleCheck(node, $event.target.checked)"
              />
              <span
                class="node-label"
                v-html="highlightLabel(node.label)"
              ></span>
            </label>
          </div>
        </div>
      </div>
    </div>
    <!-- 右侧面板 -->
    <div class="right-panel">
      <div class="selected-items-container">
        <header>
          <span>已选{{ selectList.length }}条</span>
          <span class="clear-all" @click="clearAll">清空</span>
        </header>
        <div class="selected-items-list">
          <div
            class="selected-item"
            v-for="item in selectList"
            :key="item.value"
          >
            <span class="item-name">{{ item.name }}</span>
            <span class="remove-item" @click="removeItem(item)">x</span>
          </div>
        </div>
      </div>

      <!-- 新增：确认按钮 + 输出结果展示（可删，正式用时 expose 出去） -->
      <div class="action-footer">
        <button class="confirm-btn" @click="handleConfirm">确认</button>
      </div>

      <!-- 调试用：点击确认后显示结果（正式项目可以删） -->
      <div v-if="resultOutput" class="result-output">
        <pre>{{ JSON.stringify(resultOutput, null, 2) }}</pre>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from "vue";

interface ITreeData {
  id: number;
  pid: number | null;
  label: string;
  value: string;
  isLeaf?: boolean;
  docClassCode?: string;
  docClassName?: string;
  checked: boolean;
  indeterminate: boolean;
  childrenIds?: number[]; // 子节点 ID 列表
}

const emit = defineEmits<{
  confirm: [
    data: {
      docItemNames: string;
      docClassCode: string;
      docClassNames: string;
    }
  ];
}>();

const props = defineProps<{
  allowParentSelect?: boolean; // 是否允许父级进入已选列表，默认 false
}>();

const allowParentSelect = computed(() => props.allowParentSelect ?? false);

// 原始 realData（从用户提供）
const realData = [
  {
    docItemName: "商务合作",
    children: [
      { docClassCode: "DOC0001", docClassName: "合同范本" },
      { docClassCode: "DOC0002", docClassName: "协议范本" },
    ],
  },
  {
    docItemName: "法律事务",
    children: [
      { docClassCode: "DOC0001", docClassName: "合同范本" },
      { docClassCode: "DOC0003", docClassName: "法律意见书" },
      { docClassCode: "DOC0005", docClassName: "尽职调查报告" },
    ],
  },
  {
    docItemName: "知识产权",
    children: [
      { docClassCode: "DOC0006", docClassName: "专利申请" },
      { docClassCode: "DOC0003", docClassName: "法律意见书" },
      { docClassCode: "DOC0007", docClassName: "商标注册" },
    ],
  },
];

const resultOutput = ref<any>(null);

const handleConfirm = () => {
  const selectedCodes = selectList.value.map((item) => item.value); // 如 ['DOC0001', 'DOC0003', 'DOC0005']

  const docItemNames: string[] = [];
  const codeList: string[] = [];
  const nameList: string[] = [];

  const seenParents = new Set<string>();
  const seenCodes = new Set<string>();

  // 按原始 realData 的顺序遍历（保证顺序正确）
  realData.forEach((group) => {
    const parentName = group.docItemName;

    group.children.forEach((child: any) => {
      if (selectedCodes.includes(child.docClassCode)) {
        if (!seenCodes.has(child.docClassCode)) {
          seenCodes.add(child.docClassCode);
          codeList.push(child.docClassCode);
          nameList.push(child.docClassName);

          if (!seenParents.has(parentName)) {
            seenParents.add(parentName);
            docItemNames.push(parentName);
          }
        }
      }
    });
  });

  resultOutput.value = {
    docItemNames: docItemNames.join(", "), // 例如：商务合作, 法律事务
    docClassCode: codeList.join(", "), // 例如：DOC0001, DOC0003, DOC0005
    docClassNames: nameList.join(", "), // 例如：合同范本, 法律意见书, 尽职调查报告
  };

  // 正式使用时：通过 emit 或 expose 抛出去
  emit("confirm", resultOutput.value);
};

// 是否全部展开（计算属性）
const isAllExpanded = computed(() => {
  return allNodes.value
    .filter((node) => !node.isLeaf)
    .every((node) => expandedNodes.value.has(node.id));
});

// 一键全部展开/收起
const toggleAllExpand = () => {
  const shouldExpand = !isAllExpanded.value;

  allNodes.value.forEach((node) => {
    if (!node.isLeaf) {
      if (shouldExpand) {
        expandedNodes.value.add(node.id);
      } else {
        expandedNodes.value.delete(node.id);
      }
    }
  });
};

// 转换函数：将 realData 转换为扁平 ITreeData[]，添加 checked 和 indeterminate
const flattenData = (data: any[]): ITreeData[] => {
  const flatList: ITreeData[] = [];
  let idCounter = 1;

  data.forEach((parent) => {
    const parentNode: ITreeData = {
      id: idCounter++,
      pid: null,
      label: parent.docItemName,
      value: parent.docItemName,
      isLeaf: false,
      checked: false,
      indeterminate: false,
      childrenIds: [],
    };
    flatList.push(parentNode);

    parent.children.forEach((child: any) => {
      const childNode: ITreeData = {
        id: idCounter++,
        pid: parentNode.id,
        label: child.docClassName, // 显示 docClassName，但 value 用 docClassCode 去重
        value: child.docClassCode,
        isLeaf: true,
        docClassCode: child.docClassCode,
        docClassName: child.docClassName,
        checked: false,
        indeterminate: false,
      };
      flatList.push(childNode);
      parentNode.childrenIds!.push(childNode.id);
    });
  });

  return flatList;
};

const allNodes = ref<ITreeData[]>([]);
const nodeMap = computed<Map<number, ITreeData>>(() => {
  const map = new Map();
  allNodes.value.forEach((node) => map.set(node.id, node));
  return map;
});
const expandedNodes = ref<Set<number>>(new Set());
const searchValue = ref<string>("");
const selectList = ref<Array<{ value: string; name: string }>>([]);

onMounted(() => {
  allNodes.value = flattenData(realData);
  // 默认展开所有父级
  allNodes.value.forEach((node) => {
    if (!node.isLeaf) expandedNodes.value.add(node.id);
  });
});

// 显示的节点：只显示父级，子级通过 getChildren 处理
const displayedNodes = computed(() => {
  const searchLower = searchValue.value.toLowerCase();
  const result: ITreeData[] = [];
  const matchedParents = new Set<number>();

  if (searchValue.value) {
    // 标记匹配的父级（如果子级匹配）
    allNodes.value.forEach((node) => {
      if (node.isLeaf && node.label.toLowerCase().includes(searchLower)) {
        if (node.pid) matchedParents.add(node.pid);
      }
    });
  }

  // 只添加父级，如果匹配或无搜索
  allNodes.value
    .filter((node) => node.pid === null)
    .forEach((parent) => {
      const parentMatches =
        !searchValue.value || parent.label.toLowerCase().includes(searchLower);
      if (parentMatches || matchedParents.has(parent.id)) {
        result.push(parent);
        if (searchValue.value) expandedNodes.value.add(parent.id); // 如果搜索匹配，自动展开
      }
    });

  return result;
});

// 获取子节点，支持搜索过滤
const getChildren = (parent: ITreeData) => {
  const searchLower = searchValue.value.toLowerCase();
  return parent
    .childrenIds!.map((id) => nodeMap.value.get(id)!)
    .filter((child) => {
      return (
        !searchValue.value ||
        child.label.toLowerCase().includes(searchLower) ||
        parent.label.toLowerCase().includes(searchLower)
      );
    });
};

// 高亮标签
const highlightLabel = (label: string) => {
  if (!searchValue.value) return label;
  const regex = new RegExp(
    `(${searchValue.value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`,
    "gi"
  );
  return label.replace(regex, '<span class="highlight">$1</span>');
};

// 切换展开
const toggleExpand = (node: ITreeData) => {
  if (expandedNodes.value.has(node.id)) {
    expandedNodes.value.delete(node.id);
  } else {
    expandedNodes.value.add(node.id);
  }
};

// 处理 checkbox 变更：父子联动 + 三态
const handleCheck = (node: ITreeData, checked: boolean) => {
  node.checked = checked;
  node.indeterminate = false;

  // 如果是父级，联动子级
  if (!node.isLeaf) {
    node.childrenIds!.forEach((childId) => {
      const child = nodeMap.value.get(childId);
      if (child) {
        child.checked = checked;
        child.indeterminate = false;
      }
    });
  }

  // 更新父级状态（如果有 pid）
  if (node.pid) {
    updateParentState(node.pid);
  }

  updateSelectList();
};

// 更新父级状态：递归向上
function updateParentState(parentId: number) {
  const parent = nodeMap.value.get(parentId);
  if (!parent) return;

  const children = parent.childrenIds!.map((id) => nodeMap.value.get(id)!);
  const allChecked = children.every((child) => child.checked);
  const noneChecked = children.every(
    (child) => !child.checked && !child.indeterminate
  );
  parent.checked = allChecked;
  parent.indeterminate = !allChecked && !noneChecked;

  if (parent.pid) {
    updateParentState(parent.pid);
  }
}

// 更新右侧列表：基于 value 去重，可根据 allowParentSelect 添加父级
const updateSelectList = () => {
  const selectedMap = new Map<string, { value: string; name: string }>();
  allNodes.value.forEach((node) => {
    if (node.checked && !selectedMap.has(node.value)) {
      if (node.isLeaf || allowParentSelect.value) {
        selectedMap.set(node.value, { value: node.value, name: node.label });
      }
    }
  });
  selectList.value = Array.from(selectedMap.values());
};

// 清空
const clearAll = () => {
  allNodes.value.forEach((node) => {
    node.checked = false;
    node.indeterminate = false;
  });
  selectList.value = [];
};

// 移除项：基于 value 取消所有同 value 的 checked，并更新父级
const removeItem = (item: { value: string; name: string }) => {
  allNodes.value.forEach((node) => {
    if (node.value === item.value) {
      node.checked = false;
      if (node.pid) updateParentState(node.pid);
      else if (!node.isLeaf) {
        // 如果移除父级，联动子级 unchecked
        node.childrenIds!.forEach((childId) => {
          const child = nodeMap.value.get(childId);
          if (child) child.checked = false;
        });
      }
    }
  });
  updateSelectList();
};

// 搜索处理（v-model 已处理）
const handleSearch = () => {
  // computed 会自动更新
};

defineExpose({
  getSelectedResult: () => resultOutput.value,
  selectList,
});
</script>

<style scoped>
.checkbox-transfer {
  display: flex;
  height: 100%; /* 继承父容器高度 */
  min-height: 400px; /* 最小高度 400px */
  gap: 16px;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen,
    Ubuntu, Cantarell, sans-serif;
  font-size: 14px;
}

/* 左侧面板：固定 300px */
.left-panel {
  width: 300px;
  min-width: 300px;
  display: flex;
  flex-direction: column;
  background: #fff;
  border: 1px solid #e1e4e8;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.search-bar {
  display: flex;
  align-items: center;
  gap: 8px;
}

.search-bar input {
  flex: 1;
}

.toggle-all-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 10px;
  background: #f5f7fa;
  border: 1px solid #d9d9d9;
  border-radius: 6px;
  font-size: 13px;
  color: #555;
  cursor: pointer;
  transition: all 0.2s;
  white-space: nowrap;
}

.toggle-all-btn:hover {
  background: #e6f7ff;
  border-color: #409eff;
  color: #409eff;
}

.toggle-all-btn .expand-arrow {
  font-size: 10px;
  transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
}

.toggle-all-btn .expand-arrow.expanded {
  transform: rotate(90deg);
}

.input-search {
  padding: 12px;
  border-bottom: 1px solid #f0f0f0;
}

.input-search input {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #d9d9d9;
  border-radius: 6px;
  font-size: 14px;
  transition: border 0.2s;
}

.input-search input:focus {
  outline: none;
  border-color: #409eff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.2);
}

/* 树容器：内容区域滚动 */
.checkbox-tree-container {
  flex: 1;
  overflow-y: auto;
  padding: 8px 12px;
}

/* 右侧面板：固定 200px */
.right-panel {
  width: 200px;
  min-width: 200px;
  display: flex;
  flex-direction: column;
  background: #fff;
  border: 1px solid #e1e4e8;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.selected-header {
  padding: 12px;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 14px;
  color: #333;
}

.selected-count {
  font-weight: 600;
}

.clear-all {
  cursor: pointer;
  color: #ff4d4f;
  font-size: 13px;
}

.clear-all:hover {
  text-decoration: underline;
}

/* 已选列表容器：滚动 */
.selected-items-container {
  flex: 1;
  overflow-y: auto;
  padding: 8px 0;
}

.selected-items-list {
  padding: 0 12px;
}

.selected-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  margin: 4px 0;
  background: #f5f7fa;
  border-radius: 6px;
  font-size: 13px;
  transition: background 0.2s;
}

.selected-item:hover {
  background: #e6f7ff;
}

.remove-item {
  cursor: pointer;
  color: #999;
  font-size: 18px;
  font-weight: bold;
}

.remove-item:hover {
  color: #ff4d4f;
}

/* 树节点样式 */
.tree-node-wrapper {
  margin-bottom: 4px;
}

.tree-node {
  display: flex;
  align-items: center;
  padding: 4px 6px;
  border-radius: 4px;
  transition: background 0.2s;
  user-select: none;
}

.tree-node:hover {
  background: #f5f7fa;
}

.level-0 {
  font-weight: 600;
  color: #1f2329;
}

.level-1 {
  color: #555;
}

.expand-arrow svg {
  display: block;
  transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  transform: rotate(0deg);
}

.expand-arrow svg.expanded {
  transform: rotate(90deg);
}

.checkbox-label {
  display: flex;
  align-items: center;
  cursor: pointer;
  flex: 1;
}

.checkbox-label input {
  margin-right: 8px;
}

.node-label {
  line-height: 1.4;
}

.highlight {
  background: #fff566;
  padding: 0 2px;
  border-radius: 2px;
  font-weight: 600;
}

.children-group {
  margin-left: 22px;
  overflow: hidden;
}

/* 展开动画 */
.expand-enter-active,
.expand-leave-active {
  transition: all 0.28s ease;
  max-height: 1000px;
  opacity: 1;
}

.expand-enter-from,
.expand-leave-to {
  max-height: 0;
  opacity: 0;
  margin-top: 0 !important;
  margin-bottom: 0 !important;
  padding-top: 0;
  padding-bottom: 0;
}

/* 空状态 */
.empty-tip {
  padding: 40px 20px;
  text-align: center;
  color: #999;
  font-size: 13px;
}

.action-footer {
  padding: 12px;
  border-top: 1px solid #f0f0f0;
  text-align: right;
}

.confirm-btn {
  padding: 8px 20px;
  background: #409eff;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: background 0.2s;
}

.confirm-btn:hover {
  background: #66b1ff;
}

.result-output {
  margin: 12px;
  padding: 12px;
  background: #f6ffed;
  border: 1px solid #b7eb8f;
  border-radius: 6px;
  font-size: 12px;
  max-height: 200px;
  overflow: auto;
}
</style>
