<template>
  <el-dialog
    v-model="visible"
    title="文档配置"
    width="80%"
    :before-close="handleClose"
    append-to-body
  >
    <el-steps :active="active" finish-status="success">
      <el-step title="基本信息" />
      <el-step title="文档项配置" />
    </el-steps>

    <!-- 步骤1: 表单布局使用 row col -->
    <el-form
      ref="step1FormRef"
      :model="step1Form"
      :rules="rules"
      label-width="120px"
      v-if="active === 0"
    >
      <el-row :gutter="24">
        <el-col :span="8">
          <el-form-item label="Init Doc Name" prop="initDocName">
            <el-input
              v-model="step1Form.initDocName"
              placeholder="请输入文档名称"
            />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="Doc Class Code" prop="docClassCode">
            <el-select
              v-model="step1Form.docClassCode"
              multiple
              placeholder="请选择文档分类代码"
              style="width: 100%"
              clearable
            >
              <el-option
                v-for="item in docClassOptions"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="开始时间" prop="startDate">
            <el-date-picker
              v-model="step1Form.startDate"
              type="date"
              placeholder="选择日期"
              :picker-options="datePickerOptions"
              style="width: 100%"
            />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <!-- 步骤2: 显示步骤1置灰 + 表格 -->
    <div v-if="active === 1" class="step2-content">
      <!-- 步骤1内容（置灰显示，使用disabled表单） -->
      <div class="step1-preview">
        <h4>基本信息（查看）</h4>
        <el-form :model="step1Form" label-width="120px">
          <el-row :gutter="24">
            <el-col :span="8">
              <el-form-item label="Init Doc Name">
                <el-input
                  v-model="step1Form.initDocName"
                  placeholder="请输入文档名称"
                  disabled
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Doc Class Code">
                <el-select
                  v-model="step1Form.docClassCode"
                  multiple
                  placeholder="请选择文档分类代码"
                  style="width: 100%"
                  disabled
                >
                  <el-option
                    v-for="item in docClassOptions"
                    :key="item"
                    :label="item"
                    :value="item"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="开始时间">
                <el-date-picker
                  v-model="step1Form.startDate"
                  type="date"
                  placeholder="选择日期"
                  :picker-options="datePickerOptions"
                  style="width: 100%"
                  disabled
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <!-- 步骤2表格 -->
      <div class="step2-table">
        <h4>文档项配置</h4>
        <el-table
          ref="elTableRef"
          :data="displayedData"
          border
          style="width: 100%; margin-top: 10px"
          :show-overflow-tooltip="true"
          row-key="sort"
        >
          <el-table-column type="index" label="序号" width="80" fixed="left" />
          <el-table-column label="拖拽" width="60" fixed="left">
            <template #default="scope">
              <i
                class="el-icon-rank drag-handle"
                style="cursor: move; color: #999; font-size: 16px"
              ></i>
            </template>
          </el-table-column>
          <el-table-column
            prop="docItemName"
            label="Doc Item Name"
            min-width="150"
          >
            <template #default="scope">
              <el-input v-model="scope.row.docItemName" size="small" />
            </template>
          </el-table-column>
          <el-table-column
            prop="docClassCode"
            label="Doc Class Code"
            min-width="150"
          >
            <template #default="scope">
              <el-input
                v-model="scope.row.docClassCode"
                size="small"
                disabled
              />
            </template>
          </el-table-column>
          <el-table-column
            v-if="props.mode === 'CONFIGURATION'"
            prop="status"
            label="Status"
            width="100"
          >
            <template #default="scope">
              <span>{{ scope.row.status || "N/A" }}</span>
            </template>
          </el-table-column>
          <el-table-column label="Type" min-width="120">
            <template #default="scope">
              <el-select
                v-model="scope.row.type"
                placeholder="请选择类型"
                size="small"
                clearable
                @change="handleTypeChange(scope.row)"
              >
                <el-option label="INIT" value="INIT" />
                <el-option label="LIST" value="LIST" />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column label="Condition" min-width="300">
            <template #default="scope">
              <div v-if="scope.row.type === 'INIT'">
                <el-date-picker
                  v-model="scope.row.dateStartTime"
                  type="date"
                  placeholder="起始时间"
                  :picker-options="datePickerOptions"
                  size="small"
                  style="width: 45%; margin-right: 5px"
                />
                <el-date-picker
                  v-model="scope.row.dateEndTime"
                  type="date"
                  placeholder="终止时间"
                  :picker-options="datePickerOptions"
                  size="small"
                  style="width: 50%"
                />
              </div>
              <div v-else-if="scope.row.type === 'LIST'">
                <el-input-tag
                  v-model="scope.row.condition"
                  placeholder="Please input"
                  class="input-new-tag"
                  size="small"
                />
              </div>
            </template>
          </el-table-column>
          <el-table-column label="DeliveryTime" min-width="150">
            <template #default="scope">
              <el-input v-model="scope.row.deliveryTime" size="small" />
            </template>
          </el-table-column>
          <el-table-column label="操作" width="150" fixed="right">
            <template #default="scope">
              <el-button
                type="text"
                size="small"
                @click="handleAddRow(scope.row)"
                >新增</el-button
              >
              <el-button
                type="text"
                size="small"
                @click="handleDeleteRow(scope.$index)"
                >删除</el-button
              >
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          v-model:current-page="currentPage"
          :page-size="pageSize"
          layout="total, prev, pager, next, jumper"
          :total="step2TableData.length"
          class="pagination"
          style="margin-top: 10px; text-align: right"
          @current-change="handlePageChange"
        />
      </div>
    </div>

    <template #footer>
      <span v-if="active === 0" class="dialog-footer">
        <el-button @click="handleClose">取消</el-button>
        <el-button type="primary" @click="handleNext">下一步</el-button>
      </span>
      <span v-else class="dialog-footer">
        <el-button @click="handlePrev">上一步</el-button>
        <el-button type="primary" @click="handleFinish">确认</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, reactive, nextTick, watch, computed } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import Sortable from "sortablejs";

// 弹框可见性
const visible = ref(false);
// 当前步骤
const active = ref(0);
// 步骤1表单引用
const step1FormRef = ref();
// 步骤1表单数据
const step1Form = reactive({
  initDocName: "",
  docClassCode: [],
  startDate: null,
});
// 验证规则
const rules = reactive({
  initDocName: [{ required: true, message: "请输入文档名称", trigger: "blur" }],
  docClassCode: [
    {
      required: true,
      message: "请选择分类代码",
      trigger: "change",
      type: "array",
      min: 1,
    },
  ],
  startDate: [{ required: true, message: "请选择开始时间", trigger: "change" }],
});
// docClassCode 选项（扩展到10个）
const docClassOptions = [
  "DOC001",
  "DOC002",
  "DOC003",
  "DOC004",
  "DOC005",
  "DOC006",
  "DOC007",
  "DOC008",
  "DOC009",
  "DOC010",
];
// 日期选择器选项（大于今天，当前日期 2025-10-12，根据用户提示更新）
const today = new Date("2025-10-12");
const datePickerOptions = {
  disabledDate(time) {
    return time.getTime() <= today.getTime();
  },
};
// 步骤2表格数据
const step2TableData = ref([]);
// 新增：CONFIG模式下的原始数据缓存（用于比对变化）和删除ID集合
const originalTableData = ref([]);
const deletedIds = ref([]);
// 新增：缓存数据和旧docClassCodes（ADD模式用）
const cachedTableData = ref([]);
const oldDocClassCodes = ref([]);
// 新增：CONFIG模式下的原始行按docClassCode分组
const originalRowsByCode = reactive({});
// 新增：首次next标志
const isFirstNext = ref(false);
// 分页相关
const currentPage = ref(1);
const pageSize = ref(5); // 示例页大小，可调整
const displayedData = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value;
  const end = start + pageSize.value;
  return step2TableData.value.slice(start, end);
});
// 表格引用
const elTableRef = ref();
// Sortable 实例
let sortableInstance = null;

const props = defineProps({
  mode: {
    type: String,
    default: "ADD",
  },
  payload: {
    type: Object,
    default: null,
  },
});

// 模板数据
const dataModal = {
  sort: 1,
  type: "INIT",
  condition: [],
  docIdList: [],
  deliveryTime: "",
  status: "ONGOING", // CONFIG模式默认ONGOING
  docItemName: "",
  docClassCode: "",
  dateStartTime: null,
  dateEndTime: null,
  initBatchTaskId: null,
  initDomainTaskId: null,
};

// 模拟后端请求：根据docClassCode返回对应docItemName列表（ADD用）
const fetchDocItems = async (codes) => {
  // 模拟延迟
  await new Promise((resolve) => setTimeout(resolve, 500));
  // Mock映射：DOC001 -> '电影', DOC002 -> '电视剧', 等
  const mockMap = {
    DOC001: "电影",
    DOC002: "电视剧",
    DOC003: "音乐",
    DOC004: "综艺",
    DOC005: "小说",
    DOC006: "漫画",
    DOC007: "游戏",
    DOC008: "动漫",
    DOC009: "纪录片",
    DOC010: "访谈",
  };
  const data = codes.map((code) => ({
    docItemName: mockMap[code] || "未知",
    docClassCode: code,
  }));
  return {
    code: 200,
    message: "success",
    data,
  };
};

// 模拟创建基本信息接口：返回initBatchTaskId（ADD用）
const createInitDoc = async (formData) => {
  // 模拟延迟
  await new Promise((resolve) => setTimeout(resolve, 300));
  // Mock返回：假设成功，生成一个随机ID
  const initBatchTaskId = `BATCH_${Date.now()}_${Math.random()
    .toString(36)
    .substr(2, 9)}`;
  return {
    code: 200,
    message: "success",
    data: {
      initBatchTaskId,
    },
  };
};

// 比较两个对象是否相同（忽略undefined/null，JSON.stringify简单比对，现在包含sort）
const isObjectChanged = (original, current) => {
  // const excludeKeys = ["sort"]; // 移除排除，包含sort变化
  const excludeKeys = [];
  const origFiltered = Object.fromEntries(
    Object.entries(original).filter(([k]) => !excludeKeys.includes(k))
  );
  const currFiltered = Object.fromEntries(
    Object.entries(current).filter(([k]) => !excludeKeys.includes(k))
  );
  const origStr = JSON.stringify(origFiltered);
  const currStr = JSON.stringify(currFiltered);
  return origStr !== currStr;
};

// Type变化处理：同步condition到docIdList
const handleTypeChange = (row) => {
  if (row.type === "LIST") {
    row.docIdList = [...row.condition];
  } else {
    row.docIdList = [];
  }
};

// 初始化Sortable拖拽
const initSortable = () => {
  if (sortableInstance) {
    sortableInstance.destroy();
  }
  nextTick(() => {
    const tbody = elTableRef.value?.$el.querySelector(
      ".el-table__body-wrapper tbody"
    );
    if (tbody && displayedData.value.length > 1) {
      // 只有多行时初始化
      sortableInstance = Sortable.create(tbody, {
        animation: 150,
        handle: ".drag-handle",
        onEnd: (evt) => {
          const fullOldIndex =
            (currentPage.value - 1) * pageSize.value + evt.oldIndex;
          const fullNewIndex =
            (currentPage.value - 1) * pageSize.value + evt.newIndex;
          if (
            fullOldIndex !== fullNewIndex &&
            fullOldIndex < step2TableData.value.length &&
            fullNewIndex <= step2TableData.value.length
          ) {
            const item = step2TableData.value[fullOldIndex];
            step2TableData.value.splice(fullOldIndex, 1);
            step2TableData.value.splice(fullNewIndex, 0, item);
            // 重排sort（全局）
            step2TableData.value.forEach((row, idx) => {
              row.sort = idx + 1;
            });
            // 无需手动调整页码，computed会更新显示；如果需要可添加逻辑保持拖拽行在当前页
          }
        },
      });
    }
  });
};

// 新增行：基于当前行继承docClassCode和docItemName（作为模板），添加到最后
const handleAddRow = (currentRow = null) => {
  const newRow = { ...dataModal };
  newRow.sort = step2TableData.value.length + 1;
  newRow.initBatchTaskId = step2TableData.value[0]?.initBatchTaskId || null; // 继承batch ID，如果有
  if (currentRow) {
    newRow.docClassCode = currentRow.docClassCode; // 继承docClassCode
    newRow.docItemName = currentRow.docItemName; // 继承docItemName（用户可编辑）
  }
  // 如果无currentRow（fallback），docClassCode/docItemName为空
  step2TableData.value.push(newRow);
  // 调整页码到最后一页
  currentPage.value = Math.ceil(step2TableData.value.length / pageSize.value);
  nextTick(initSortable);
};

// 删除行并重新排序（CONFIG: 收集initDomainTaskId）
const handleDeleteRow = (displayedIndex) => {
  const fullIndex = (currentPage.value - 1) * pageSize.value + displayedIndex;
  ElMessageBox.confirm("确定删除该行吗？", "提示", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  }).then(() => {
    const row = step2TableData.value[fullIndex];
    if (row.initDomainTaskId && props.mode === "CONFIGURATION") {
      deletedIds.value.push(row.initDomainTaskId);
    }
    step2TableData.value.splice(fullIndex, 1);
    // 重新排序sort
    step2TableData.value.forEach((row, idx) => {
      row.sort = idx + 1;
    });
    // 调整页码：如果当前页为空，回到上一页
    const totalPages = Math.ceil(step2TableData.value.length / pageSize.value);
    if (currentPage.value > totalPages) {
      currentPage.value = totalPages || 1;
    }
    ElMessage.success("删除成功");
    nextTick(initSortable);
  });
};

// 分页变化
const handlePageChange = (page) => {
  currentPage.value = page;
  nextTick(initSortable);
};

// 步骤1下一步：验证 + 处理docClassCode变化 + 模拟创建基本信息 + 初始化/更新表格
const handleNext = async () => {
  try {
    await step1FormRef.value.validate();
    const newCodes = step1Form.docClassCode;
    if (newCodes.length === 0) {
      ElMessage.error("请选择至少一个分类代码");
      return;
    }

    let initBatchTaskId = null;
    let updatedTableData = [];

    if (props.mode === "ADD") {
      const createResponse = await createInitDoc(step1Form);
      if (createResponse.code !== 200) {
        ElMessage.error(createResponse.message || "创建基本信息失败");
        return;
      }
      initBatchTaskId = createResponse.data.initBatchTaskId;
    } else {
      initBatchTaskId = originalTableData.value[0]?.initBatchTaskId;
      if (isFirstNext.value) {
        isFirstNext.value = false;
        active.value = 1;
        nextTick(initSortable);
        return;
      }
    }

    const addedCodes = newCodes.filter(
      (code) => !oldDocClassCodes.value.includes(code)
    );
    const removedCodes = oldDocClassCodes.value.filter(
      (code) => !newCodes.includes(code)
    );

    if (
      oldDocClassCodes.value.length === 0 ||
      cachedTableData.value.length === 0
    ) {
      // 首次进入或无缓存：正常创建
      if (props.mode === "ADD") {
        const response = await fetchDocItems(newCodes);
        if (response.code !== 200) {
          ElMessage.error(response.message || "请求失败");
          return;
        }
        updatedTableData = response.data.map((item, index) => {
          const row = { ...dataModal };
          row.docItemName = item.docItemName;
          row.docClassCode = item.docClassCode;
          row.sort = index + 1;
          row.initBatchTaskId = initBatchTaskId;
          row.condition = [];
          row.docIdList = [];
          row.status = "";
          return row;
        });
      } else {
        // CONFIG首次已处理，此分支不应到达
        updatedTableData = step2TableData.value.map((row) =>
          JSON.parse(JSON.stringify(row))
        );
      }
    } else {
      // 有缓存：处理变化
      // CONFIG: 标记删除的原始行
      if (props.mode === "CONFIGURATION") {
        const rowsToMark = cachedTableData.value
          .filter((row) => removedCodes.includes(row.docClassCode))
          .filter((row) => row.initDomainTaskId);
        rowsToMark.forEach((row) => {
          if (!deletedIds.value.includes(row.initDomainTaskId)) {
            deletedIds.value.push(row.initDomainTaskId);
          }
        });
      }

      // 保留：过滤掉removed的cached
      updatedTableData = cachedTableData.value.filter(
        (row) => !removedCodes.includes(row.docClassCode)
      );

      // 新增：为addedCodes添加新行或还原
      const addPromises = addedCodes.map(async (code) => {
        let newRowsForCode = [];
        if (
          props.mode === "CONFIGURATION" &&
          originalRowsByCode[code] &&
          originalRowsByCode[code].length > 0
        ) {
          // 还原原始行
          newRowsForCode = originalRowsByCode[code].map((row) =>
            JSON.parse(JSON.stringify(row))
          );
          // 取消标记删除
          newRowsForCode.forEach((r) => {
            const idx = deletedIds.value.indexOf(r.initDomainTaskId);
            if (idx > -1) {
              deletedIds.value.splice(idx, 1);
            }
          });
        } else {
          // 新增：fetch新行
          const response = await fetchDocItems([code]);
          if (response.code !== 200) {
            ElMessage.error(response.message || "新增数据请求失败");
            return [];
          }
          const item = response.data[0];
          const row = { ...dataModal };
          row.docItemName = item.docItemName;
          row.docClassCode = code;
          row.sort = updatedTableData.length + newRowsForCode.length + 1;
          row.initBatchTaskId = initBatchTaskId;
          row.condition = [];
          row.docIdList = [];
          row.status = props.mode === "CONFIGURATION" ? "ONGOING" : "";
          newRowsForCode = [row];
        }
        return newRowsForCode;
      });
      const allAddedRows = (await Promise.all(addPromises)).flat();
      updatedTableData.push(...allAddedRows);
    }

    // 确保所有行有initBatchTaskId（更新）
    updatedTableData.forEach((row) => {
      if (!row.initBatchTaskId) {
        row.initBatchTaskId = initBatchTaskId;
      }
    });

    // 重新排序
    updatedTableData.forEach((row, idx) => {
      row.sort = idx + 1;
    });

    step2TableData.value = updatedTableData;

    // 更新oldCodes为newCodes（下次用）
    oldDocClassCodes.value = [...newCodes];

    currentPage.value = 1; // 重置到第一页
    active.value = 1;
    nextTick(initSortable);
  } catch {
    ElMessage.error("请检查表单填写是否完整");
  }
};

// 上一步：缓存数据和旧codes
const handlePrev = () => {
  // 只在有数据时缓存（避免空缓存）
  if (step2TableData.value.length > 0) {
    cachedTableData.value = step2TableData.value.map((row) =>
      JSON.parse(JSON.stringify(row))
    );
    oldDocClassCodes.value = [...step1Form.docClassCode];
  }
  active.value = 0;
};

// 确认：构建add/update/delete（CONFIG: 比对变化；ADD: 只add）
const handleFinish = () => {
  const submitData = {
    addList: [],
    updateList: [],
    deleteList: deletedIds.value,
  };

  if (props.mode === "CONFIGURATION") {
    // CONFIG: add (无initDomainTaskId), update (有ID且变化，包括sort)
    step2TableData.value.forEach((row) => {
      if (!row.initDomainTaskId) {
        // 新增
        submitData.addList.push({
          ...row,
          ...(row.type === "LIST" && { docIdList: [...row.condition] }),
        });
      } else {
        // 编辑：找原始对应行比对
        const origRow = originalTableData.value.find(
          (o) => o.initDomainTaskId === row.initDomainTaskId
        );
        if (origRow && isObjectChanged(origRow, row)) {
          submitData.updateList.push({
            ...row,
            ...(row.type === "LIST" && { docIdList: [...row.condition] }),
          });
        }
      }
    });
  } else {
    // ADD: 全addList
    submitData.addList = step2TableData.value.map((row) => ({
      ...row,
      ...(row.type === "LIST" && { docIdList: [...row.condition] }),
    }));
  }

  // 模拟后端提交
  console.log("提交数据到后端：", submitData);
  ElMessage.success("提交成功");
  handleClose();
};

// 关闭弹框
const handleClose = () => {
  if (sortableInstance) {
    sortableInstance.destroy();
    sortableInstance = null;
  }
  visible.value = false;
  active.value = 0;
  currentPage.value = 1;
  // 重置所有
  Object.assign(step1Form, {
    initDocName: "",
    docClassCode: [],
    startDate: null,
  });
  step2TableData.value = [];
  cachedTableData.value = [];
  oldDocClassCodes.value = [];
  originalTableData.value = [];
  deletedIds.value = [];
  isFirstNext.value = false;
  // 清空originalRowsByCode
  Object.keys(originalRowsByCode).forEach((key) => {
    delete originalRowsByCode[key];
  });
};

// 暴露的打开函数
const handleOpen = async (mode, payload = null) => {
  deletedIds.value = []; // 重置删除ID
  currentPage.value = 1;
  if (mode === "CONFIGURATION") {
    // CONFIG模式：mock表单和表格数据（无需payload或fetch）
    // Mock表单数据
    Object.assign(step1Form, {
      initDocName: "配置文档示例",
      docClassCode: ["DOC001", "DOC003"], // 对应表格docClassCode
      startDate: new Date("2025-10-10"),
    });

    // Mock表格数据：3行，带initDomainTaskId，docClassCode匹配表单，status有值
    const mockTableData = [
      {
        sort: 1,
        type: "INIT",
        condition: [],
        docIdList: [],
        deliveryTime: "2025-10-15",
        status: "ONGOING",
        docItemName: "电影子项1",
        docClassCode: "DOC001",
        dateStartTime: new Date("2025-10-12"),
        dateEndTime: new Date("2025-10-14"),
        initBatchTaskId: "BATCH_1728480000000_abc123",
        initDomainTaskId: "DOMAIN_1728480000000_task1",
      },
      {
        sort: 2,
        type: "LIST",
        condition: ["tagA", "tagB"],
        docIdList: ["tagA", "tagB"],
        deliveryTime: "2025-10-18",
        status: "PAUSE",
        docItemName: "音乐子项1",
        docClassCode: "DOC003",
        dateStartTime: null,
        dateEndTime: null,
        initBatchTaskId: "BATCH_1728480000000_abc123",
        initDomainTaskId: "DOMAIN_1728480000000_task2",
      },
      {
        sort: 3,
        type: "INIT",
        condition: [],
        docIdList: [],
        deliveryTime: "",
        status: "COMPLETE",
        docItemName: "电影子项2",
        docClassCode: "DOC001",
        dateStartTime: new Date("2025-10-16"),
        dateEndTime: new Date("2025-10-20"),
        initBatchTaskId: "BATCH_1728480000000_abc123",
        initDomainTaskId: "DOMAIN_1728480000000_task3",
      },
    ];
    step2TableData.value = mockTableData;
    // 确保初始化condition/docIdList
    step2TableData.value.forEach((row) => {
      if (!row.condition) row.condition = [];
      if (!row.docIdList) row.docIdList = [...row.condition];
    });
    // 缓存原始数据用于比对（深拷贝）
    originalTableData.value = JSON.parse(JSON.stringify(step2TableData.value));
    // 构建originalRowsByCode（深拷贝）
    Object.keys(originalRowsByCode).forEach((key) => {
      delete originalRowsByCode[key];
    });
    step2TableData.value.forEach((row) => {
      const code = row.docClassCode;
      if (!originalRowsByCode[code]) {
        originalRowsByCode[code] = [];
      }
      originalRowsByCode[code].push(JSON.parse(JSON.stringify(row)));
    });
    // 重置ADD缓存
    cachedTableData.value = [];
    oldDocClassCodes.value = [...step1Form.docClassCode];
    isFirstNext.value = true;
    active.value = 0;
  } else {
    // ADD模式，初始化空表格（handleNext会填充），active=0
    step2TableData.value = [];
    active.value = 0;
    cachedTableData.value = [];
    oldDocClassCodes.value = [];
    originalTableData.value = [];
    isFirstNext.value = false;
  }
  visible.value = true;
  // 延迟初始化Sortable，确保表格渲染
  nextTick(() => {
    if (active.value === 1) {
      initSortable();
    }
  });
};

// 分页数据变化时调整当前页
watch(
  () => step2TableData.value.length,
  (newLen) => {
    const totalPages = Math.ceil(newLen / pageSize.value);
    if (currentPage.value > totalPages) {
      currentPage.value = totalPages || 1;
    }
  }
);

// Type变化监听，初始化condition和docIdList
watch(
  () => step2TableData.value,
  (newVal) => {
    if (newVal) {
      newVal.forEach((row) => {
        if (!row.condition) row.condition = [];
        if (!row.docIdList) row.docIdList = [...row.condition]; // 同步
      });
    }
  },
  { deep: true }
);

defineExpose({
  handleOpen,
});
</script>

<style scoped>
.step2-content {
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.step1-preview {
  background: #f5f7fa;
  padding: 15px;
  border-radius: 4px;
}
.step2-table {
  flex: 1;
}
.dialog-footer {
  text-align: right;
}
.input-new-tag {
  width: 100%;
}
.pagination :deep(.el-pagination__jump) {
  margin-left: auto;
}
</style>
<!-- 1 -->
<!-- import dayjs from 'dayjs'

const target = dayjs('2025-10-15') // 目标时间
const isAfterToday = target.isAfter(dayjs().startOf('day'))

console.log(isAfterToday) // true 表示比今天的时间大（即今天之后） -->

<!-- 
2
const target = dayjs('2025-10-15 12:00')
const isAfterNow = target.isAfter(dayjs())

console.log(isAfterNow) // true 表示比当前时间晚 -->

<!-- 3
const target = dayjs('2025-10-13 10:00')
const isToday = target.isSame(dayjs(), 'day')

console.log(isToday) // true 表示目标时间在今天 -->

<!-- 4
const target = dayjs('2025-10-14')
const isFutureDay = target.isAfter(dayjs().endOf('day'))

console.log(isFutureDay) // true 表示目标日期在今天之后（不含今天） -->

<!-- 
5
function isAfterToday(date) {
  return dayjs(date).isAfter(dayjs().endOf('day'))
} -->
