<template>
  <el-dialog
    v-model="visible"
    title="文档配置"
    width="80%"
    :before-close="handleClose"
    append-to-body
  >
    <el-steps :active="active" finish-status="success">
      <el-step title="基本信息" />
      <el-step title="文档项配置" />
    </el-steps>

    <!-- 步骤1: 表单布局使用 row col -->
    <el-form
      ref="step1FormRef"
      :model="step1Form"
      :rules="rules"
      label-width="120px"
      v-if="active === 0"
    >
      <el-row :gutter="24">
        <el-col :span="8">
          <el-form-item label="Init Doc Name" prop="initDocName">
            <el-input
              v-model="step1Form.initDocName"
              placeholder="请输入文档名称"
            />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="Doc Class Code" prop="docClassCode">
            <el-select
              v-model="step1Form.docClassCode"
              multiple
              placeholder="请选择文档分类代码"
              style="width: 100%"
              clearable
            >
              <el-option
                v-for="item in docClassOptions"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="开始时间" prop="startDate">
            <el-date-picker
              v-model="step1Form.startDate"
              type="date"
              placeholder="选择日期"
              :picker-options="datePickerOptions"
              style="width: 100%"
            />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <!-- 步骤2: 显示步骤1置灰 + 表格 -->
    <div v-if="active === 1" class="step2-content">
      <!-- 步骤1内容（置灰显示，使用disabled表单） -->
      <div class="step1-preview">
        <h4>基本信息（查看）</h4>
        <el-form :model="step1Form" label-width="120px" disabled>
          <el-row :gutter="24">
            <el-col :span="8">
              <el-form-item label="Init Doc Name">
                <el-input
                  v-model="step1Form.initDocName"
                  placeholder="请输入文档名称"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="Doc Class Code">
                <el-select
                  v-model="step1Form.docClassCode"
                  multiple
                  placeholder="请选择文档分类代码"
                  style="width: 100%"
                >
                  <el-option
                    v-for="item in docClassOptions"
                    :key="item"
                    :label="item"
                    :value="item"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="开始时间">
                <el-date-picker
                  v-model="step1Form.startDate"
                  type="date"
                  placeholder="选择日期"
                  :picker-options="datePickerOptions"
                  style="width: 100%"
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <!-- 步骤2表格 -->
      <div class="step2-table">
        <h4>文档项配置</h4>
        <el-table
          :data="step2TableData"
          border
          style="width: 100%; margin-top: 10px"
          :show-overflow-tooltip="true"
        >
          <el-table-column type="index" label="序号" width="80" fixed="left" />
          <el-table-column
            prop="docItemName"
            label="Doc Item Name"
            min-width="150"
          >
            <template #default="scope">
              <el-input v-model="scope.row.docItemName" size="small" />
            </template>
          </el-table-column>
          <el-table-column
            prop="docClassCode"
            label="Doc Class Code"
            min-width="150"
          >
            <template #default="scope">
              <el-input
                v-model="scope.row.docClassCode"
                size="small"
                disabled
              />
            </template>
          </el-table-column>
          <el-table-column
            v-if="props.mode === 'CONFIGURATION'"
            prop="status"
            label="Status"
            width="100"
          >
            <template #default="scope">
              <span>{{ scope.row.status || "N/A" }}</span>
            </template>
          </el-table-column>
          <el-table-column label="Type" min-width="120">
            <template #default="scope">
              <el-select
                v-model="scope.row.type"
                placeholder="请选择类型"
                size="small"
                clearable
                @change="handleTypeChange(scope.row)"
              >
                <el-option label="INIT" value="INIT" />
                <el-option label="LIST" value="LIST" />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column label="Condition" min-width="300">
            <template #default="scope">
              <div v-if="scope.row.type === 'INIT'">
                <el-date-picker
                  v-model="scope.row.dateStartTime"
                  type="date"
                  placeholder="起始时间"
                  :picker-options="datePickerOptions"
                  size="small"
                  style="width: 45%; margin-right: 5px"
                />
                <el-date-picker
                  v-model="scope.row.dateEndTime"
                  type="date"
                  placeholder="终止时间"
                  :picker-options="datePickerOptions"
                  size="small"
                  style="width: 50%"
                />
              </div>
              <div v-else-if="scope.row.type === 'LIST'">
                <el-input-tag
                  v-model="scope.row.condition"
                  placeholder="Please input"
                  class="input-new-tag"
                  size="small"
                />
              </div>
            </template>
          </el-table-column>
          <el-table-column label="DeliveryTime" min-width="150">
            <template #default="scope">
              <el-input v-model="scope.row.deliveryTime" size="small" />
            </template>
          </el-table-column>
          <el-table-column label="操作" width="150" fixed="right">
            <template #default="scope">
              <el-button
                type="text"
                size="small"
                @click="handleAddRow(scope.row)"
                >新增</el-button
              >
              <el-button
                type="text"
                size="small"
                @click="handleDeleteRow(scope.$index)"
                >删除</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>

    <template #footer>
      <span v-if="active === 0" class="dialog-footer">
        <el-button @click="handleClose">取消</el-button>
        <el-button type="primary" @click="handleNext">下一步</el-button>
      </span>
      <span v-else class="dialog-footer">
        <el-button @click="handlePrev">上一步</el-button>
        <el-button type="primary" @click="handleFinish">确认</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, reactive, nextTick, watch } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";

// 弹框可见性
const visible = ref(false);
// 当前步骤
const active = ref(0);
// 步骤1表单引用
const step1FormRef = ref();
// 步骤1表单数据
const step1Form = reactive({
  initDocName: "",
  docClassCode: [],
  startDate: null,
});
// 验证规则
const rules = reactive({
  initDocName: [{ required: true, message: "请输入文档名称", trigger: "blur" }],
  docClassCode: [
    {
      required: true,
      message: "请选择分类代码",
      trigger: "change",
      type: "array",
      min: 1,
    },
  ],
  startDate: [{ required: true, message: "请选择开始时间", trigger: "change" }],
});
// docClassCode 选项（扩展到10个）
const docClassOptions = [
  "DOC001",
  "DOC002",
  "DOC003",
  "DOC004",
  "DOC005",
  "DOC006",
  "DOC007",
  "DOC008",
  "DOC009",
  "DOC010",
];
// 日期选择器选项（大于今天，当前日期 2025-10-09）
const today = new Date("2025-10-09");
const datePickerOptions = {
  disabledDate(time) {
    return time.getTime() <= today.getTime();
  },
};
// 步骤2表格数据
const step2TableData = ref([]);
// 新增：CONFIG模式下的原始数据缓存（用于比对变化）和删除ID集合
const originalTableData = ref([]);
const deletedIds = ref([]);
// 新增：缓存数据和旧docClassCodes（ADD模式用）
const cachedTableData = ref([]);
const oldDocClassCodes = ref([]);

const props = defineProps({
  mode: {
    type: String,
    default: "ADD",
  },
  payload: {
    type: Object,
    default: null,
  },
});

// 模板数据
const dataModal = {
  sort: 1,
  type: "INIT",
  condition: [],
  docIdList: [],
  deliveryTime: "",
  status: "ONGOING", // CONFIG模式默认ONGOING
  docItemName: "",
  docClassCode: "",
  dateStartTime: null,
  dateEndTime: null,
  initBatchTaskId: null,
  initDomainTaskId: null,
};

// 模拟后端请求：根据docClassCode返回对应docItemName列表（ADD用）
const fetchDocItems = async (codes) => {
  // 模拟延迟
  await new Promise((resolve) => setTimeout(resolve, 500));
  // Mock映射：DOC001 -> '电影', DOC002 -> '电视剧', 等
  const mockMap = {
    DOC001: "电影",
    DOC002: "电视剧",
    DOC003: "音乐",
    DOC004: "综艺",
    DOC005: "小说",
    DOC006: "漫画",
    DOC007: "游戏",
    DOC008: "动漫",
    DOC009: "纪录片",
    DOC010: "访谈",
  };
  const data = codes.map((code) => ({
    docItemName: mockMap[code] || "未知",
    docClassCode: code,
  }));
  return {
    code: 200,
    message: "success",
    data,
  };
};

// 模拟创建基本信息接口：返回initBatchTaskId（ADD用）
const createInitDoc = async (formData) => {
  // 模拟延迟
  await new Promise((resolve) => setTimeout(resolve, 300));
  // Mock返回：假设成功，生成一个随机ID
  const initBatchTaskId = `BATCH_${Date.now()}_${Math.random()
    .toString(36)
    .substr(2, 9)}`;
  return {
    code: 200,
    message: "success",
    data: {
      initBatchTaskId,
    },
  };
};

// 比较两个对象是否相同（忽略undefined/null，JSON.stringify简单比对）
const isObjectChanged = (original, current) => {
  const excludeKeys = ["sort"]; // 可扩展排除键
  const origStr = JSON.stringify({
    ...original,
    ...Object.fromEntries(
      Object.entries(original).filter(([k]) => !excludeKeys.includes(k))
    ),
  });
  const currStr = JSON.stringify({
    ...current,
    ...Object.fromEntries(
      Object.entries(current).filter(([k]) => !excludeKeys.includes(k))
    ),
  });
  return origStr !== currStr;
};

// Type变化处理：同步condition到docIdList
const handleTypeChange = (row) => {
  if (row.type === "LIST") {
    row.docIdList = [...row.condition];
  } else {
    row.docIdList = [];
  }
};

// 新增行：基于当前行继承docClassCode和docItemName（作为模板），添加到最后
const handleAddRow = (currentRow = null) => {
  const newRow = { ...dataModal };
  newRow.sort = step2TableData.value.length + 1;
  newRow.initBatchTaskId = step2TableData.value[0]?.initBatchTaskId || null; // 继承batch ID，如果有
  if (currentRow) {
    newRow.docClassCode = currentRow.docClassCode; // 继承docClassCode
    newRow.docItemName = currentRow.docItemName; // 继承docItemName（用户可编辑）
  }
  // 如果无currentRow（fallback），docClassCode/docItemName为空
  step2TableData.value.push(newRow);
};

// 删除行并重新排序（CONFIG: 收集initDomainTaskId）
const handleDeleteRow = (index) => {
  ElMessageBox.confirm("确定删除该行吗？", "提示", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  }).then(() => {
    const row = step2TableData.value[index];
    if (row.initDomainTaskId && props.mode === "CONFIGURATION") {
      deletedIds.value.push(row.initDomainTaskId);
    }
    step2TableData.value.splice(index, 1);
    // 重新排序sort
    step2TableData.value.forEach((row, idx) => {
      row.sort = idx + 1;
    });
    ElMessage.success("删除成功");
  });
};

// 步骤1下一步：验证 + 处理docClassCode变化 + 模拟创建基本信息 + 初始化/更新表格（仅ADD用）
const handleNext = async () => {
  try {
    await step1FormRef.value.validate();
    const newCodes = step1Form.docClassCode;
    if (newCodes.length === 0) {
      ElMessage.error("请选择至少一个分类代码");
      return;
    }

    // 模拟创建基本信息，获取initBatchTaskId（每次next都重新创建，或根据需求缓存）
    const createResponse = await createInitDoc(step1Form);
    if (createResponse.code !== 200) {
      ElMessage.error(createResponse.message || "创建基本信息失败");
      return;
    }
    const initBatchTaskId = createResponse.data.initBatchTaskId;

    let updatedTableData;
    if (
      oldDocClassCodes.value.length === 0 ||
      cachedTableData.value.length === 0
    ) {
      // 首次进入或无缓存：正常创建
      const response = await fetchDocItems(newCodes);
      if (response.code !== 200) {
        ElMessage.error(response.message || "请求失败");
        return;
      }
      updatedTableData = response.data.map((item, index) => {
        const row = { ...dataModal };
        row.docItemName = item.docItemName;
        row.docClassCode = item.docClassCode;
        row.sort = index + 1;
        row.status = props.mode === "CONFIGURATION" ? "ONGOING" : "";
        row.initBatchTaskId = initBatchTaskId;
        row.condition = [];
        row.docIdList = [];
        return row;
      });
    } else {
      // 有缓存：处理变化
      const addedCodes = newCodes.filter(
        (code) => !oldDocClassCodes.value.includes(code)
      );
      const removedCodes = oldDocClassCodes.value.filter(
        (code) => !newCodes.includes(code)
      );

      // 保留：过滤掉removed的cached
      updatedTableData = cachedTableData.value.filter(
        (row) => !removedCodes.includes(row.docClassCode)
      );

      // 新增：为addedCodes添加新行
      if (addedCodes.length > 0) {
        const newItemsResponse = await fetchDocItems(addedCodes);
        if (newItemsResponse.code === 200) {
          const newRows = newItemsResponse.data.map((item, index) => {
            const row = { ...dataModal };
            row.docItemName = item.docItemName;
            row.docClassCode = item.docClassCode;
            row.sort = updatedTableData.length + index + 1;
            row.initBatchTaskId = initBatchTaskId;
            row.condition = [];
            row.docIdList = [];
            row.status = props.mode === "CONFIGURATION" ? "ONGOING" : "";
            return row;
          });
          updatedTableData = [...updatedTableData, ...newRows];
        } else {
          ElMessage.error(newItemsResponse.message || "新增数据请求失败");
          return;
        }
      }

      // 确保所有行有initBatchTaskId（更新）
      updatedTableData.forEach((row) => {
        row.initBatchTaskId = initBatchTaskId;
      });
    }

    // 重新排序
    updatedTableData.forEach((row, idx) => {
      row.sort = idx + 1;
    });

    step2TableData.value = updatedTableData;

    // 更新oldCodes为newCodes（下次用）
    oldDocClassCodes.value = [...newCodes];

    active.value = 1;
  } catch {
    ElMessage.error("请检查表单填写是否完整");
  }
};

// 上一步：缓存数据和旧codes（仅ADD用）
const handlePrev = () => {
  // 只在有数据时缓存（避免空缓存）
  if (step2TableData.value.length > 0 && props.mode === "ADD") {
    cachedTableData.value = [...step2TableData.value];
    oldDocClassCodes.value = [...step1Form.docClassCode];
  }
  active.value = 0;
};

// 确认：构建add/update/delete（CONFIG: 比对变化；ADD: 只add）
const handleFinish = () => {
  const submitData = {
    addList: [],
    updateList: [],
    deleteList: deletedIds.value,
  };

  if (props.mode === "CONFIGURATION") {
    // CONFIG: add (无initDomainTaskId), update (有ID且变化)
    step2TableData.value.forEach((row) => {
      if (!row.initDomainTaskId) {
        // 新增
        submitData.addList.push({
          ...row,
          ...(row.type === "LIST" && { docIdList: [...row.condition] }),
        });
      } else {
        // 编辑：找原始对应行比对
        const origRow = originalTableData.value.find(
          (o) => o.initDomainTaskId === row.initDomainTaskId
        );
        if (origRow && isObjectChanged(origRow, row)) {
          submitData.updateList.push({
            ...row,
            ...(row.type === "LIST" && { docIdList: [...row.condition] }),
          });
        }
      }
    });
  } else {
    // ADD: 全addList
    submitData.addList = step2TableData.value.map((row) => ({
      ...row,
      ...(row.type === "LIST" && { docIdList: [...row.condition] }),
    }));
  }

  // 模拟后端提交
  console.log("提交数据到后端：", submitData);
  ElMessage.success("提交成功");
  handleClose();
};

// 关闭弹框
const handleClose = () => {
  visible.value = false;
  active.value = 0;
  // 重置所有
  Object.assign(step1Form, {
    initDocName: "",
    docClassCode: [],
    startDate: null,
  });
  step2TableData.value = [];
  cachedTableData.value = [];
  oldDocClassCodes.value = [];
  originalTableData.value = [];
  deletedIds.value = [];
};

// 暴露的打开函数
const handleOpen = async (mode, payload = null) => {
  deletedIds.value = []; // 重置删除ID
  if (mode === "CONFIGURATION") {
    // CONFIG模式：直接mock表单和表格数据（无需payload或fetch）
    // Mock表单数据
    Object.assign(step1Form, {
      initDocName: "配置文档示例",
      docClassCode: ["DOC001", "DOC003"], // 对应表格docClassCode
      startDate: new Date("2025-10-10"),
    });
    active.value = 1; // 直接第二步

    // Mock表格数据：3行，带initDomainTaskId，docClassCode匹配表单，status有值
    step2TableData.value = [
      {
        sort: 1,
        type: "INIT",
        condition: [],
        docIdList: [],
        deliveryTime: "2025-10-15",
        status: "ONGOING",
        docItemName: "电影子项1",
        docClassCode: "DOC001",
        dateStartTime: new Date("2025-10-12"),
        dateEndTime: new Date("2025-10-14"),
        initBatchTaskId: "BATCH_1728480000000_abc123",
        initDomainTaskId: "DOMAIN_1728480000000_task1",
      },
      {
        sort: 2,
        type: "LIST",
        condition: ["tagA", "tagB"],
        docIdList: ["tagA", "tagB"],
        deliveryTime: "2025-10-18",
        status: "PAUSE",
        docItemName: "音乐子项1",
        docClassCode: "DOC003",
        dateStartTime: null,
        dateEndTime: null,
        initBatchTaskId: "BATCH_1728480000000_abc123",
        initDomainTaskId: "DOMAIN_1728480000000_task2",
      },
      {
        sort: 3,
        type: "INIT",
        condition: [],
        docIdList: [],
        deliveryTime: "",
        status: "COMPLETE",
        docItemName: "电影子项2",
        docClassCode: "DOC001",
        dateStartTime: new Date("2025-10-16"),
        dateEndTime: new Date("2025-10-20"),
        initBatchTaskId: "BATCH_1728480000000_abc123",
        initDomainTaskId: "DOMAIN_1728480000000_task3",
      },
    ];
    // 缓存原始数据用于比对
    originalTableData.value = [...step2TableData.value];
    // 确保初始化
    step2TableData.value.forEach((row) => {
      if (!row.condition) row.condition = [];
      if (!row.docIdList) row.docIdList = row.condition;
    });

    // 重置ADD缓存
    cachedTableData.value = [];
    oldDocClassCodes.value = [];
  } else {
    // ADD模式，初始化空表格（handleNext会填充），active=0
    step2TableData.value = [];
    active.value = 0;
    cachedTableData.value = [];
    oldDocClassCodes.value = [];
    originalTableData.value = [];
  }
  visible.value = true;
};

// Type变化监听，初始化condition和docIdList
watch(
  () => step2TableData.value,
  (newVal) => {
    if (newVal) {
      newVal.forEach((row) => {
        if (!row.condition) row.condition = [];
        if (!row.docIdList) row.docIdList = row.condition; // 同步
      });
    }
  },
  { deep: true }
);

defineExpose({
  handleOpen,
});
</script>

<style scoped>
.step2-content {
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.step1-preview {
  background: #f5f7fa;
  padding: 15px;
  border-radius: 4px;
}
.step2-table {
  flex: 1;
}
.dialog-footer {
  text-align: right;
}
.input-new-tag {
  width: 100%;
}
</style>
