<template>
  <div class="doc-table">
    <el-button type="primary" @click="handleCreate">创建</el-button>
    <el-table :data="tableData" style="width: 100%; margin-top: 20px">
      <el-table-column type="index" label="序号" width="80" />
      <el-table-column prop="status" label="Status" width="120" />
      <el-table-column prop="docItemName" label="Doc Item Name" width="150" />
      <el-table-column prop="docClassCode" label="Doc Class Code" width="150" />
      <el-table-column prop="createTime" label="创建时间" width="150" />
      <el-table-column label="操作" width="120" fixed="right">
        <template #default="scope">
          <!-- 这里可以基于 scope.row.status 添加条件，例如 if (status !== 'COMPLETE') 显示按钮 -->
          <el-button type="text" size="small" @click="handleEdit(scope.row)">
            配置
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>

  <!-- 组件 -->
  <InitDialog ref="initDialogRef" />
</template>

<script setup>
import { ref, useTemplateRef } from "vue";

import InitDialog from "./InitDialog.vue";

// mock 数据：4 条，每种 status 一条
const tableData = ref([
  {
    status: "ONGOING",
    docItemName: "文档项1",
    docClassCode: "CLASS001",
    createTime: "2025-10-01 10:00:00",
  },
  {
    status: "PAUSE",
    docItemName: "文档项2",
    docClassCode: "CLASS002",
    createTime: "2025-10-02 11:00:00",
  },
  {
    status: "COMPLETE",
    docItemName: "文档项3",
    docClassCode: "CLASS003",
    createTime: "2025-10-03 12:00:00",
  },
  {
    status: "PENDING",
    docItemName: "文档项4",
    docClassCode: "CLASS004",
    createTime: "2025-10-04 13:00:00",
  },
]);

// const
// 创建按钮点击事件
const initDialogRefEL = useTemplateRef("initDialogRef");
const handleCreate = () => {
  console.log("点击创建，打开创建弹窗或路由");
  let payload = {};
  // 这里可以添加你的创建逻辑，例如打开 Dialog 或跳转页面
  initDialogRefEL.value.handleOpen("ADD", payload);
};

// 编辑按钮点击事件（配置）
const handleEdit = (row) => {
  console.log("编辑行数据：", row);
  let payload = row;
  // 这里可以添加你的编辑逻辑，例如打开编辑弹窗，并传入 row 数据
  // 可以基于 row.status 添加条件，例如 if (row.status === 'COMPLETE') { alert('已完成，无法编辑') }
  initDialogRefEL.value.handleOpen("ADD", payload);
};
</script>

<style scoped>
.doc-table {
  padding: 20px;
}
</style>
