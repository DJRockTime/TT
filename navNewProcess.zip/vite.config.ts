import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import { resolve } from "path";

// 自动引入插件（强烈推荐，极大提升实验与开发效率）
import AutoImport from "unplugin-auto-import/vite";
import Components from "unplugin-vue-components/vite";
import { ElementPlusResolver } from "unplugin-vue-components/resolvers";

// https://vite.dev/config/
export default defineConfig({
    plugins: [
        vue(),

        // 1. 自动引入 Vue, Vue-Router, Pinia, VueUse 的常用 API
        AutoImport({
            imports: ["vue", "vue-router", "pinia", "@vueuse/core"],
            resolvers: [ElementPlusResolver()],
            dts: "src/auto-imports.d.ts", // 生成 TS 声明文件
        }),

        // 2. 自动引入 Element Plus 组件
        Components({
            resolvers: [ElementPlusResolver()],
            dts: "src/components.d.ts", // 生成 TS 声明文件
        }),
    ],

    resolve: {
        // 3. 配置路径别名：使用 @ 指向 src 目录
        alias: {
            "@": resolve(__dirname, "./src"),
        },
    },

    css: {
        // 4. Less 全局配置
        preprocessorOptions: {
            less: {
                javascriptEnabled: true,
                // 如果有全局 Less 变量文件，可以在此处注入（可选）
                // additionalData: `@import "@/assets/styles/variables.less";`
            },
        },
    },

    // 5. 开发服务器配置
    server: {
        host: "0.0.0.0", // 允许通过局域网 IP 访问
        port: 3000, // 指定开发服务器端口
        open: true, // 启动服务时自动在浏览器打开
        cors: true, // 允许跨域

        // 预留反向代理配置，方便您后续做接口联调实验
        proxy: {
            "/api": {
                target: "http://localhost:8080", // 您的后端接口地址
                changeOrigin: true,
                rewrite: (path) => path.replace(/^\/api/, ""),
            },
        },
    },
});
