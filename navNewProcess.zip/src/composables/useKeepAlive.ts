import { computed, type MaybeRefOrGetter, toValue } from "vue";
import { useStorage } from "@vueuse/core";

/* =========================================================
 * KeepAlive State
 *
 * 业务级页面状态缓存
 *
 * 不使用 Vue <KeepAlive>
 *
 * 存储：
 * sessionStorage
 *
 * Key：
 * keepAlive:${path}
 * ========================================================= */

export type KeepAliveState = Record<string, unknown>;

/* =========================================================
 * Key
 * ========================================================= */

function getStorageKey(path: string) {
  return `keepAlive:${path}`;
}

/* =========================================================
 * 深度复制初始状态
 *
 * 防止不同页面之间引用同一个对象。
 * ========================================================= */

function cloneInitialState<T>(value: T): T {
  if (value === undefined || value === null) {
    return value;
  }

  if (typeof structuredClone === "function") {
    return structuredClone(value);
  }

  return JSON.parse(JSON.stringify(value));
}

/* =========================================================
 * useKeepAlive
 *
 * 页面使用：
 *
 * const { state, clear } = useKeepAlive(
 *   "/document/category",
 *   {
 *     formData: {},
 *     scrollTop: 0,
 *     rules: {},
 *   },
 * );
 *
 * ========================================================= */

export function useKeepAlive<T extends KeepAliveState>(
  path: MaybeRefOrGetter<string>,
  initialState: T,
) {
  const resolvedPath = computed(() => toValue(path));

  /*
   * VueUse useStorage
   *
   * sessionStorage：
   * 页面刷新仍然存在
   * 浏览器会话结束后消失
   */
  const state = useStorage<T>(
    computed(() => getStorageKey(resolvedPath.value)),
    cloneInitialState(initialState),
    sessionStorage,
    {
      deep: true,
    },
  );

  /* =======================================================
   * 是否存在缓存
   * ======================================================= */

  const hasState = computed(() => {
    return Object.keys(state.value ?? {}).length > 0;
  });

  /* =======================================================
   * 清除当前页面
   * ======================================================= */

  function clear() {
    sessionStorage.removeItem(getStorageKey(resolvedPath.value));

    state.value = cloneInitialState(initialState);
  }

  /* =======================================================
   * 返回
   * ======================================================= */

  return {
    state,

    hasState,

    clear,

    key: computed(() => getStorageKey(resolvedPath.value)),
  };
}

/* =========================================================
 * 删除单个页面 KeepAlive
 *
 * useDropKeepAlive("/document/category")
 *
 * ========================================================= */

function dropRouteKeepAlive(path: string) {
  if (!path) {
    return;
  }

  sessionStorage.removeItem(getStorageKey(path));
}

/* =========================================================
 * 删除模块 KeepAlive
 *
 * useDropKeepAlive.module("document")
 *
 * 删除：
 *
 * keepAlive:/document/category
 * keepAlive:/document/template
 *
 * 但不会删除：
 *
 * keepAlive:/document/category/1001
 *
 * 详情页由自己的 Detail Tag 单独管理。
 * ========================================================= */

function dropModuleKeepAlive(module: string) {
  if (!module) {
    return;
  }

  const prefix = `keepAlive:/${module}/`;

  const keys: string[] = [];

  for (let index = 0; index < sessionStorage.length; index++) {
    const key = sessionStorage.key(index);

    if (!key) {
      continue;
    }

    /*
     * 只处理 KeepAlive
     */
    if (!key.startsWith(prefix)) {
      continue;
    }

    const path = key.slice("keepAlive:".length);

    /*
     * 详情页判断：
     *
     * /document/category
     *       只有两个路径段
     *
     * /document/category/1001
     *       三个以上路径段
     *
     * 当前项目详情页通常属于这种形式。
     *
     * 这里暂时不删除详情。
     */
    const segments = path.split("/").filter(Boolean);

    if (segments.length > 2) {
      continue;
    }

    keys.push(key);
  }

  keys.forEach((key) => {
    sessionStorage.removeItem(key);
  });
}

/* =========================================================
 * 删除全部 KeepAlive
 *
 * 预留。
 * ========================================================= */

function dropAllKeepAlive() {
  const keys: string[] = [];

  for (let index = 0; index < sessionStorage.length; index++) {
    const key = sessionStorage.key(index);

    if (key?.startsWith("keepAlive:")) {
      keys.push(key);
    }
  }

  keys.forEach((key) => {
    sessionStorage.removeItem(key);
  });
}

/* =========================================================
 * 统一删除 API
 *
 * useDropKeepAlive.route(path)
 *
 * useDropKeepAlive.module(module)
 *
 * useDropKeepAlive.all()
 * ========================================================= */

export const useDropKeepAlive = {
  all: dropAllKeepAlive,
  route: dropRouteKeepAlive,
  module: dropModuleKeepAlive,
};
