import { defineStore } from "pinia";

import type { RouteRecordRaw } from "vue-router";

import accessControlRoutes from "@/router/access-control.ts";
import organizationRoutes from "@/router/organization.ts";
import opsRoutes from "@/router/ops.ts";
import documentRoutes from "@/router/document.ts";

/* =========================================================
 * 模块类型
 * ========================================================= */

export type ModuleKey = "access-control" | "organization" | "ops" | "document";

/* =========================================================
 * 模块信息
 * ========================================================= */

export interface ModuleItem {
  key: ModuleKey;
  title: string;
  icon: string;
}

/* =========================================================
 * 四大模块
 *
 * 后续新增模块，只需要在这里增加。
 * ========================================================= */

export const modules: ModuleItem[] = [
  {
    key: "access-control",
    title: "权限控制中心",
    icon: "🍃",
  },
  {
    key: "organization",
    title: "组织架构管理",
    icon: "🏀",
  },
  {
    key: "ops",
    title: "系统运维监控",
    icon: "🥝",
  },
  {
    key: "document",
    title: "文档基础配置",
    icon: "⚾",
  },
];

/* =========================================================
 * 模块路由
 * ========================================================= */

export const moduleRouteMap: Record<ModuleKey, RouteRecordRaw[]> = {
  "access-control": accessControlRoutes,
  organization: organizationRoutes,
  ops: opsRoutes,
  document: documentRoutes,
};

/* =========================================================
 * Store
 * ========================================================= */

export const useLayoutStore = defineStore("layout", {
  state: () => ({
    /*
     * 当前模块
     */
    currentModule: "access-control" as ModuleKey,
  }),

  getters: {
    /* -----------------------------------------------
     * 当前模块信息
     * ----------------------------------------------- */

    currentModuleInfo(state) {
      return modules.find((item) => item.key === state.currentModule);
    },

    /* -----------------------------------------------
     * 当前模块标题
     * ----------------------------------------------- */

    currentModuleTitle(state) {
      return modules.find((item) => item.key === state.currentModule)?.title ?? "";
    },

    /* -----------------------------------------------
     * 当前模块图标
     * ----------------------------------------------- */

    currentModuleIcon(state) {
      return modules.find((item) => item.key === state.currentModule)?.icon ?? "";
    },

    /* -----------------------------------------------
     * 当前模块路由
     * ----------------------------------------------- */

    currentRoutes(state) {
      return moduleRouteMap[state.currentModule] ?? [];
    },
  },

  actions: {
    /* =================================================
     * 设置当前模块
     * ================================================= */

    setCurrentModule(module: ModuleKey) {
      this.currentModule = module;
    },

    /* =================================================
     * 根据路由路径判断模块
     *
     * 例如：
     *
     * /access-control/user/list
     *       ↓
     * access-control
     *
     * /organization/user
     *       ↓
     * organization
     * ================================================= */

    syncModuleByPath(path: string) {
      const module = modules.find(
        (item) => path === `/${item.key}` || path.startsWith(`/${item.key}/`),
      );

      if (module) {
        this.currentModule = module.key;
      }
    },
  },
});
