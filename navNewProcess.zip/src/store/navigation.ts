import { ref } from "vue";

import { defineStore } from "pinia";

/* =========================================================
 * 模块页面导航记忆
 *
 * 规则：
 *
 * module
 *   ↓
 * 最后访问的普通子路由 path
 *
 * 例如：
 *
 * {
 *   "access-control": "/access-control/role",
 *   "organization": "/organization/position",
 *   "ops": "/ops/log",
 *   "document": "/document/template"
 * }
 *
 * 注意：
 *
 * 这是运行时记忆。
 *
 * 不写 localStorage。
 *
 * 因为：
 *
 * CustomerTag 生命周期
 *        ↓
 * Tag 关闭
 *        ↓
 * 模块记忆删除
 *
 * 页面刷新后重新建立新的 Tag 生命周期。
 * ========================================================= */

export type NavigationMemory = Record<string, string>;

export const useNavigationStore = defineStore("navigation", () => {
  /* =======================================================
   * Memory
   * ======================================================= */

  const memory = ref<NavigationMemory>({});

  /* =======================================================
   * 获取某个模块记忆的页面
   * ======================================================= */

  function getRememberedRoute(module: string): string | null {
    if (!module) {
      return null;
    }

    return memory.value[module] ?? null;
  }

  /* =======================================================
   * 判断模块是否存在记忆
   * ======================================================= */

  function hasRememberedRoute(module: string): boolean {
    if (!module) {
      return false;
    }

    return Boolean(memory.value[module]);
  }

  /* =======================================================
   * 记录模块当前页面
   *
   * Router afterEach 会统一调用。
   * ======================================================= */

  function rememberRoute(module: string, path: string) {
    if (!module || !path) {
      return;
    }

    memory.value = {
      ...memory.value,

      [module]: path,
    };
  }

  /* =======================================================
   * 删除模块记忆
   *
   * CustomerTags 关闭模块 Tag 时调用。
   *
   * 例如：
   *
   * document
   *   ↓
   * /document/template
   *
   * 关闭 Document Tag
   *   ↓
   * 删除 document
   * ======================================================= */

  function removeRememberedRoute(module: string) {
    if (!module) {
      return;
    }

    if (!Object.prototype.hasOwnProperty.call(memory.value, module)) {
      return;
    }

    const next = {
      ...memory.value,
    };

    delete next[module];

    memory.value = next;
  }

  /* =======================================================
   * 清空全部记忆
   *
   * 预留给：
   *
   * 退出登录
   * 用户切换
   * 系统重置
   * ======================================================= */

  function clearAll() {
    memory.value = {};
  }

  /* =======================================================
   * 暴露
   * ======================================================= */

  return {
    memory,

    getRememberedRoute,

    hasRememberedRoute,

    rememberRoute,

    removeRememberedRoute,

    clearAll,
  };
});
