import { defineStore } from "pinia";
import { ref } from "vue";

export const useFormStore = defineStore("formStore", () => {
  const formData = ref({
    price: "10.25",
    quantity: "3",
    result: "0",
  });

  return { formData };
});
