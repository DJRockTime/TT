import { computed } from "vue";
import { defineStore } from "pinia";
import { useStorage } from "@vueuse/core";

/* =========================================================
 * 模块页面导航记忆
 *
 * 规则：
 *
 * module
 *   ↓
 * 最后访问的普通页面 path
 *
 * 例如：
 *
 * {
 *   "access-control": "/access-control/user",
 *   "organization": "/organization/department"
 * }
 *
 * ========================================================= */

export type NavigationMemory = Record<string, string>;

export const useNavigationStore = defineStore("navigation", () => {
  /* =======================================================
   * VueUse 持久化
   *
   * localStorage:
   *
   * navigation-memory
   * ======================================================= */

  const memory = useStorage<NavigationMemory>("navigation-memory", {});

  /* =======================================================
   * 获取某个模块记忆的页面
   * ======================================================= */

  function getRememberedRoute(module: string): string | null {
    return memory.value[module] ?? null;
  }

  /* =======================================================
   * 判断模块是否存在记忆
   * ======================================================= */

  function hasRememberedRoute(module: string): boolean {
    return Boolean(memory.value[module]);
  }

  /* =======================================================
   * 记录模块当前页面
   * ======================================================= */

  function rememberRoute(module: string, path: string) {
    if (!module || !path) {
      return;
    }

    memory.value = {
      ...memory.value,

      [module]: path,
    };
  }

  /* =======================================================
   * 删除模块记忆
   *
   * ★ CustomerTags 关闭 Tag 时调用
   * ======================================================= */

  function removeRememberedRoute(module: string) {
    if (!Object.prototype.hasOwnProperty.call(memory.value, module)) {
      return;
    }

    const next = {
      ...memory.value,
    };

    delete next[module];

    memory.value = next;
  }

  /* =======================================================
   * 清空全部记忆
   *
   * 目前不用。
   * 给以后退出登录 / 用户切换预留。
   * ======================================================= */

  function clearAll() {
    memory.value = {};
  }

  /* =======================================================
   * 暴露
   * ======================================================= */

  return {
    memory,

    getRememberedRoute,

    hasRememberedRoute,

    rememberRoute,

    removeRememberedRoute,

    clearAll,
  };
});
