import type { RouteRecordRaw } from "vue-router";

const organizationRoutes: RouteRecordRaw[] = [
  {
    path: "/organization",

    name: "Organization",

    redirect: "/organization/department",

    meta: {
      title: "组织架构管理",

      module: "organization",
    },

    children: [
      {
        path: "department",

        name: "DepartmentManage",

        component: () => import("@/views/organization/department/DepartmentList.vue"),

        meta: {
          title: "组织机构",

          permission: "organization:department",

          module: "organization",
        },
      },

      {
        path: "position",

        name: "PositionManage",

        component: () => import("@/views/organization/position/PositionList.vue"),

        meta: {
          title: "岗位管理",

          permission: "organization:position",

          module: "organization",
        },
      },
    ],
  },
];

export default organizationRoutes;
