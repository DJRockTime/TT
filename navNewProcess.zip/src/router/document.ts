import type { RouteRecordRaw } from "vue-router";

const documentRoutes: RouteRecordRaw[] = [
  {
    path: "/document",

    name: "Document",

    redirect: "/document/category",

    meta: {
      title: "文档基础配置",

      module: "document",
    },

    children: [
      {
        path: "category",

        name: "DocumentCategory",

        component: () => import("@/views/document/category/DocumentCategory.vue"),

        meta: {
          title: "文档分类",

          permission: "document:category",

          module: "document",
        },
      },

      {
        path: "template",

        name: "DocumentTemplate",

        component: () => import("@/views/document/template/DocumentTemplate.vue"),

        meta: {
          title: "文档模板",

          permission: "document:template",

          module: "document",
        },
      },
    ],
  },
];

export default documentRoutes;
