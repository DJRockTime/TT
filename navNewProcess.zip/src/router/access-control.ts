import type { RouteRecordRaw } from "vue-router";

const accessControlRoutes: RouteRecordRaw[] = [
  {
    path: "/access-control",

    name: "AccessControl",

    redirect: "/access-control/user",

    meta: {
      title: "权限控制中心",
      module: "access-control",
    },

    children: [
      // =====================================================
      // 用户管理
      // =====================================================
      {
        path: "user",

        name: "UserManage",

        component: () => import("@/views/access/user/UserList.vue"),

        meta: {
          title: "用户管理",
          permission: "access:user",
          module: "access-control",
        },
      },

      // =====================================================
      // 角色权限
      // =====================================================
      {
        path: "role",

        name: "RoleManage",

        component: () => import("@/views/access/role/RoleList.vue"),

        meta: {
          title: "角色权限",
          permission: "access:role",
          module: "access-control",
        },
      },

      // =====================================================
      // 角色详情
      // =====================================================
      {
        path: "role/:id",

        name: "RoleDetail",

        component: () => import("@/views/access/role/RoleDetail.vue"),

        meta: {
          title: "角色详情",
          permission: "access:role:detail",
          module: "access-control",
          // ★ 明确告诉 Tag 系统：
          // 这是一个详情页面
          detail: true,
        },
      },

      // =====================================================
      // 权限资源
      // =====================================================
      {
        path: "permission",
        name: "PermissionManage",
        component: () => import("@/views/access/permission/PermissionList.vue"),
        meta: {
          title: "权限资源",
          permission: "access:permission",
          module: "access-control",
        },
      },
    ],
  },
];

export default accessControlRoutes;
