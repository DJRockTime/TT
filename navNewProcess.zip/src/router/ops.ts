import type { RouteRecordRaw } from "vue-router";

const opsRoutes: RouteRecordRaw[] = [
  {
    path: "/ops",

    name: "Ops",

    redirect: "/ops/monitor",

    meta: {
      title: "系统运维监控",

      module: "ops",
    },

    children: [
      {
        path: "monitor",

        name: "SystemMonitor",

        component: () => import("@/views/ops/monitor/SystemMonitor.vue"),

        meta: {
          title: "系统监控",

          permission: "ops:monitor",

          module: "ops",
        },
      },

      {
        path: "log",

        name: "OperationLog",

        component: () => import("@/views/ops/log/OperationLog.vue"),

        meta: {
          title: "操作日志",

          permission: "ops:log",

          module: "ops",
        },
      },
    ],
  },
];

export default opsRoutes;
