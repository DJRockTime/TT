import {
  createRouter,
  createWebHistory,
  type RouteLocationNormalized,
  type RouteRecordRaw,
} from "vue-router";

import accessControlRoutes from "./access-control";
import organizationRoutes from "./organization";
import opsRoutes from "./ops";
import documentRoutes from "./document";

import { useNavigationStore } from "@/store/navigation.ts";

/* =========================================================
 * Routes
 * ========================================================= */

const routes: RouteRecordRaw[] = [
  // ==========================================
  // 默认入口
  // ==========================================
  {
    path: "/",

    component: () => import("@/views/layout/MainLayout.vue"),

    children: [
      // ==========================================
      // 权限控制中心
      // ==========================================
      ...accessControlRoutes,

      // ==========================================
      // 组织架构管理
      // ==========================================
      ...organizationRoutes,

      // ==========================================
      // 系统运维监控
      // ==========================================
      ...opsRoutes,

      // ==========================================
      // 文档基础配置
      // ==========================================
      ...documentRoutes,
    ],
  },

  // ==========================================
  // 404
  // ==========================================
  {
    path: "/:pathMatch(.*)*",

    name: "NotFound",

    component: () => import("@/views/NotFound.vue"),

    meta: {
      title: "页面不存在",
    },
  },
];

/* =========================================================
 * Router
 * ========================================================= */

const router = createRouter({
  history: createWebHistory(),

  routes,

  scrollBehavior() {
    return {
      top: 0,
    };
  },
});

/* =========================================================
 * 判断是否为详情路由
 *
 * 当前项目规则：
 *
 * 有 route.params
 *     ↓
 * 认为是详情页面
 *
 * 例如：
 *
 * /document/template
 *     params = {}
 *     ↓
 * 普通页面
 *
 * /document/template/123
 *     params = { id: "123" }
 *     ↓
 * 详情页面
 *
 * 详情页面不写模块导航记忆。
 * ========================================================= */

function isDetailRoute(to: RouteLocationNormalized): boolean {
  return Object.keys(to.params).length > 0;
}

/* =========================================================
 * 获取模块
 *
 * 子路由现在已经明确声明：
 *
 * meta.module
 *
 * 所以这里直接读取。
 * ========================================================= */

function getRouteModule(to: RouteLocationNormalized): string | undefined {
  const module = to.meta.module;

  if (typeof module !== "string" || !module) {
    return undefined;
  }

  return module;
}

/* =========================================================
 * Router → Navigation Memory
 *
 * ★★★ 整个导航记忆系统的核心 ★★★
 *
 * 所有真正完成的路由导航：
 *
 *     ↓
 *
 * afterEach
 *
 *     ↓
 *
 * navigationStore
 *
 *     ↓
 *
 * module → last child route
 *
 * ========================================================= */

router.afterEach((to) => {
  /* =======================================================
   * 详情页面不参与模块导航记忆
   * ======================================================= */

  if (isDetailRoute(to)) {
    return;
  }

  /* =======================================================
   * 获取模块
   * ======================================================= */

  const module = getRouteModule(to);

  if (!module) {
    return;
  }

  /* =======================================================
   * 获取导航 Store
   *
   * 注意：
   *
   * 这里是在 Router 真正开始运行以后执行，
   * 此时 Pinia 应用已经初始化。
   * ======================================================= */

  const navigationStore = useNavigationStore();

  /* =======================================================
   * 记录当前普通页面
   *
   * 例如：
   *
   * document
   *     ↓
   * /document/template
   *
   * 保存：
   *
   * {
   *   document: "/document/template"
   * }
   * ======================================================= */

  navigationStore.rememberRoute(module, to.fullPath);
});

export default router;
