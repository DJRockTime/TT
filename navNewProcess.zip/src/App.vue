<template>
  <main class="main-container">
    <router-view />
  </main>
</template>
<script setup lang="ts"></script>

<style lang="less" scoped>
#app {
  box-sizing: border-box;
  padding: 0px;
  margin: 0px;
}
.main-container {
  height: 100vh !important;
}
</style>
