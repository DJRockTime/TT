<template>
  <div class="page-container">
    <!-- 系统概览 -->
    <el-row :gutter="16" class="overview">
      <el-col :span="6">
        <el-card shadow="hover">
          <el-statistic title="CPU 使用率" :value="cpuUsage">
            <template #suffix>%</template>
          </el-statistic>

          <el-progress :percentage="cpuUsage" :show-text="false" class="progress" />
        </el-card>
      </el-col>

      <el-col :span="6">
        <el-card shadow="hover">
          <el-statistic title="内存使用率" :value="memoryUsage">
            <template #suffix>%</template>
          </el-statistic>

          <el-progress :percentage="memoryUsage" :show-text="false" class="progress" />
        </el-card>
      </el-col>

      <el-col :span="6">
        <el-card shadow="hover">
          <el-statistic title="磁盘使用率" :value="diskUsage">
            <template #suffix>%</template>
          </el-statistic>

          <el-progress :percentage="diskUsage" :show-text="false" class="progress" />
        </el-card>
      </el-col>

      <el-col :span="6">
        <el-card shadow="hover">
          <el-statistic title="在线用户" :value="onlineUsers">
            <template #suffix>人</template>
          </el-statistic>
        </el-card>
      </el-col>
    </el-row>

    <!-- 服务状态 -->
    <el-card shadow="never" class="service-card">
      <template #header>
        <div class="card-header">
          <span>服务状态</span>

          <el-button type="primary" plain size="small" @click="handleRefresh"> 刷新状态 </el-button>
        </div>
      </template>

      <el-table :data="serviceList" border stripe>
        <el-table-column prop="name" label="服务名称" min-width="180" />

        <el-table-column prop="address" label="服务地址" min-width="240" />

        <el-table-column prop="responseTime" label="响应时间" width="140">
          <template #default="{ row }"> {{ row.responseTime }} ms </template>
        </el-table-column>

        <el-table-column label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="row.status === 'running' ? 'success' : 'danger'">
              {{ row.status === "running" ? "运行中" : "异常" }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="updatedAt" label="最后检测" width="180" />
      </el-table>
    </el-card>

    <!-- 系统信息 -->
    <el-card shadow="never">
      <template #header> 系统信息 </template>

      <el-descriptions :column="3" border>
        <el-descriptions-item label="操作系统"> Windows Server 2025 </el-descriptions-item>

        <el-descriptions-item label="运行时间"> 18 天 06 小时 </el-descriptions-item>

        <el-descriptions-item label="Java"> JDK 25 </el-descriptions-item>

        <el-descriptions-item label="Spring Boot"> 4.0.1 </el-descriptions-item>

        <el-descriptions-item label="数据库"> MySQL 8.4 </el-descriptions-item>

        <el-descriptions-item label="服务器"> 192.168.1.100 </el-descriptions-item>
      </el-descriptions>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";

interface Service {
  name: string;
  address: string;
  responseTime: number;
  status: "running" | "error";
  updatedAt: string;
}

const cpuUsage = ref(42);
const memoryUsage = ref(68);
const diskUsage = ref(57);
const onlineUsers = ref(128);

const serviceList = ref<Service[]>([
  {
    name: "用户服务",
    address: "http://192.168.1.100:8081",
    responseTime: 28,
    status: "running",
    updatedAt: "2026-08-18 21:10:20",
  },
  {
    name: "权限服务",
    address: "http://192.168.1.100:8082",
    responseTime: 35,
    status: "running",
    updatedAt: "2026-08-18 21:10:18",
  },
  {
    name: "文档服务",
    address: "http://192.168.1.100:8083",
    responseTime: 86,
    status: "running",
    updatedAt: "2026-08-18 21:10:15",
  },
  {
    name: "消息服务",
    address: "http://192.168.1.100:8084",
    responseTime: 320,
    status: "error",
    updatedAt: "2026-08-18 21:10:12",
  },
]);

function handleRefresh() {
  cpuUsage.value = Math.floor(Math.random() * 30) + 35;
  memoryUsage.value = Math.floor(Math.random() * 20) + 55;
  diskUsage.value = Math.floor(Math.random() * 15) + 50;
  onlineUsers.value = Math.floor(Math.random() * 50) + 100;
}
</script>

<style scoped lang="less">
.page-container {
  padding: 20px;
}

.overview {
  margin-bottom: 16px;
}

.progress {
  margin-top: 18px;
}

.service-card {
  margin-bottom: 16px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
</style>
