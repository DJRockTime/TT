<template>
  <div class="page-container">
    <el-card shadow="never">
      <!-- 查询条件 -->
      <el-form :model="queryForm" inline>
        <el-form-item label="操作用户">
          <el-input v-model="queryForm.username" placeholder="请输入用户名" clearable />
        </el-form-item>

        <el-form-item label="操作类型">
          <el-select v-model="queryForm.type" placeholder="请选择" clearable style="width: 150px">
            <el-option label="新增" value="create" />
            <el-option label="修改" value="update" />
            <el-option label="删除" value="delete" />
            <el-option label="登录" value="login" />
          </el-select>
        </el-form-item>

        <el-form-item label="操作时间">
          <el-date-picker
            v-model="queryForm.dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
          />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleSearch"> 查询 </el-button>

          <el-button @click="handleReset"> 重置 </el-button>
        </el-form-item>
      </el-form>

      <el-divider />

      <!-- 日志表格 -->
      <el-table :data="tableData" border stripe>
        <el-table-column prop="username" label="操作用户" width="130" />

        <el-table-column prop="type" label="操作类型" width="110">
          <template #default="{ row }">
            <el-tag :type="getTypeTag(row.type)">
              {{ getTypeName(row.type) }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="module" label="操作模块" width="150" />

        <el-table-column
          prop="description"
          label="操作描述"
          min-width="260"
          show-overflow-tooltip
        />

        <el-table-column prop="ip" label="IP 地址" width="150" />

        <el-table-column prop="result" label="结果" width="100">
          <template #default="{ row }">
            <el-tag :type="row.result === 'success' ? 'success' : 'danger'">
              {{ row.result === "success" ? "成功" : "失败" }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="createdAt" label="操作时间" width="180" />

        <el-table-column label="详情" width="90" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleDetail(row as any)"> 查看 </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="pagination.total"
          background
          layout="total, sizes, prev, pager, next"
        />
      </div>
    </el-card>

    <!-- 日志详情 -->
    <el-drawer v-model="drawerVisible" title="操作日志详情" size="480px">
      <el-descriptions v-if="currentLog" :column="1" border>
        <el-descriptions-item label="操作用户">
          {{ currentLog.username }}
        </el-descriptions-item>

        <el-descriptions-item label="操作类型">
          {{ getTypeName(currentLog.type) }}
        </el-descriptions-item>

        <el-descriptions-item label="操作模块">
          {{ currentLog.module }}
        </el-descriptions-item>

        <el-descriptions-item label="操作描述">
          {{ currentLog.description }}
        </el-descriptions-item>

        <el-descriptions-item label="IP 地址">
          {{ currentLog.ip }}
        </el-descriptions-item>

        <el-descriptions-item label="操作时间">
          {{ currentLog.createdAt }}
        </el-descriptions-item>

        <el-descriptions-item label="操作结果">
          <el-tag :type="currentLog.result === 'success' ? 'success' : 'danger'">
            {{ currentLog.result === "success" ? "成功" : "失败" }}
          </el-tag>
        </el-descriptions-item>
      </el-descriptions>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import type { AnyColumns } from "element-plus/es/components/table-v2/src/types.mjs";
import { reactive, ref } from "vue";

type LogType = "create" | "update" | "delete" | "login";

interface OperationLog {
  id: number;
  username: string;
  type: LogType;
  module: string;
  description: string;
  ip: string;
  result: "success" | "error";
  createdAt: string;
}

const queryForm = reactive<{
  username: string;
  type: string;
  dateRange: [Date, Date] | null;
}>({
  username: "",
  type: "",
  dateRange: null,
});

const tableData = ref<OperationLog[]>([
  {
    id: 1,
    username: "admin",
    type: "login",
    module: "权限控制中心",
    description: "用户登录系统",
    ip: "192.168.1.101",
    result: "success",
    createdAt: "2026-08-18 21:05:32",
  },
  {
    id: 2,
    username: "admin",
    type: "create",
    module: "用户管理",
    description: "新增用户 zhangsan",
    ip: "192.168.1.101",
    result: "success",
    createdAt: "2026-08-18 20:48:16",
  },
  {
    id: 3,
    username: "zhangsan",
    type: "update",
    module: "组织机构",
    description: "修改技术部负责人信息",
    ip: "192.168.1.102",
    result: "success",
    createdAt: "2026-08-18 19:32:08",
  },
  {
    id: 4,
    username: "lisi",
    type: "delete",
    module: "岗位管理",
    description: "删除岗位：测试工程师",
    ip: "192.168.1.103",
    result: "error",
    createdAt: "2026-08-18 18:21:44",
  },
]);

const pagination = reactive({
  page: 1,
  pageSize: 10,
  total: tableData.value.length,
});

const drawerVisible = ref(false);
const currentLog = ref<OperationLog | null>(null);

function handleSearch() {
  console.log("查询日志", queryForm);
}

function handleReset() {
  queryForm.username = "";
  queryForm.type = "";
  queryForm.dateRange = null;
}

function handleDetail(row: OperationLog) {
  currentLog.value = row;
  drawerVisible.value = true;
}

function getTypeName(type: LogType) {
  const map: Record<LogType, string> = {
    create: "新增",
    update: "修改",
    delete: "删除",
    login: "登录",
  };

  return map[type];
}

function getTypeTag(type: LogType) {
  const map: Record<LogType, "success" | "warning" | "danger" | "info"> = {
    create: "success",
    update: "warning",
    delete: "danger",
    login: "info",
  };

  return map[type];
}
</script>

<style scoped lang="less">
.page-container {
  padding: 20px;
}

.pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}
</style>
