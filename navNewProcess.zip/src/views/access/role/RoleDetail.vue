<template>
  <div class="page-container">
    <el-card shadow="never">
      <template #header>
        <div class="page-header">
          <div>
            <div class="page-title">角色详情</div>

            <div class="page-subtitle">当前角色 ID：{{ route.params.id }}</div>
          </div>

          <el-tag type="info"> ID {{ route.params.id }} </el-tag>
        </div>
      </template>

      <!-- =====================================================
       * 基础信息
       * ===================================================== -->

      <el-form :model="form" label-width="120px">
        <el-divider content-position="left"> 基础信息 </el-divider>

        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="角色名称">
              <el-input v-model="form.name" placeholder="请输入角色名称" />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="角色编码">
              <el-input v-model="form.code" placeholder="请输入角色编码" />
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item label="角色描述">
          <el-input
            v-model="form.description"
            type="textarea"
            :rows="4"
            placeholder="请输入角色描述"
          />
        </el-form-item>

        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="状态">
              <el-switch v-model="form.enabled" active-text="启用" inactive-text="禁用" />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="角色类型">
              <el-select v-model="form.type" style="width: 100%">
                <el-option label="系统角色" value="system" />

                <el-option label="业务角色" value="business" />

                <el-option label="临时角色" value="temporary" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <!-- ===================================================
         * 权限
         * =================================================== -->

        <el-divider content-position="left"> 权限配置 </el-divider>

        <el-form-item label="数据范围">
          <el-radio-group v-model="form.dataScope">
            <el-radio value="all"> 全部数据 </el-radio>

            <el-radio value="department"> 本部门 </el-radio>

            <el-radio value="self"> 仅本人 </el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="权限">
          <el-checkbox-group v-model="form.permissions">
            <el-checkbox value="user:view"> 用户查看 </el-checkbox>

            <el-checkbox value="user:edit"> 用户编辑 </el-checkbox>

            <el-checkbox value="role:view"> 角色查看 </el-checkbox>

            <el-checkbox value="role:edit"> 角色编辑 </el-checkbox>

            <el-checkbox value="permission:view"> 权限查看 </el-checkbox>

            <el-checkbox value="permission:edit"> 权限编辑 </el-checkbox>
          </el-checkbox-group>
        </el-form-item>

        <!-- ===================================================
         * 其他信息
         * =================================================== -->

        <el-divider content-position="left"> 其他配置 </el-divider>

        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="有效期">
              <el-date-picker
                v-model="form.expireDate"
                type="date"
                placeholder="请选择日期"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="优先级">
              <el-input-number v-model="form.priority" :min="1" :max="100" style="width: 100%" />
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="5" placeholder="请输入备注" />
        </el-form-item>

        <!-- ===================================================
         * KeepAlive 测试
         * =================================================== -->

        <el-divider content-position="left"> KeepAlive 测试 </el-divider>

        <div class="test-panel">
          <p>当前详情页使用 Vue 原生 KeepAlive。</p>

          <p>
            当前详情 ID：
            <strong>{{ route.params.id }}</strong>
          </p>

          <p>
            当前组件实例：
            <strong>{{ instanceId }}</strong>
          </p>

          <p>你可以修改上面的表单，然后切换其他详情页面， 再返回观察数据是否保持。</p>

          <p>
            当前组件状态：
            <el-tag type="success"> 组件内部 reactive </el-tag>
          </p>
        </div>
      </el-form>

      <!-- =====================================================
       * Footer
       * ===================================================== -->

      <div class="footer">
        <el-button> 取消 </el-button>

        <el-button type="primary" @click="handleSave"> 保存 </el-button>

        <el-button type="danger" plain @click="handleReset"> 重置表单 </el-button>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { onActivated, onDeactivated, onMounted, onUnmounted, reactive } from "vue";

import { useRoute } from "vue-router";

/* =========================================================
 * Router
 * ========================================================= */

const route = useRoute();

/* =========================================================
 * Component Instance
 *
 * ★ 纯粹为了测试
 *
 * 每创建一个 RoleDetail 组件实例，
 * 都应该拥有一个不同的 instanceId。
 * ========================================================= */

const instanceId = Math.random().toString(36).slice(2, 8);

/* =========================================================
 * Form
 *
 * ★★★ 核心 ★★★
 *
 * 不使用：
 *
 * - useKeepAlive
 * - Pinia
 * - sessionStorage
 * - localStorage
 * - IndexedDB
 * - 任何外部缓存
 *
 * 这个 form 只属于当前 RoleDetail 组件实例。
 * ========================================================= */

const form = reactive({
  name: "",
  code: "",
  description: "",

  enabled: true,

  type: "business",

  dataScope: "department",

  permissions: [] as string[],

  expireDate: null as Date | null,

  priority: 50,

  remark: "",
});

/* =========================================================
 * 初始化测试数据
 *
 * 每一个组件实例创建时，
 * 根据自己的 route.params.id 初始化。
 * ========================================================= */

function initializeForm() {
  const id = String(route.params.id ?? "");

  if (!id) {
    return;
  }

  Object.assign(form, {
    name: `测试角色 ${id}`,

    code: `ROLE_${id}`,

    description: "这是一个用于测试 Tag + KeepAlive 的角色详情页面。",

    enabled: true,

    type: "business",

    dataScope: "department",

    permissions: ["user:view", "role:view"],

    expireDate: null,

    priority: 50,

    remark: "可以随意修改这里的内容，然后切换其他页面测试状态是否保留。",
  });
}

/* =========================================================
 * Lifecycle
 *
 * ★★★ 调试 KeepAlive 的核心 ★★★
 * ========================================================= */

onMounted(() => {
  console.log("🟢 RoleDetail mounted:", {
    id: route.params.id,
    instanceId,
  });

  initializeForm();
});

onActivated(() => {
  console.log("🔵 RoleDetail activated:", {
    id: route.params.id,
    instanceId,
  });
});

onDeactivated(() => {
  console.log("🟡 RoleDetail deactivated:", {
    id: route.params.id,
    instanceId,
  });
});

onUnmounted(() => {
  console.log("🔴 RoleDetail UNMOUNTED:", {
    id: route.params.id,
    instanceId,
  });
});

/* =========================================================
 * Save
 * ========================================================= */

function handleSave() {
  console.log("保存角色：", {
    id: route.params.id,
    instanceId,
    form: { ...form },
  });
}

/* =========================================================
 * Reset
 *
 * 只重置当前组件实例。
 * ========================================================= */

function handleReset() {
  initializeForm();
}
</script>

<style scoped lang="less">
.page-container {
  min-height: 100%;

  padding: 20px;

  box-sizing: border-box;
}

.page-header {
  display: flex;

  align-items: center;

  justify-content: space-between;
}

.page-title {
  color: #303133;

  font-size: 18px;

  font-weight: 600;
}

.page-subtitle {
  margin-top: 6px;

  color: #909399;

  font-size: 13px;
}

.test-panel {
  padding: 18px;

  color: #606266;

  line-height: 1.8;

  background: #f7f8fa;

  border-radius: 6px;

  strong {
    color: #303133;
  }

  code {
    display: inline-block;

    padding: 4px 8px;

    color: #409eff;

    background: #ecf5ff;

    border-radius: 4px;
  }
}

.footer {
  display: flex;

  justify-content: flex-end;

  margin-top: 30px;

  padding-top: 20px;

  border-top: 1px solid #ebeef5;
}
</style>
