<template>
  <div class="page-container">
    <el-card shadow="never">
      <!-- =====================================================
       * 查询
       * ===================================================== -->
      <el-form :model="queryForm" inline>
        <el-form-item label="角色名称">
          <el-input v-model="queryForm.name" placeholder="请输入角色名称" clearable />
        </el-form-item>

        <el-form-item label="状态">
          <el-select
            v-model="queryForm.status"
            placeholder="请选择状态"
            clearable
            style="width: 140px"
          >
            <el-option label="启用" value="enabled" />
            <el-option label="禁用" value="disabled" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary"> 查询 </el-button>

          <el-button @click="handleReset"> 重置 </el-button>
        </el-form-item>
      </el-form>

      <el-divider />

      <!-- =====================================================
       * Toolbar
       * ===================================================== -->
      <div class="toolbar">
        <el-button type="primary" @click="handleAdd"> 新增角色 </el-button>
      </div>

      <!-- =====================================================
       * Table
       * ===================================================== -->
      <el-table :data="tableData" border stripe>
        <el-table-column prop="id" label="ID" width="100" />

        <el-table-column prop="name" label="角色名称" min-width="160" />

        <el-table-column prop="code" label="角色编码" min-width="160" />

        <el-table-column prop="description" label="描述" min-width="240" />

        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 'enabled' ? 'success' : 'info'">
              {{ row.status === "enabled" ? "启用" : "禁用" }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="createdAt" label="创建时间" width="180" />

        <!-- ===================================================
         * 操作
         * =================================================== -->
        <el-table-column label="操作" width="260" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleView(row as any)"> 查看 </el-button>

            <el-button link type="primary" @click="handleEdit(row as any)"> 编辑 </el-button>

            <el-button link type="warning"> 分配权限 </el-button>

            <el-button link type="danger"> 删除 </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- =======================================================
     * 编辑 Dialog
     * ======================================================= -->
    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="角色名称">
          <el-input v-model="form.name" />
        </el-form-item>

        <el-form-item label="角色编码">
          <el-input v-model="form.code" />
        </el-form-item>

        <el-form-item label="角色描述">
          <el-input v-model="form.description" type="textarea" :rows="3" />
        </el-form-item>

        <el-form-item label="状态">
          <el-switch v-model="form.enabled" active-text="启用" inactive-text="禁用" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="dialogVisible = false"> 取消 </el-button>

        <el-button type="primary" @click="handleSave"> 保存 </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from "vue";

import { useRouter } from "vue-router";

/* =========================================================
 * Router
 * ========================================================= */

const router = useRouter();

/* =========================================================
 * Role
 * ========================================================= */

interface Role {
  id: number;

  name: string;

  code: string;

  description: string;

  status: "enabled" | "disabled";

  createdAt: string;
}

/* =========================================================
 * Query
 * ========================================================= */

const queryForm = reactive({
  name: "",

  status: "",
});

/* =========================================================
 * Table
 * ========================================================= */

const tableData = ref<Role[]>([
  {
    id: 1001,

    name: "系统管理员",

    code: "ADMIN",

    description: "拥有系统全部管理权限",

    status: "enabled",

    createdAt: "2026-08-18 09:00",
  },

  {
    id: 1002,

    name: "普通用户",

    code: "USER",

    description: "系统基础业务操作权限",

    status: "enabled",

    createdAt: "2026-08-17 15:30",
  },

  {
    id: 1003,

    name: "审计人员",

    code: "AUDITOR",

    description: "负责系统审计及日志查看",

    status: "enabled",

    createdAt: "2026-08-16 11:20",
  },
]);

/* =========================================================
 * Dialog
 * ========================================================= */

const dialogVisible = ref(false);

const dialogTitle = ref("新增角色");

/* =========================================================
 * Form
 * ========================================================= */

const form = reactive({
  name: "",

  code: "",

  description: "",

  enabled: true,
});

/* =========================================================
 * Reset
 * ========================================================= */

function handleReset() {
  queryForm.name = "";

  queryForm.status = "";
}

/* =========================================================
 * Add
 * ========================================================= */

function handleAdd() {
  dialogTitle.value = "新增角色";

  Object.assign(form, {
    name: "",
    code: "",
    description: "",
    enabled: true,
  });

  dialogVisible.value = true;
}

/* =========================================================
 * View
 *
 * ★ 打开详情
 * ========================================================= */

async function handleView(row: Role) {
  await router.push({
    name: "RoleDetail",

    params: {
      id: row.id,
    },
  });
}

/* =========================================================
 * Edit
 * ========================================================= */

function handleEdit(row: Role) {
  dialogTitle.value = "编辑角色";

  Object.assign(form, {
    name: row.name,

    code: row.code,

    description: row.description,

    enabled: row.status === "enabled",
  });

  dialogVisible.value = true;
}

/* =========================================================
 * Save
 * ========================================================= */

function handleSave() {
  dialogVisible.value = false;
}
</script>

<style scoped lang="less">
.page-container {
  padding: 20px;
}

.toolbar {
  margin-bottom: 16px;
}
</style>
