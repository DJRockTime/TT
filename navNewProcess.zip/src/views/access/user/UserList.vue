<template>
  <div class="page-container">
    <el-card shadow="never">
      <!-- 查询区域 -->
      <el-form :model="queryForm" inline>
        <el-form-item label="用户名">
          <el-input v-model="queryForm.username" placeholder="请输入用户名" clearable />
        </el-form-item>

        <el-form-item label="状态">
          <el-select
            v-model="queryForm.status"
            placeholder="请选择状态"
            clearable
            style="width: 140px"
          >
            <el-option label="启用" value="enabled" />
            <el-option label="禁用" value="disabled" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleSearch"> 查询 </el-button>
          <el-button @click="handleReset"> 重置 </el-button>
        </el-form-item>
      </el-form>

      <el-divider />

      <!-- 工具栏 -->
      <div class="toolbar">
        <el-button type="primary" @click="handleAdd"> 新增用户 </el-button>

        <el-button type="danger" plain :disabled="selectedRows.length === 0"> 批量删除 </el-button>
      </div>

      <!-- 表格 -->
      <el-table :data="tableData" border stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="50" />

        <el-table-column prop="username" label="用户名" min-width="140" />

        <el-table-column prop="realName" label="姓名" min-width="120" />

        <el-table-column prop="department" label="所属部门" min-width="160" />

        <el-table-column prop="role" label="角色" min-width="120" />

        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 'enabled' ? 'success' : 'info'">
              {{ row.status === "enabled" ? "启用" : "禁用" }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="createdAt" label="创建时间" width="180" />

        <el-table-column label="操作" fixed="right" width="180">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleEdit(row)"> 编辑 </el-button>

            <el-button link type="danger"> 删除 </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="pagination.total"
          background
          layout="total, sizes, prev, pager, next"
        />
      </div>
    </el-card>

    <!-- 新增 / 编辑 -->
    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form ref="formRef" :model="form" label-width="90px">
        <el-form-item label="用户名">
          <el-input v-model="form.username" />
        </el-form-item>

        <el-form-item label="姓名">
          <el-input v-model="form.realName" />
        </el-form-item>

        <el-form-item label="部门">
          <el-select v-model="form.department" placeholder="请选择部门" style="width: 100%">
            <el-option label="技术部" value="技术部" />
            <el-option label="产品部" value="产品部" />
            <el-option label="运营部" value="运营部" />
          </el-select>
        </el-form-item>

        <el-form-item label="角色">
          <el-select v-model="form.role" placeholder="请选择角色" style="width: 100%">
            <el-option label="管理员" value="管理员" />
            <el-option label="普通用户" value="普通用户" />
          </el-select>
        </el-form-item>

        <el-form-item label="状态">
          <el-switch v-model="form.enabled" active-text="启用" inactive-text="禁用" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="dialogVisible = false"> 取消 </el-button>
        <el-button type="primary" @click="handleSave"> 保存 </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from "vue";
import type { FormInstance } from "element-plus";

interface User {
  username: string;
  realName: string;
  department: string;
  role: string;
  status: "enabled" | "disabled";
  createdAt: string;
}

const formRef = ref<FormInstance>();

const queryForm = reactive({
  username: "",
  status: "",
});

const tableData = ref<User[]>([
  {
    username: "admin",
    realName: "系统管理员",
    department: "技术部",
    role: "管理员",
    status: "enabled",
    createdAt: "2026-08-18 09:30",
  },
  {
    username: "zhangsan",
    realName: "张三",
    department: "产品部",
    role: "普通用户",
    status: "enabled",
    createdAt: "2026-08-17 14:20",
  },
  {
    username: "lisi",
    realName: "李四",
    department: "运营部",
    role: "普通用户",
    status: "disabled",
    createdAt: "2026-08-16 10:15",
  },
]);

const selectedRows = ref<User[]>([]);

const pagination = reactive({
  page: 1,
  pageSize: 10,
  total: tableData.value.length,
});

const dialogVisible = ref(false);
const dialogTitle = ref("新增用户");

const form = reactive({
  username: "",
  realName: "",
  department: "",
  role: "",
  enabled: true,
});

function handleSearch() {
  console.log("查询", queryForm);
}

function handleReset() {
  queryForm.username = "";
  queryForm.status = "";
}

function handleSelectionChange(rows: User[]) {
  selectedRows.value = rows;
}

function handleAdd() {
  dialogTitle.value = "新增用户";

  Object.assign(form, {
    username: "",
    realName: "",
    department: "",
    role: "",
    enabled: true,
  });

  dialogVisible.value = true;
}

function handleEdit(row: User) {
  dialogTitle.value = "编辑用户";

  Object.assign(form, {
    username: row.username,
    realName: row.realName,
    department: row.department,
    role: row.role,
    enabled: row.status === "enabled",
  });

  dialogVisible.value = true;
}

function handleSave() {
  dialogVisible.value = false;
}
</script>

<style scoped lang="less">
.page-container {
  padding: 20px;
}

.toolbar {
  display: flex;
  gap: 10px;
  margin-bottom: 16px;
}

.pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}
</style>
