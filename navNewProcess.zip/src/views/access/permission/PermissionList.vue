<template>
  <div class="page-container">
    <el-card shadow="never">
      <template #header>
        <div class="header">
          <span>权限资源</span>

          <el-tag> 普通子页面 </el-tag>
        </div>
      </template>

      <el-form :model="state" label-width="100px">
        <el-form-item label="权限名称">
          <el-input v-model="state.name" placeholder="输入权限名称" />
        </el-form-item>

        <el-form-item label="权限编码">
          <el-input v-model="state.code" placeholder="输入权限编码" />
        </el-form-item>

        <el-form-item label="权限类型">
          <el-select v-model="state.type" style="width: 200px">
            <el-option label="菜单" value="menu" />

            <el-option label="按钮" value="button" />

            <el-option label="接口" value="api" />
          </el-select>
        </el-form-item>

        <el-form-item label="备注">
          <el-input v-model="state.remark" type="textarea" :rows="5" />
        </el-form-item>
      </el-form>

      <el-divider />

      <div class="cache-info">
        当前页面状态：

        <el-tag :type="hasState ? 'success' : 'info'">
          {{ hasState ? "已缓存" : "未缓存" }}
        </el-tag>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { useKeepAlive } from "@/composables/useKeepAlive";

const { state, hasState } = useKeepAlive("/access-control/permission", {
  name: "",

  code: "",

  type: "menu",

  remark: "",
});
</script>

<style scoped lang="less">
.page-container {
  min-height: 100%;

  padding: 20px;

  box-sizing: border-box;
}

.header {
  display: flex;

  align-items: center;

  justify-content: space-between;
}

.cache-info {
  color: #606266;

  font-size: 14px;
}
</style>
