<template>
  <div class="not-found">
    <div class="background-number">404</div>

    <div class="content">
      <div class="code">404</div>

      <div class="divider"></div>

      <h1>页面暂时走丢了</h1>

      <p>抱歉，你访问的页面不存在，或者已经被移动。</p>

      <el-button type="primary" size="large" @click="goHome"> 返回首页 </el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from "vue-router";

const router = useRouter();

function goHome() {
  router.push("/");
}
</script>

<style scoped lang="less">
.not-found {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  overflow: hidden;
  background: radial-gradient(circle at 50% 45%, #faf8f3 0%, #f5f3ee 45%, #eeece6 100%);
}

.background-number {
  position: absolute;
  top: 50%;
  left: 50%;
  color: rgba(30, 30, 30, 0.035);
  font-family: Georgia, "Times New Roman", serif;
  font-size: min(42vw, 620px);
  font-weight: 700;
  line-height: 1;
  letter-spacing: -30px;
  transform: translate(-50%, -55%);
  user-select: none;
}

.content {
  position: relative;
  z-index: 1;
  text-align: center;
}

.code {
  color: #2c2c2c;
  font-family: Georgia, "Times New Roman", serif;
  font-size: 108px;
  font-weight: 600;
  line-height: 1;
  letter-spacing: 8px;
}

.divider {
  width: 48px;
  height: 2px;
  margin: 28px auto;
  background: #b59a68;
}

h1 {
  margin: 0;
  color: #2c2c2c;
  font-size: 24px;
  font-weight: 500;
  letter-spacing: 2px;
}

p {
  margin: 16px 0 30px;
  color: #88837a;
  font-size: 14px;
  letter-spacing: 1px;
}

:deep(.el-button--primary) {
  padding: 0 28px;
  border: none;
  border-radius: 4px;
  background: #2c2c2c;
  letter-spacing: 1px;
}

:deep(.el-button--primary:hover) {
  background: #444;
}
</style>
