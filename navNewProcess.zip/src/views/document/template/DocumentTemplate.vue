<template>
  <div class="page-container">
    <el-card shadow="never">
      <!-- 查询 -->
      <el-form :model="queryForm" inline>
        <el-form-item label="模板名称">
          <el-input v-model="queryForm.name" placeholder="请输入模板名称" clearable />
        </el-form-item>

        <el-form-item label="模板类型">
          <el-select
            v-model="queryForm.type"
            placeholder="请选择类型"
            clearable
            style="width: 150px"
          >
            <el-option label="通知公告" value="notice" />
            <el-option label="合同协议" value="contract" />
            <el-option label="报告" value="report" />
          </el-select>
        </el-form-item>

        <el-form-item label="状态">
          <el-select
            v-model="queryForm.status"
            placeholder="请选择状态"
            clearable
            style="width: 130px"
          >
            <el-option label="启用" value="enabled" />
            <el-option label="停用" value="disabled" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleSearch"> 查询 </el-button>

          <el-button @click="handleReset"> 重置 </el-button>
        </el-form-item>
      </el-form>

      <el-divider />

      <!-- 工具栏 -->
      <div class="toolbar">
        <el-button type="primary" @click="handleAdd"> 新增模板 </el-button>

        <el-button> 导入模板 </el-button>

        <el-button> 导出 </el-button>
      </div>

      <!-- 表格 -->
      <el-table :data="tableData" border stripe>
        <el-table-column prop="name" label="模板名称" min-width="180" />

        <el-table-column prop="code" label="模板编码" width="150" />

        <el-table-column prop="type" label="模板类型" width="130">
          <template #default="{ row }">
            {{ getTypeName(row.type) }}
          </template>
        </el-table-column>

        <el-table-column prop="category" label="所属分类" width="150" />

        <el-table-column prop="version" label="版本" width="100" />

        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 'enabled' ? 'success' : 'info'">
              {{ row.status === "enabled" ? "启用" : "停用" }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="updatedBy" label="最后修改人" width="120" />

        <el-table-column prop="updatedAt" label="更新时间" width="180" />

        <el-table-column label="操作" fixed="right" width="220">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleDetail(row as any)"> 查看 </el-button>

            <el-button link type="primary" @click="handleEdit(row as any)"> 编辑 </el-button>

            <el-button link type="warning"> 复制 </el-button>

            <el-button link type="danger"> 删除 </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="pagination.total"
          background
          layout="total, sizes, prev, pager, next"
        />
      </div>
    </el-card>

    <!-- 新增 / 编辑 -->
    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="520px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="模板名称">
          <el-input v-model="form.name" placeholder="请输入模板名称" />
        </el-form-item>

        <el-form-item label="模板编码">
          <el-input v-model="form.code" placeholder="请输入模板编码" />
        </el-form-item>

        <el-form-item label="模板类型">
          <el-select v-model="form.type" style="width: 100%">
            <el-option label="通知公告" value="notice" />
            <el-option label="合同协议" value="contract" />
            <el-option label="报告" value="report" />
          </el-select>
        </el-form-item>

        <el-form-item label="所属分类">
          <el-select v-model="form.category" style="width: 100%">
            <el-option label="规章制度" value="规章制度" />
            <el-option label="行政文件" value="行政文件" />
            <el-option label="开发规范" value="开发规范" />
          </el-select>
        </el-form-item>

        <el-form-item label="模板说明">
          <el-input
            v-model="form.description"
            type="textarea"
            :rows="4"
            placeholder="请输入模板说明"
          />
        </el-form-item>

        <el-form-item label="状态">
          <el-switch v-model="form.enabled" active-text="启用" inactive-text="停用" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="dialogVisible = false"> 取消 </el-button>

        <el-button type="primary" @click="handleSave"> 保存 </el-button>
      </template>
    </el-dialog>

    <!-- 查看详情 -->
    <el-drawer v-model="drawerVisible" title="模板详情" size="500px">
      <template v-if="currentTemplate">
        <el-descriptions :column="1" border>
          <el-descriptions-item label="模板名称">
            {{ currentTemplate.name }}
          </el-descriptions-item>

          <el-descriptions-item label="模板编码">
            {{ currentTemplate.code }}
          </el-descriptions-item>

          <el-descriptions-item label="模板类型">
            {{ getTypeName(currentTemplate.type) }}
          </el-descriptions-item>

          <el-descriptions-item label="所属分类">
            {{ currentTemplate.category }}
          </el-descriptions-item>

          <el-descriptions-item label="版本">
            {{ currentTemplate.version }}
          </el-descriptions-item>

          <el-descriptions-item label="最后修改人">
            {{ currentTemplate.updatedBy }}
          </el-descriptions-item>

          <el-descriptions-item label="更新时间">
            {{ currentTemplate.updatedAt }}
          </el-descriptions-item>

          <el-descriptions-item label="模板说明">
            {{ currentTemplate.description }}
          </el-descriptions-item>
        </el-descriptions>

        <div class="preview-box">
          <div class="preview-title">模板预览</div>

          <div class="preview-content">这里暂时作为模板内容预览区域。</div>
        </div>
      </template>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from "vue";

type TemplateType = "notice" | "contract" | "report";

interface DocumentTemplate {
  id: number;
  name: string;
  code: string;
  type: TemplateType;
  category: string;
  version: string;
  status: "enabled" | "disabled";
  updatedBy: string;
  updatedAt: string;
  description: string;
}

const queryForm = reactive({
  name: "",
  type: "",
  status: "",
});

const tableData = ref<DocumentTemplate[]>([
  {
    id: 1,
    name: "企业通知模板",
    code: "NOTICE_DEFAULT",
    type: "notice",
    category: "行政文件",
    version: "V1.2",
    status: "enabled",
    updatedBy: "admin",
    updatedAt: "2026-08-18 10:20",
    description: "企业内部通知公告标准模板",
  },
  {
    id: 2,
    name: "标准合同模板",
    code: "CONTRACT_DEFAULT",
    type: "contract",
    category: "规章制度",
    version: "V2.0",
    status: "enabled",
    updatedBy: "zhangsan",
    updatedAt: "2026-08-17 16:30",
    description: "企业标准合同文档模板",
  },
  {
    id: 3,
    name: "项目总结报告",
    code: "REPORT_PROJECT",
    type: "report",
    category: "开发规范",
    version: "V1.0",
    status: "disabled",
    updatedBy: "lisi",
    updatedAt: "2026-08-16 14:10",
    description: "项目阶段总结报告模板",
  },
]);

const pagination = reactive({
  page: 1,
  pageSize: 10,
  total: tableData.value.length,
});

const dialogVisible = ref(false);
const dialogTitle = ref("新增模板");

const drawerVisible = ref(false);
const currentTemplate = ref<DocumentTemplate | null>(null);

const form = reactive({
  name: "",
  code: "",
  type: "notice" as TemplateType,
  category: "",
  description: "",
  enabled: true,
});

function handleSearch() {
  console.log("查询模板", queryForm);
}

function handleReset() {
  queryForm.name = "";
  queryForm.type = "";
  queryForm.status = "";
}

function handleAdd() {
  dialogTitle.value = "新增模板";

  Object.assign(form, {
    name: "",
    code: "",
    type: "notice",
    category: "",
    description: "",
    enabled: true,
  });

  dialogVisible.value = true;
}

function handleEdit(row: DocumentTemplate) {
  dialogTitle.value = "编辑模板";

  Object.assign(form, {
    name: row.name,
    code: row.code,
    type: row.type,
    category: row.category,
    description: row.description,
    enabled: row.status === "enabled",
  });

  dialogVisible.value = true;
}

function handleDetail(row: DocumentTemplate) {
  currentTemplate.value = row;
  drawerVisible.value = true;
}

function handleSave() {
  dialogVisible.value = false;
}

function getTypeName(type: TemplateType) {
  const map: Record<TemplateType, string> = {
    notice: "通知公告",
    contract: "合同协议",
    report: "报告",
  };

  return map[type];
}
</script>

<style scoped lang="less">
.page-container {
  padding: 20px;
}

.toolbar {
  display: flex;
  gap: 10px;
  margin-bottom: 16px;
}

.pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

.preview-box {
  margin-top: 24px;
  padding: 16px;
  border: 1px solid var(--el-border-color);
  border-radius: 6px;
}

.preview-title {
  margin-bottom: 12px;
  font-weight: 600;
}

.preview-content {
  min-height: 180px;
  padding: 20px;
  color: var(--el-text-color-secondary);
  background: var(--el-fill-color-light);
  border-radius: 4px;
}
</style>
