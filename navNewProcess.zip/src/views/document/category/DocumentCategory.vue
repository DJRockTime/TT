<template>
  <div class="page-container">
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>文档分类</span>

          <el-button type="primary" @click="handleAdd()"> 新增分类 </el-button>
        </div>
      </template>

      <el-row :gutter="20">
        <!-- 左侧分类树 -->
        <el-col :span="8">
          <div class="tree-panel">
            <div class="panel-title">分类目录</div>

            <el-input v-model="filterText" placeholder="搜索分类" clearable class="tree-search" />

            <el-tree
              ref="treeRef"
              :data="treeData"
              node-key="id"
              default-expand-all
              :filter-node-method="filterNode"
              highlight-current
              @node-click="handleNodeClick"
            >
              <template #default="{ data }">
                <div class="tree-node">
                  <span>{{ data.name }}</span>

                  <el-button link type="primary" size="small" @click.stop="handleAdd(data)">
                    添加
                  </el-button>
                </div>
              </template>
            </el-tree>
          </div>
        </el-col>

        <!-- 右侧详情 -->
        <el-col :span="16">
          <div class="detail-panel">
            <template v-if="currentCategory">
              <div class="panel-title">分类信息</div>

              <el-descriptions :column="2" border>
                <el-descriptions-item label="分类名称">
                  {{ currentCategory.name }}
                </el-descriptions-item>

                <el-descriptions-item label="分类编码">
                  {{ currentCategory.code }}
                </el-descriptions-item>

                <el-descriptions-item label="排序">
                  {{ currentCategory.sort }}
                </el-descriptions-item>

                <el-descriptions-item label="状态">
                  <el-tag :type="currentCategory.enabled ? 'success' : 'info'">
                    {{ currentCategory.enabled ? "启用" : "停用" }}
                  </el-tag>
                </el-descriptions-item>

                <el-descriptions-item label="创建时间" :span="2">
                  {{ currentCategory.createdAt }}
                </el-descriptions-item>

                <el-descriptions-item label="描述" :span="2">
                  {{ currentCategory.description || "暂无描述" }}
                </el-descriptions-item>
              </el-descriptions>

              <div class="detail-actions">
                <el-button type="primary" @click="handleEdit(currentCategory)"> 编辑 </el-button>

                <el-button type="danger" plain> 删除 </el-button>
              </div>
            </template>

            <el-empty v-else description="请选择一个分类" />
          </div>
        </el-col>
      </el-row>
    </el-card>

    <!-- 新增 / 编辑 -->
    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="分类名称">
          <el-input v-model="form.name" placeholder="请输入分类名称" />
        </el-form-item>

        <el-form-item label="分类编码">
          <el-input v-model="form.code" placeholder="请输入分类编码" />
        </el-form-item>

        <el-form-item label="上级分类">
          <el-select
            v-model="form.parentId"
            placeholder="请选择上级分类"
            clearable
            style="width: 100%"
          >
            <el-option label="无" :value="0" />

            <el-option
              v-for="item in flatCategories"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="排序">
          <el-input-number v-model="form.sort" :min="0" :max="999" />
        </el-form-item>

        <el-form-item label="描述">
          <el-input
            v-model="form.description"
            type="textarea"
            :rows="3"
            placeholder="请输入分类描述"
          />
        </el-form-item>

        <el-form-item label="状态">
          <el-switch v-model="form.enabled" active-text="启用" inactive-text="停用" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="dialogVisible = false"> 取消 </el-button>

        <el-button type="primary" @click="handleSave"> 保存 </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, reactive, ref, watch } from "vue";
import type { ElTree, TreeInstance } from "element-plus";

interface Category {
  id: number;
  name: string;
  code: string;
  parentId: number;
  sort: number;
  enabled: boolean;
  description: string;
  createdAt: string;
  children?: Category[];
}

const treeRef = ref<TreeInstance>();

const filterText = ref("");

watch(filterText, (value) => {
  treeRef.value?.filter(value);
});

const treeData = ref<Category[]>([
  {
    id: 1,
    name: "企业文档",
    code: "COMPANY",
    parentId: 0,
    sort: 1,
    enabled: true,
    description: "企业基础文档",
    createdAt: "2026-08-18 09:00",
    children: [
      {
        id: 2,
        name: "规章制度",
        code: "RULE",
        parentId: 1,
        sort: 1,
        enabled: true,
        description: "企业规章制度",
        createdAt: "2026-08-18 09:10",
      },
      {
        id: 3,
        name: "行政文件",
        code: "ADMIN",
        parentId: 1,
        sort: 2,
        enabled: true,
        description: "行政管理相关文件",
        createdAt: "2026-08-18 09:20",
      },
    ],
  },
  {
    id: 4,
    name: "技术文档",
    code: "TECH",
    parentId: 0,
    sort: 2,
    enabled: true,
    description: "技术研发相关文档",
    createdAt: "2026-08-18 10:00",
    children: [
      {
        id: 5,
        name: "开发规范",
        code: "DEV-RULE",
        parentId: 4,
        sort: 1,
        enabled: true,
        description: "开发规范和技术标准",
        createdAt: "2026-08-18 10:20",
      },
    ],
  },
]);

const currentCategory = ref<Category | null>(null);

const dialogVisible = ref(false);
const dialogTitle = ref("新增分类");

const form = reactive({
  name: "",
  code: "",
  parentId: 0,
  sort: 1,
  description: "",
  enabled: true,
});

const flatCategories = computed(() => {
  const result: Category[] = [];

  const walk = (list: Category[]) => {
    list.forEach((item) => {
      result.push(item);

      if (item.children) {
        walk(item.children);
      }
    });
  };

  walk(treeData.value);

  return result;
});

function filterNode(value: string, data: Category) {
  if (!value) {
    return true;
  }

  return data.name.includes(value);
}

function handleNodeClick(data: Category) {
  currentCategory.value = data;
}

function handleAdd(parent?: Category) {
  dialogTitle.value = "新增分类";

  Object.assign(form, {
    name: "",
    code: "",
    parentId: parent?.id ?? 0,
    sort: 1,
    description: "",
    enabled: true,
  });

  dialogVisible.value = true;
}

function handleEdit(row: Category) {
  dialogTitle.value = "编辑分类";

  Object.assign(form, {
    name: row.name,
    code: row.code,
    parentId: row.parentId,
    sort: row.sort,
    description: row.description,
    enabled: row.enabled,
  });

  dialogVisible.value = true;
}

function handleSave() {
  dialogVisible.value = false;
}
</script>

<style scoped lang="less">
.page-container {
  padding: 20px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.tree-panel,
.detail-panel {
  min-height: 480px;
  padding: 16px;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

.panel-title {
  margin-bottom: 16px;
  font-size: 15px;
  font-weight: 600;
}

.tree-search {
  margin-bottom: 14px;
}

.tree-node {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding-right: 8px;
}

.detail-actions {
  margin-top: 24px;
}
</style>
