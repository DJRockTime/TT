<template>
  <div style="padding: 20px; max-width: 600px">
    <el-card header="可行性验证实验">
      <!-- 表单展示 -->
      <el-form :model="store.formData" label-width="100px">
        <el-form-item label="单价">
          <el-input v-model="store.formData.price" placeholder="请输入数字" />
        </el-form-item>

        <el-form-item label="数量">
          <el-input v-model="store.formData.quantity" placeholder="请输入整数" />
        </el-form-item>

        <el-form-item label="计算总价">
          <el-button type="primary" @click="calculate">使用 Big.js 计算</el-button>
          <span style="margin-left: 20px; font-weight: bold">
            结果: {{ store.formData.result }}
          </span>
        </el-form-item>
      </el-form>

      <el-divider />

      <!-- VueUse 复制功能测试 -->
      <div>
        <p>快捷复制实验：</p>
        <el-input v-model="textToCopy" style="margin-bottom: 10px">
          <template #append>
            <el-button @click="copy(textToCopy)">
              {{ copied ? "已复制！" : "复制" }}
            </el-button>
          </template>
        </el-input>
        <el-alert
          v-if="isSupported"
          title="您的浏览器支持剪贴板 API"
          type="success"
          :closable="false"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, computed } from "vue";
import { useFormStore } from "@/store/index.ts";
import { useClipboard } from "@vueuse/core";
import Big from "big.js";

const store = useFormStore();

// Big.js 高精度计算逻辑
const calculate = () => {
  try {
    const p = new Big(store.formData.price || 0);
    const q = new Big(store.formData.quantity || 0);
    store.formData.result = p.times(q).toString();
  } catch (error) {
    store.formData.result = "输入计算格式错误";
  }
};

// VueUse 复制逻辑
const textToCopy = computed(() => `当前计算总价是: ${store.formData.result}`);
const { copy, copied, isSupported } = useClipboard();
</script>
