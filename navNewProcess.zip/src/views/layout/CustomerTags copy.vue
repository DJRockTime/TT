<template>
  <div class="customer-tags">
    <!-- =====================================================
         Tags
         ===================================================== -->
    <div
      v-for="tag in tags"
      :key="tag.key"
      class="customer-tag"
      :class="{
        'is-active': tag.key === activeTagKey,

        'is-detail': tag.type === 'detail',
      }"
      @click="handleTagClick(tag)"
    >
      <!-- =================================================
           Title
           ================================================= -->
      <span class="customer-tag__title">
        {{ tag.title }}
      </span>

      <!-- =================================================
           Close
           ================================================= -->
      <button
        v-if="tags.length > 1"
        class="customer-tag__close"
        type="button"
        aria-label="关闭标签"
        @click.stop="handleClose(tag)"
      >
        ×
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref, watch } from "vue";

import { useRoute, useRouter } from "vue-router";

import { useLayoutStore } from "@/store/layout.ts";

/* =========================================================
 * Tag 类型
 * ========================================================= */

interface CustomerTag {
  key: string;

  title: string;

  path: string;

  type: "module" | "detail";
}

/* =========================================================
 * Router
 * ========================================================= */

const router = useRouter();

const route = useRoute();

/* =========================================================
 * Layout Store
 *
 * 和 AsideMenuBar 使用同一个 Store。
 * ========================================================= */

const layoutStore = useLayoutStore();

/* =========================================================
 * 四个模块
 * ========================================================= */

const moduleMap: Record<
  string,
  {
    title: string;
    path: string;
  }
> = {
  "access-control": {
    title: "权限控制中心",
    path: "/access-control/user",
  },

  organization: {
    title: "组织架构管理",
    path: "/organization/department",
  },

  ops: {
    title: "系统运维监控",
    path: "/ops/monitor",
  },

  document: {
    title: "文档基础配置",
    path: "/document/category",
  },
};

/* =========================================================
 * 初始 Tag
 * ========================================================= */

const tags = ref<CustomerTag[]>([
  {
    key: "access-control",

    title: "权限控制中心",

    path: "/access-control/user",

    type: "module",
  },
]);

/* =========================================================
 * 判断是否为详情路由
 *
 * 例如：
 *
 * /access-control/user
 * false
 *
 * /access-control/user/1001
 * true
 * ========================================================= */

function isDetailRoute(currentRoute = route): boolean {
  return Object.keys(currentRoute.params).length > 0;
}

/* =========================================================
 * 获取当前模块
 * ========================================================= */

function getCurrentModule(currentRoute = route): string | undefined {
  return currentRoute.meta.module as string | undefined;
}

/* =========================================================
 * ★ 核心修复
 *
 * Router → Pinia
 *
 * 无论路由是通过：
 *
 * 1. AsideMenuBar
 * 2. CustomerTags
 * 3. 浏览器前进后退
 * 4. router.push
 * 5. 地址栏直接访问
 *
 * 最终都统一同步 currentModule。
 *
 * ========================================================= */

function syncCurrentModule() {
  const module = getCurrentModule(route);

  /*
   * 没有模块信息
   *
   * 例如 404
   */
  if (!module || !moduleMap[module]) {
    return;
  }

  /*
   * 避免无意义重复赋值
   */
  if (layoutStore.currentModule !== module) {
    layoutStore.setCurrentModule(module);
  }
}

/* =========================================================
 * 当前 Active Tag
 *
 * 详情优先使用 fullPath。
 *
 * 模块使用 module key。
 * ========================================================= */

const activeTagKey = computed(() => {
  /*
   * 详情页面
   */
  if (isDetailRoute(route)) {
    return route.fullPath;
  }

  /*
   * 普通模块页面
   */
  const module = getCurrentModule(route);

  if (module && moduleMap[module]) {
    return module;
  }

  /*
   * 兜底
   */
  return route.fullPath;
});

/* =========================================================
 * 获取详情 ID
 * ========================================================= */

function getDetailId(currentRoute = route): string {
  const values = Object.values(currentRoute.params);

  if (!values.length) {
    return "";
  }

  const value = values[0];

  if (Array.isArray(value)) {
    return value.join("/");
  }

  return String(value);
}

/* =========================================================
 * 详情标题
 * ========================================================= */

function getDetailTitle(currentRoute = route): string {
  const id = getDetailId(currentRoute);

  return id ? `详情 ${id}` : "详情";
}

/* =========================================================
 * 更新当前 Tag
 * ========================================================= */

function updateCurrentTag() {
  /*
   * ★ 先同步模块
   *
   * 这是本次 Bug 的核心修复。
   */
  syncCurrentModule();

  const currentRoute = route;

  const detail = isDetailRoute(currentRoute);

  const module = getCurrentModule(currentRoute);

  /* =======================================================
   * 详情路由
   * ======================================================= */

  if (detail) {
    const key = currentRoute.fullPath;

    const exists = tags.value.some((tag) => tag.key === key);

    if (!exists) {
      tags.value.push({
        key,

        title: getDetailTitle(currentRoute),

        path: currentRoute.fullPath,

        type: "detail",
      });
    }

    return;
  }

  /* =======================================================
   * 普通模块路由
   * ======================================================= */

  if (module && moduleMap[module]) {
    const moduleInfo = moduleMap[module];

    const exists = tags.value.some((tag) => tag.key === module);

    if (!exists) {
      tags.value.push({
        key: module,

        title: moduleInfo.title,

        path: moduleInfo.path,

        type: "module",
      });
    }
  }
}

/* =========================================================
 * ★ Router → Tag → Pinia
 *
 * 每次 URL 变化统一处理。
 * ========================================================= */

watch(
  () => route.fullPath,

  () => {
    updateCurrentTag();
  },

  {
    immediate: true,
  },
);

/* =========================================================
 * 点击 Tag
 * ========================================================= */

async function handleTagClick(tag: CustomerTag) {
  /*
   * 如果本来就是当前路由，
   * 仍然主动同步一次模块。
   *
   * 这样即使 Store 状态因为其他原因
   * 没有同步，也可以被修正。
   */
  if (route.fullPath === tag.path) {
    syncCurrentModule();

    return;
  }

  /*
   * 正常 Router 跳转
   *
   * 路由变化后会触发 watch，
   * 然后自动：
   *
   * Router
   * ↓
   * updateCurrentTag()
   * ↓
   * syncCurrentModule()
   * ↓
   * Pinia
   */
  await router.push(tag.path);
}

/* =========================================================
 * 关闭 Tag
 * ========================================================= */

async function handleClose(tag: CustomerTag) {
  /*
   * 至少保留一个
   */
  if (tags.value.length <= 1) {
    return;
  }

  /*
   * 找到索引
   */
  const index = tags.value.findIndex((item) => item.key === tag.key);

  if (index === -1) {
    return;
  }

  /*
   * 当前 Tag？
   */
  const isCurrent = tag.key === activeTagKey.value;

  /*
   * 删除
   */
  tags.value.splice(index, 1);

  /*
   * 关闭的不是当前 Tag
   *
   * 当前页面完全不动。
   */
  if (!isCurrent) {
    return;
  }

  /*
   * 当前 Tag 被关闭：
   *
   * 优先右边
   * ↓
   * 左边
   * ↓
   * 第一个
   */
  const nextTag = tags.value[index] ?? tags.value[index - 1] ?? tags.value[0];

  if (!nextTag) {
    return;
  }

  /*
   * Router 跳转
   *
   * watch 会自动同步 Pinia。
   */
  await router.push(nextTag.path);
}
</script>

<style scoped lang="less">
/* =========================================================
 * Customer Tags
 * ========================================================= */

.customer-tags {
  display: flex;
  align-items: center;

  width: 100%;
  height: 40px;

  padding: 0 14px;

  overflow-x: auto;
  overflow-y: hidden;

  box-sizing: border-box;

  background: #ffffff;

  border-bottom: 1px solid #eeeeee;

  scrollbar-width: none;

  &::-webkit-scrollbar {
    display: none;
  }
}

/* =========================================================
 * Tag
 * ========================================================= */

.customer-tag {
  display: inline-flex;
  align-items: center;
  justify-content: center;

  flex-shrink: 0;

  height: 28px;

  margin-right: 7px;

  padding: 0 8px 0 13px;

  color: #777777;

  font-size: 13px;
  font-weight: 400;

  line-height: 1;

  cursor: pointer;

  background: #f7f8f9;

  border: 1px solid #eeeeee;

  border-radius: 4px;

  box-sizing: border-box;

  transition:
    color 0.18s ease,
    background-color 0.18s ease,
    border-color 0.18s ease,
    box-shadow 0.18s ease;

  &:hover {
    color: #3d3d3d;

    background: #f2f4f5;

    border-color: #e3e5e7;
  }

  &.is-active {
    color: #2f596d;

    background: #c5e3f2;

    border-color: #b6d8e8;

    box-shadow: 0 2px 6px rgb(76 123 148 / 10%);
  }

  &.is-active:hover {
    background: #c5e3f2;

    border-color: #b6d8e8;
  }
}

/* =========================================================
 * Title
 * ========================================================= */

.customer-tag__title {
  display: block;

  max-width: 140px;

  overflow: hidden;

  text-overflow: ellipsis;

  white-space: nowrap;
}

/* =========================================================
 * Close
 * ========================================================= */

.customer-tag__close {
  display: inline-flex;

  align-items: center;
  justify-content: center;

  width: 18px;
  height: 18px;

  margin-left: 5px;

  padding: 0;

  color: #9aa0a4;

  font-family: Arial, sans-serif;

  font-size: 15px;
  font-weight: 400;

  line-height: 18px;

  cursor: pointer;

  background: transparent;

  border: 0;

  border-radius: 50%;

  transition:
    color 0.18s ease,
    background-color 0.18s ease;

  &:hover {
    color: #ffffff;

    background: rgb(67 92 105 / 45%);
  }
}

/* =========================================================
 * Active Tag Close
 * ========================================================= */

.customer-tag.is-active {
  .customer-tag__close {
    color: #638394;

    &:hover {
      color: #ffffff;

      background: rgb(67 92 105 / 55%);
    }
  }
}
</style>
