<template>
  <div class="sub-menu-item">
    <!-- =====================================================
         当前菜单
         ===================================================== -->
    <div
      class="menu-node"
      :class="{
        'is-clickable': clickable,
        'has-children': hasChildren,
        'is-active': isActive,
        [`level-${level}`]: true,
      }"
      @click="handleClick"
    >
      <!-- 展开箭头 -->
      <button v-if="hasChildren" class="menu-node__arrow" type="button" @click.stop="handleToggle">
        <span
          :class="{
            'is-expanded': isExpanded,
          }"
        >
          ›
        </span>
      </button>

      <!-- 没有子节点时占位 -->
      <span v-else class="menu-node__arrow-placeholder" />

      <!-- 菜单标题 -->
      <span class="menu-node__title">
        {{ title }}
      </span>
    </div>

    <!-- =====================================================
         子菜单
         ===================================================== -->
    <div v-if="hasChildren && isExpanded" class="menu-node__children">
      <SubMenuItem
        v-for="child in route.children"
        :key="getRouteKey(child)"
        :route="child"
        :level="level + 1"
        :expanded-keys="expandedKeys"
        :search-keyword="searchKeyword"
        @toggle="$emit('toggle', $event)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from "vue";

import { useRoute, useRouter } from "vue-router";

import type { RouteRecordRaw } from "vue-router";

interface Props {
  route: RouteRecordRaw;
  level: number;
  expandedKeys: Set<string>;
  searchKeyword: string;
}

const props = defineProps<Props>();

const emit = defineEmits<{
  toggle: [key: string];
}>();

const router = useRouter();
const currentRoute = useRoute();

/* =========================================================
 * 标题
 * ========================================================= */

const title = computed(() => {
  return String(props.route.meta?.title ?? props.route.name ?? props.route.path);
});

/* =========================================================
 * 子路由
 * ========================================================= */

const hasChildren = computed(() => {
  return Boolean(props.route.children && props.route.children.length);
});

/* =========================================================
 * Key
 * ========================================================= */

function getRouteKey(route: RouteRecordRaw) {
  if (route.name) {
    return String(route.name);
  }

  return route.path;
}

const routeKey = computed(() => {
  return getRouteKey(props.route);
});

/* =========================================================
 * 是否展开
 * ========================================================= */

const isExpanded = computed(() => {
  return props.expandedKeys.has(routeKey.value);
});

/* =========================================================
 * 是否可点击
 *
 * 默认：
 *
 * 有 children → 不可点击
 * 没 children → 可以点击
 *
 * meta.clickable 可以覆盖。
 * ========================================================= */

const clickable = computed(() => {
  const meta = props.route.meta as Record<string, unknown> | undefined;

  if (typeof meta?.clickable === "boolean") {
    return meta.clickable;
  }

  return !hasChildren.value;
});

/* =========================================================
 * 当前路由是否 Active
 * ========================================================= */

const isActive = computed(() => {
  if (!props.route.name) {
    return false;
  }

  return currentRoute.name === props.route.name;
});

/* =========================================================
 * 展开 / 收起
 * ========================================================= */

function handleToggle() {
  emit("toggle", routeKey.value);
}

/* =========================================================
 * 点击菜单
 * ========================================================= */

function handleClick() {
  /*
   * 有 children 的一级菜单
   * 默认只是展开 / 收起
   */
  if (!clickable.value) {
    if (hasChildren.value) {
      handleToggle();
    }

    return;
  }

  /*
   * 没有 name 的路由无法进行可靠导航
   */
  if (!props.route.name) {
    console.warn(`[SubMenuItem] 路由缺少 name：${props.route.path}`);

    return;
  }

  /*
   * 真正进行路由跳转
   */
  router.push({
    name: props.route.name,
  });
}
</script>

<style scoped lang="less">
/* =========================================================
 * Menu Node
 * ========================================================= */

.menu-node {
  position: relative;

  display: flex;
  align-items: center;

  width: 100%;
  height: 36px;

  color: #666666;

  font-size: 13px;

  border-radius: 4px;

  box-sizing: border-box;

  transition:
    color 0.16s ease,
    background-color 0.16s ease;

  &.is-clickable {
    cursor: pointer;

    &:hover {
      color: #333333;
      background: #f7f7f7;
    }
  }

  &.has-children {
    cursor: default;
  }
}

/* =========================================================
 * Active
 * ========================================================= */

.menu-node.is-active {
  color: #31566d;

  background: #dfecfd;
}

/* =========================================================
 * Level
 * ========================================================= */

.menu-node.level-0 {
  padding-right: 8px;
}

.menu-node.level-1 {
  padding-right: 8px;
}

.menu-node.level-2 {
  padding-right: 8px;
}

.menu-node.level-3 {
  padding-right: 8px;
}

/* =========================================================
 * Arrow
 * ========================================================= */

.menu-node__arrow {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 28px;
  height: 36px;

  flex-shrink: 0;

  padding: 0;

  color: #999999;

  cursor: pointer;

  background: transparent;

  border: 0;
  outline: none;

  box-sizing: border-box;
}

.menu-node__arrow span {
  display: block;

  font-size: 18px;
  line-height: 1;

  transform: rotate(0deg);

  transition: transform 0.18s ease;
}

.menu-node__arrow span.is-expanded {
  transform: rotate(90deg);
}

/* =========================================================
 * 无子菜单占位
 * ========================================================= */

.menu-node__arrow-placeholder {
  display: block;

  width: 28px;
  height: 36px;

  flex-shrink: 0;
}

/* =========================================================
 * Title
 * ========================================================= */

.menu-node__title {
  min-width: 0;

  overflow: hidden;

  text-overflow: ellipsis;
  white-space: nowrap;
}

/* =========================================================
 * Children
 * ========================================================= */

.menu-node__children {
  width: 100%;

  padding-left: 16px;

  box-sizing: border-box;
}
</style>
