<template>
  <aside class="aside-menu-bar">
    <!-- =====================================================
         左侧模块滚动区域
         ===================================================== -->
    <div class="aside-menu-bar__scroll">
      <div class="aside-menu-bar__list">
        <div
          v-for="module in modules"
          :key="module.key"
          class="module-item"
          :class="{
            'is-active': layoutStore.currentModule === module.key,
          }"
          @mouseenter="handleMouseEnter(module)"
          @mouseleave="handleMouseLeave"
          @click="handleModuleClick(module)"
        >
          <!-- =================================================
               左侧图标
               ================================================= -->
          <div class="module-item__icon">
            {{ module.icon }}
          </div>
        </div>
      </div>
    </div>

    <!-- =====================================================
         右侧 Hover Popover

         注意：
         Popover 不再放在 module-item 内部。

         这样可以避免：
         module-item
            ↓
         scroll
            ↓
         overflow
            ↓
         Popover 被裁剪
         ===================================================== -->
    <div
      v-if="hoveredModule"
      class="module-popover"
      :class="{
        'is-active': layoutStore.currentModule === hoveredModule.key,
      }"
      :style="popoverStyle"
      @mouseenter="handlePopoverMouseEnter"
      @mouseleave="handlePopoverMouseLeave"
    >
      <!-- =================================================
           Arrow
           ================================================= -->
      <span
        class="module-popover__arrow"
        :class="{
          'is-active': layoutStore.currentModule === hoveredModule.key,
        }"
      />

      <!-- =================================================
           Module Name
           ================================================= -->
      <span class="module-popover__title">
        {{ hoveredModule.title }}
      </span>
    </div>
  </aside>
</template>

<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref } from "vue";

import { useRoute, useRouter } from "vue-router";

import { modules, useLayoutStore, type ModuleItem } from "@/store/layout.ts";

/* =========================================================
 * Router
 * ========================================================= */

const router = useRouter();

const route = useRoute();

/* =========================================================
 * Store
 * ========================================================= */

const layoutStore = useLayoutStore();

/* =========================================================
 * 当前 Hover 模块
 * ========================================================= */

const hoveredModule = ref<ModuleItem | null>(null);

/* =========================================================
 * 当前 Hover 模块索引
 * ========================================================= */

const hoveredModuleIndex = computed(() => {
  if (!hoveredModule.value) {
    return -1;
  }

  return modules.findIndex((module) => module.key === hoveredModule.value?.key);
});

/* =========================================================
 * Popover 位置
 *
 * 左侧：
 *
 * padding-top = 4px
 * module height = 48px
 * gap = 4px
 *
 * 所以：
 *
 * index 0 → 4px
 * index 1 → 56px
 * index 2 → 108px
 * index 3 → 160px
 *
 * ========================================================= */

const popoverStyle = computed(() => {
  const index = hoveredModuleIndex.value;

  if (index < 0) {
    return {};
  }

  const top = 4 + index * 52;

  return {
    top: `${top}px`,
  };
});

/* =========================================================
 * Hover 延迟关闭
 *
 * 防止鼠标从左侧模块
 * 移动到右侧 Popover 时，
 * 中间出现瞬间消失。
 * ========================================================= */

let leaveTimer: ReturnType<typeof setTimeout> | null = null;

/* =========================================================
 * 清理关闭 Timer
 * ========================================================= */

function clearLeaveTimer() {
  if (leaveTimer) {
    clearTimeout(leaveTimer);

    leaveTimer = null;
  }
}

/* =========================================================
 * Hover Module
 * ========================================================= */

function handleMouseEnter(module: ModuleItem) {
  clearLeaveTimer();

  hoveredModule.value = module;
}

/* =========================================================
 * Leave Module
 * ========================================================= */

function handleMouseLeave() {
  schedulePopoverClose();
}

/* =========================================================
 * Hover Popover
 * ========================================================= */

function handlePopoverMouseEnter() {
  clearLeaveTimer();
}

/* =========================================================
 * Leave Popover
 * ========================================================= */

function handlePopoverMouseLeave() {
  schedulePopoverClose();
}

/* =========================================================
 * 延迟关闭
 *
 * 这里给一点点缓冲，
 * 防止鼠标移动过程中闪烁。
 * ========================================================= */

function schedulePopoverClose() {
  clearLeaveTimer();

  leaveTimer = setTimeout(() => {
    hoveredModule.value = null;

    leaveTimer = null;
  }, 80);
}

/* =========================================================
 * 点击模块
 *
 * 1. 更新 Pinia
 * 2. 跳转到该模块默认页面
 * ========================================================= */

async function handleModuleClick(module: ModuleItem) {
  /*
   * 当前模块
   */
  layoutStore.setCurrentModule(module.key);

  /*
   * 找到模块默认路由
   */
  const routes = layoutStore.currentRoutes;

  if (!routes.length) {
    return;
  }

  /*
   * 优先寻找第一个
   * 可以作为入口的路由
   */
  const target = findFirstNavigableRoute(routes);

  if (!target) {
    return;
  }

  /*
   * 如果有 name，
   * 优先使用 name
   */
  if (target.name) {
    await router.push({
      name: target.name,
    });

    return;
  }

  /*
   * 没有 name 时
   * 使用 path
   */
  await router.push(buildAbsolutePath(module.key, target.path));
}

/* =========================================================
 * 找模块默认可导航路由
 *
 * 如果第一级只是目录，
 * 就继续往 children 找。
 * ========================================================= */

function findFirstNavigableRoute(routes: any[]): any | null {
  for (const route of routes) {
    const clickable = route.meta?.clickable;

    /*
     * 明确 clickable:false
     */
    if (clickable === false) {
      if (route.children?.length) {
        const child = findFirstNavigableRoute(route.children);

        if (child) {
          return child;
        }
      }

      continue;
    }

    /*
     * 有 children
     */
    if (route.children && route.children.length) {
      /*
       * 默认进入 children
       */
      const child = findFirstNavigableRoute(route.children);

      if (child) {
        return child;
      }

      /*
       * 如果明确允许父级点击
       */
      if (clickable === true) {
        return route;
      }

      continue;
    }

    /*
     * 叶子节点
     */
    return route;
  }

  return null;
}

/* =========================================================
 * 构建绝对路径
 * ========================================================= */

function buildAbsolutePath(moduleKey: string, routePath: string) {
  const cleanPath = routePath.replace(/^\/+/, "");

  return `/${moduleKey}/${cleanPath}`;
}

/* =========================================================
 * Router → Pinia
 *
 * URL 改变的时候，
 * 自动同步当前模块。
 * ========================================================= */

function syncModule() {
  layoutStore.syncModuleByPath(route.path);
}

/* =========================================================
 * 初始化
 * ========================================================= */

onMounted(() => {
  syncModule();
});

/* =========================================================
 * 清理
 * ========================================================= */

onBeforeUnmount(() => {
  clearLeaveTimer();
});
</script>

<style scoped lang="less">
/* =========================================================
 * Aside
 * ========================================================= */

.aside-menu-bar {
  position: relative;

  width: 48px;
  height: 100%;

  flex-shrink: 0;

  background: #ffffff;

  border-right: 1px solid #eeeeee;

  box-sizing: border-box;

  /*
   * 非常重要：
   *
   * Popover 在这个层级，
   * 允许向右溢出。
   */
  overflow: visible;

  z-index: 999;
}

/* =========================================================
 * Scroll
 *
 * 只负责左侧模块列表。
 * ========================================================= */

.aside-menu-bar__scroll {
  width: 48px;
  height: 100%;

  overflow-x: hidden;
  overflow-y: auto;

  scrollbar-width: none;
}

.aside-menu-bar__scroll::-webkit-scrollbar {
  display: none;
}

/* =========================================================
 * List
 * ========================================================= */

.aside-menu-bar__list {
  display: flex;
  flex-direction: column;
  align-items: center;

  width: 48px;

  padding: 4px 0;

  box-sizing: border-box;
}

/* =========================================================
 * Module
 * ========================================================= */

.module-item {
  position: relative;

  display: flex;
  align-items: center;
  justify-content: center;

  width: 40px;
  height: 48px;

  margin-bottom: 4px;

  flex-shrink: 0;

  cursor: pointer;

  border-radius: 4px;

  box-sizing: border-box;

  transition: background-color 0.16s ease;
}

/*
 * 最后一个模块不需要额外 margin
 */

.module-item:last-child {
  margin-bottom: 0;
}

/* =========================================================
 * Icon
 * ========================================================= */

.module-item__icon {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 40px;
  height: 48px;

  color: #555555;

  font-size: 20px;

  border-radius: 4px;

  box-sizing: border-box;

  transition:
    background-color 0.16s ease,
    color 0.16s ease;
}

/* =========================================================
 * Hover
 * ========================================================= */

.module-item:hover .module-item__icon {
  background: #f7f7f7;
}

/* =========================================================
 * Active
 * ========================================================= */

.module-item.is-active .module-item__icon {
  background: #dfecfd;
}

/*
 * Active + Hover
 *
 * active 永远保持蓝色，
 * 不被 hover 的灰色覆盖。
 */

.module-item.is-active:hover .module-item__icon {
  background: #dfecfd;
}

/* =========================================================
 * Popover
 *
 * 注意：
 *
 * 现在它已经不属于
 * module-item。
 *
 * 它属于 aside-menu-bar。
 *
 * 所以不会再受到
 * scroll 容器裁剪。
 * ========================================================= */

.module-popover {
  position: absolute;

  left: 44px;

  display: flex;
  align-items: center;

  width: 240px;
  height: 48px;

  padding: 0 16px;

  color: #555555;

  background: #f7f7f7;

  border-radius: 8px;

  box-sizing: border-box;

  pointer-events: auto;

  z-index: 1000000;

  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);

  /*
   * 让出现 / 消失更加自然
   */
  animation: modulePopoverIn 0.12s ease-out;
}

/* =========================================================
 * Popover Active
 * ========================================================= */

.module-popover.is-active {
  background: #dfecfd;
}

/* =========================================================
 * Popover Arrow
 * ========================================================= */

.module-popover__arrow {
  position: absolute;

  left: -5px;
  top: 18px;

  width: 10px;
  height: 10px;

  background: #f7f7f7;

  border-radius: 1px;

  transform: rotate(45deg);

  z-index: 0;
}

/* =========================================================
 * Arrow Active
 * ========================================================= */

.module-popover__arrow.is-active {
  background: #dfecfd;
}

/* =========================================================
 * Title
 * ========================================================= */

.module-popover__title {
  position: relative;

  z-index: 1;

  color: #555555;

  font-size: 13px;
  font-weight: 400;

  line-height: 1;

  white-space: nowrap;
}

/* =========================================================
 * Active Title
 * ========================================================= */

.module-popover.is-active .module-popover__title {
  color: #31566d;
}

/* =========================================================
 * Animation
 * ========================================================= */

@keyframes modulePopoverIn {
  from {
    opacity: 0;

    transform: translateX(-4px);
  }

  to {
    opacity: 1;

    transform: translateX(0);
  }
}
</style>
