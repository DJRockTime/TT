<template>
  <header>
    <!-- 填充标签 这个标签只用来展示主模块，比如 权限控制中心 X （权限控制中心 模块下的子栏目都在这个标签下）  -->
    <CustomerTags />
  </header>

  <section class="main-layout-body">
    <!-- 宽度48 px, 然后里面是 -->
    <AsideMenuBar />
    <SubAsideMenu />
    <MainContent />
  </section>
</template>

<script setup lang="ts">
import CustomerTags from "./CustomerTags.vue";
import AsideMenuBar from "./AsideMenuBar.vue";
import SubAsideMenu from "./SubAsideMenu.vue";
import MainContent from "./MainContent.vue";
</script>

<style lang="less" scoped>
.main-layout {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background: #ffffff;
}

.main-layout__header {
  width: 100%;
  height: 40px;
  flex-shrink: 0;
}

.main-layout__body {
  display: flex;

  width: 100%;
  height: calc(100vh - 40px);

  overflow: hidden;
}

.main-layout-body {
  display: flex;
  width: 100%;
  height: 100%;
}
</style>
