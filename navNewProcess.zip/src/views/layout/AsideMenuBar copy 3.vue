<template>
  <aside class="aside-menu" @mouseenter="handleAsideEnter" @mouseleave="handleAsideLeave">
    <!-- =====================================================
         左侧 48px 图标区域
         ===================================================== -->
    <div class="aside-menu__icons">
      <div
        v-for="(module, index) in modules"
        :key="module.key"
        class="module-icon"
        :class="{
          'is-active': layoutStore.currentModule === module.key,

          'is-hover': hoverIndex === index,
        }"
        @mouseenter="handleModuleEnter(index)"
        @click="handleSelect(module)"
      >
        <!-- =================================================
             Emoji
             ================================================= -->
        <span class="module-icon__emoji">
          {{ module.icon }}
        </span>
      </div>
    </div>

    <!-- =====================================================
         右侧 Hover 面板
         
         注意：
         Panel 独立于左侧 Scroll。
         
         这样不会被 overflow 裁剪。
         ===================================================== -->
    <div
      v-if="isPanelVisible"
      class="aside-menu__panel"
      @mouseenter="handlePanelEnter"
      @mouseleave="handlePanelLeave"
    >
      <div
        v-for="(module, index) in modules"
        :key="module.key"
        class="module-label"
        :class="{
          'is-active': layoutStore.currentModule === module.key,

          'is-hover': hoverIndex === index,
        }"
        @mouseenter="handleModuleEnter(index)"
        @click="handleSelect(module)"
      >
        <!-- =================================================
             Hover 箭头
             
             只有当前 Hover 的模块显示。
             ================================================= -->
        <span
          v-if="hoverIndex === index"
          class="module-label__arrow"
          :class="{
            'is-active': layoutStore.currentModule === module.key,
          }"
        />

        <!-- =================================================
             Module Title
             ================================================= -->
        <span class="module-label__text">
          {{ module.title }}
        </span>
      </div>
    </div>
  </aside>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from "vue";

import { useRoute, useRouter } from "vue-router";

import { modules, useLayoutStore, type ModuleItem } from "@/store/layout.ts";

/* =========================================================
 * Router
 * ========================================================= */

const router = useRouter();

const route = useRoute();

/* =========================================================
 * Store
 * ========================================================= */

const layoutStore = useLayoutStore();

/* =========================================================
 * 当前 Hover Index
 * ========================================================= */

const hoverIndex = ref<number | null>(null);

/* =========================================================
 * Panel 是否显示
 * ========================================================= */

const isPanelVisible = ref(false);

/* =========================================================
 * 延迟关闭 Timer
 *
 * 防止：
 *
 * 左侧 → 右侧 Panel
 *
 * 移动过程中 Panel 瞬间消失。
 * ========================================================= */

let leaveTimer: ReturnType<typeof setTimeout> | null = null;

/* =========================================================
 * 清理 Timer
 * ========================================================= */

function clearLeaveTimer() {
  if (leaveTimer) {
    clearTimeout(leaveTimer);

    leaveTimer = null;
  }
}

/* =========================================================
 * Aside Enter
 * ========================================================= */

function handleAsideEnter() {
  clearLeaveTimer();

  isPanelVisible.value = true;
}

/* =========================================================
 * Aside Leave
 * ========================================================= */

function handleAsideLeave() {
  schedulePanelClose();
}

/* =========================================================
 * Panel Enter
 * ========================================================= */

function handlePanelEnter() {
  clearLeaveTimer();

  isPanelVisible.value = true;
}

/* =========================================================
 * Panel Leave
 * ========================================================= */

function handlePanelLeave() {
  schedulePanelClose();
}

/* =========================================================
 * Module Enter
 * ========================================================= */

function handleModuleEnter(index: number) {
  clearLeaveTimer();

  hoverIndex.value = index;

  isPanelVisible.value = true;
}

/* =========================================================
 * Schedule Close
 * ========================================================= */

function schedulePanelClose() {
  clearLeaveTimer();

  leaveTimer = setTimeout(() => {
    hoverIndex.value = null;

    isPanelVisible.value = false;

    leaveTimer = null;
  }, 80);
}

/* =========================================================
 * 点击模块
 *
 * 保持上一版功能逻辑：
 *
 * 1. 更新 Pinia
 * 2. 找模块默认路由
 * 3. Router 跳转
 * ========================================================= */

async function handleSelect(module: ModuleItem) {
  /*
   * 更新当前模块
   */
  layoutStore.setCurrentModule(module.key);

  /*
   * 当前模块路由
   */
  const routes = layoutStore.currentRoutes;

  if (!routes.length) {
    return;
  }

  /*
   * 找默认可导航路由
   */
  const target = findFirstNavigableRoute(routes);

  if (!target) {
    return;
  }

  /*
   * 优先使用 name
   */
  if (target.name) {
    await router.push({
      name: target.name,
    });

    return;
  }

  /*
   * 没有 name
   * 使用绝对路径
   */
  await router.push(buildAbsolutePath(module.key, target.path));
}

/* =========================================================
 * 找模块默认可导航路由
 * ========================================================= */

function findFirstNavigableRoute(routes: any[]): any | null {
  for (const route of routes) {
    const clickable = route.meta?.clickable;

    /*
     * clickable:false
     */
    if (clickable === false) {
      if (route.children?.length) {
        const child = findFirstNavigableRoute(route.children);

        if (child) {
          return child;
        }
      }

      continue;
    }

    /*
     * 有 children
     */
    if (route.children && route.children.length) {
      const child = findFirstNavigableRoute(route.children);

      if (child) {
        return child;
      }

      /*
       * 明确允许父级点击
       */
      if (clickable === true) {
        return route;
      }

      continue;
    }

    /*
     * 叶子节点
     */
    return route;
  }

  return null;
}

/* =========================================================
 * 构建绝对路径
 * ========================================================= */

function buildAbsolutePath(moduleKey: string, routePath: string) {
  const cleanPath = routePath.replace(/^\/+/, "");

  return `/${moduleKey}/${cleanPath}`;
}

/* =========================================================
 * Router → Pinia
 * ========================================================= */

function syncModule() {
  layoutStore.syncModuleByPath(route.path);
}

/* =========================================================
 * 初始化
 * ========================================================= */

onMounted(() => {
  syncModule();
});

/* =========================================================
 * 清理
 * ========================================================= */

onBeforeUnmount(() => {
  clearLeaveTimer();
});
</script>

<style scoped lang="less">
/* =========================================================
 * Aside Menu
 * ========================================================= */

.aside-menu {
  position: relative;

  width: 48px;
  height: 100%;

  flex-shrink: 0;

  background: #ffffff;

  border-right: 1px solid #eeeeee;

  box-sizing: border-box;

  /*
   * 非常重要：
   *
   * 允许右侧 Panel
   * 溢出 48px 区域。
   */
  overflow: visible;

  /*
   * 防止点击时出现
   * 文本选择 / 光标。
   */
  user-select: none;
  -webkit-user-select: none;

  z-index: 999;
}

/* =========================================================
 * 左侧图标区域
 * ========================================================= */

.aside-menu__icons {
  display: flex;
  flex-direction: column;
  align-items: center;

  width: 48px;
  height: 100%;

  padding: 4px 0;

  overflow-x: hidden;
  overflow-y: auto;

  box-sizing: border-box;

  scrollbar-width: none;
}

.aside-menu__icons::-webkit-scrollbar {
  display: none;
}

/* =========================================================
 * 左侧图标
 *
 * 40 × 48
 * ========================================================= */

.module-icon {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 40px;
  height: 48px;

  flex-shrink: 0;

  margin-bottom: 4px;

  cursor: pointer;

  background: #ffffff;

  border-radius: 5px;

  box-sizing: border-box;

  transition: background-color 0.16s ease;
}

/* =========================================================
 * 最后一个取消 GAP
 * ========================================================= */

.module-icon:last-child {
  margin-bottom: 0;
}

/* =========================================================
 * Emoji
 * ========================================================= */

.module-icon__emoji {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 24px;
  height: 24px;

  font-size: 20px;

  line-height: 1;

  user-select: none;
}

/* =========================================================
 * 左侧 Hover
 * ========================================================= */

.module-icon.is-hover {
  background: #f7f7f7;
}

/* =========================================================
 * 左侧 Active
 * ========================================================= */

.module-icon.is-active {
  background: #dfecfd;
}

/* =========================================================
 * Active + Hover
 *
 * Active 永远保持蓝色。
 * ========================================================= */

.module-icon.is-active.is-hover {
  background: #dfecfd;
}

/* =========================================================
 * 右侧 Hover Panel
 *
 * 四个模块一起出现。
 *
 * Panel 自己是一个独立层，
 * 不属于左侧 Scroll。
 * ========================================================= */

.aside-menu__panel {
  position: absolute;

  top: 4px;
  left: 56px;

  width: 240px;

  display: flex;
  flex-direction: column;

  padding: 4px 0;

  box-sizing: border-box;

  overflow: visible;

  background: #ffffff;

  border-radius: 8px;

  box-shadow:
    0 6px 20px rgb(0 0 0 / 7%),
    0 1px 4px rgb(0 0 0 / 4%);

  z-index: 1000000;
}

/* =========================================================
 * 右侧模块
 *
 * 和左侧严格对应：
 *
 * 左侧：
 * 48px + 4px
 *
 * 右侧：
 * 48px + 4px
 * ========================================================= */

.module-label {
  position: relative;

  display: flex;
  align-items: center;

  width: 240px;
  height: 48px;

  flex-shrink: 0;

  margin-bottom: 4px;

  padding: 0 18px;

  color: #666666;

  font-size: 14px;

  font-weight: 400;

  cursor: pointer;

  background: #ffffff;

  border-radius: 6px;

  box-sizing: border-box;

  transition:
    color 0.16s ease,
    background-color 0.16s ease;
}

/* =========================================================
 * 最后一个取消 GAP
 * ========================================================= */

.module-label:last-child {
  margin-bottom: 0;
}

/* =========================================================
 * 右侧 Hover
 * ========================================================= */

.module-label.is-hover {
  color: #3f3f3f;

  background: #f7f7f7;
}

/* =========================================================
 * 右侧 Active
 * ========================================================= */

.module-label.is-active {
  color: #31566d;

  background: #dfecfd;
}

/* =========================================================
 * Active + Hover
 * ========================================================= */

.module-label.is-active.is-hover {
  color: #31566d;

  background: #dfecfd;
}

/* =========================================================
 * 右侧文字
 * ========================================================= */

.module-label__text {
  position: relative;

  z-index: 2;

  white-space: nowrap;

  user-select: none;
}

/* =========================================================
 * Hover 箭头
 *
 * 这里修复之前箭头不出来的问题。
 *
 * 不使用：
 *
 * z-index: -1
 *
 * 因为它很容易被父级背景
 * 或 stacking context 吃掉。
 *
 * 直接使用普通层级。
 * ========================================================= */

.module-label__arrow {
  position: absolute;

  left: -7px;
  top: 50%;

  width: 0;
  height: 0;

  border-top: 7px solid transparent;

  border-bottom: 7px solid transparent;

  border-right: 7px solid #f7f7f7;

  transform: translateY(-50%);

  z-index: 10;

  pointer-events: none;
}

/* =========================================================
 * Active Arrow
 * ========================================================= */

.module-label__arrow.is-active {
  border-right-color: #dfecfd;
}

/* =========================================================
 * Panel 出现动画
 * ========================================================= */

.aside-menu__panel {
  animation: asidePanelIn 0.12s ease-out;
}

@keyframes asidePanelIn {
  from {
    opacity: 0;

    transform: translateX(-4px);
  }

  to {
    opacity: 1;

    transform: translateX(0);
  }
}
</style>
