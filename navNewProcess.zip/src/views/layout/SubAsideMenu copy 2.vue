<template>
  <aside class="sub-aside-menu">
    <!-- =====================================================
         Header
         ===================================================== -->
    <header class="sub-aside-menu__header">
      <!-- 模块名称 -->
      <div v-if="!isSearchMode" class="sub-aside-menu__title">
        {{ currentModuleTitle }}
      </div>

      <!-- 搜索 -->
      <div v-else class="sub-aside-menu__search">
        <input
          ref="searchInputRef"
          v-model="searchKeyword"
          type="text"
          placeholder="搜索菜单"
          @blur="handleSearchBlur"
          @keydown.esc="handleSearchEscape"
        />
      </div>

      <!-- 操作区 -->
      <div class="sub-aside-menu__actions">
        <!-- 搜索 -->
        <button
          v-if="!isSearchMode"
          class="header-action"
          type="button"
          title="搜索菜单"
          @click="openSearch"
        >
          🔍
        </button>

        <!-- 全部展开 / 全部收起 -->
        <button
          class="header-action"
          type="button"
          :title="isAllExpanded ? '全部收起' : '全部展开'"
          @click="toggleAll"
        >
          {{ isAllExpanded ? "↑" : "↓" }}
        </button>
      </div>
    </header>

    <!-- =====================================================
         Menu Scroll
         ===================================================== -->
    <div class="sub-aside-menu__scroll">
      <nav class="sub-aside-menu__nav">
        <SubMenuItem
          v-for="routeItem in filteredRoutes"
          :key="getRouteKey(routeItem)"
          :route="routeItem"
          :level="0"
          :expanded-keys="expandedKeys"
          :search-keyword="searchKeyword"
          @toggle="toggleRoute"
        />

        <!-- =================================================
             搜索无结果
             ================================================= -->
        <div v-if="filteredRoutes.length === 0" class="sub-aside-menu__empty">
          <span class="sub-aside-menu__empty-icon"> 🔍 </span>

          <span> 没有找到相关菜单 </span>
        </div>
      </nav>
    </div>
  </aside>
</template>

<script setup lang="ts">
import { computed, nextTick, ref, watch } from "vue";

import { useRoute } from "vue-router";

import type { RouteRecordRaw } from "vue-router";

import { moduleRouteMap, useLayoutStore } from "@/store/layout.ts";

import SubMenuItem from "./SubMenuItem.vue";

/* =========================================================
 * Router
 * ========================================================= */

const route = useRoute();

/* =========================================================
 * Store
 * ========================================================= */

const layoutStore = useLayoutStore();

/* =========================================================
 * 当前模块名称
 * ========================================================= */

const currentModuleTitle = computed(() => {
  return layoutStore.currentModuleInfo?.title ?? "";
});

/* =========================================================
 * 当前模块路由
 * ========================================================= */

const currentRoutes = computed<RouteRecordRaw[]>(() => {
  return moduleRouteMap[layoutStore.currentModule] ?? [];
});

/* =========================================================
 * 当前展开的菜单
 * ========================================================= */

const expandedKeys = ref<Set<string>>(new Set());

/* =========================================================
 * 搜索
 * ========================================================= */

const isSearchMode = ref(false);

const searchKeyword = ref("");

const searchInputRef = ref<HTMLInputElement | null>(null);

/* =========================================================
 * Route Key
 * ========================================================= */

function getRouteKey(routeItem: RouteRecordRaw): string {
  if (routeItem.name) {
    return String(routeItem.name);
  }

  return routeItem.path;
}

/* =========================================================
 * 判断是否有 children
 * ========================================================= */

function hasChildren(routeItem: RouteRecordRaw): boolean {
  return Boolean(routeItem.children && routeItem.children.length);
}

/* =========================================================
 * 收集所有可展开节点
 * ========================================================= */

function collectExpandableKeys(routes: RouteRecordRaw[], result: Set<string>) {
  for (const routeItem of routes) {
    if (hasChildren(routeItem)) {
      result.add(getRouteKey(routeItem));

      collectExpandableKeys(routeItem.children!, result);
    }
  }
}

/* =========================================================
 * 全部可展开 Key
 * ========================================================= */

const allExpandableKeys = computed(() => {
  const result = new Set<string>();

  collectExpandableKeys(currentRoutes.value, result);

  return result;
});

/* =========================================================
 * 全部展开
 * ========================================================= */

function expandAll() {
  expandedKeys.value = new Set(allExpandableKeys.value);
}

/* =========================================================
 * 全部收起
 * ========================================================= */

function collapseAll() {
  expandedKeys.value = new Set();
}

/* =========================================================
 * 当前是否全部展开
 * ========================================================= */

const isAllExpanded = computed(() => {
  const allKeys = allExpandableKeys.value;

  if (allKeys.size === 0) {
    return true;
  }

  return Array.from(allKeys).every((key) => expandedKeys.value.has(key));
});

/* =========================================================
 * 全部展开 / 收起
 * ========================================================= */

function toggleAll() {
  if (isAllExpanded.value) {
    collapseAll();
  } else {
    expandAll();
  }
}

/* =========================================================
 * 单个菜单展开 / 收起
 * ========================================================= */

function toggleRoute(key: string) {
  const next = new Set(expandedKeys.value);

  if (next.has(key)) {
    next.delete(key);
  } else {
    next.add(key);
  }

  expandedKeys.value = next;
}

/* =========================================================
 * 当前路由是否属于某个节点
 *
 * 判断当前 route.matched
 *
 * 例如：
 *
 * /access-control/user/list
 *
 * matched：
 *
 * access-control
 * user
 * list
 * ========================================================= */

function routeContainsCurrent(routeItem: RouteRecordRaw): boolean {
  if (routeItem.name && route.matched.some((matched) => matched.name === routeItem.name)) {
    return true;
  }

  if (routeItem.children && routeItem.children.some((child) => routeContainsCurrent(child))) {
    return true;
  }

  return false;
}

/* =========================================================
 * 找到当前路由所在的父级
 * ========================================================= */

function collectCurrentParents(routes: RouteRecordRaw[], result: Set<string>): boolean {
  for (const routeItem of routes) {
    if (routeItem.children && routeItem.children.length) {
      const contains = routeItem.children.some((child) => routeContainsCurrent(child));

      if (contains) {
        result.add(getRouteKey(routeItem));

        collectCurrentParents(routeItem.children, result);

        return true;
      }
    }
  }

  return false;
}

/* =========================================================
 * 根据当前 Router 自动展开
 *
 * 例如：
 *
 * /access-control/user/list
 *
 * 自动：
 *
 * 用户管理 ↓
 *   用户列表 active
 * ========================================================= */

function expandCurrentRoute() {
  const parents = new Set<string>();

  collectCurrentParents(currentRoutes.value, parents);

  /*
   * 保留当前手动状态，
   * 只增加当前路径需要展开的节点。
   */
  const next = new Set(expandedKeys.value);

  parents.forEach((key) => {
    next.add(key);
  });

  expandedKeys.value = next;
}

/* =========================================================
 * 搜索过滤
 * ========================================================= */

const filteredRoutes = computed(() => {
  const keyword = searchKeyword.value.trim().toLowerCase();

  if (!keyword) {
    return currentRoutes.value;
  }

  return filterRoutes(currentRoutes.value, keyword);
});

/* =========================================================
 * 递归搜索
 * ========================================================= */

function filterRoutes(routes: RouteRecordRaw[], keyword: string): RouteRecordRaw[] {
  const result: RouteRecordRaw[] = [];

  for (const routeItem of routes) {
    const title = String(routeItem.meta?.title ?? routeItem.name ?? "");

    const currentMatched = title.toLowerCase().includes(keyword);

    const children = routeItem.children ? filterRoutes(routeItem.children, keyword) : [];

    /*
     * 当前节点匹配
     *
     * 或者
     *
     * 子节点匹配
     */
    if (currentMatched || children.length > 0) {
      result.push({
        ...routeItem,

        children: children.length > 0 ? children : routeItem.children,
      });
    }
  }

  return result;
}

/* =========================================================
 * 搜索状态变化
 *
 * 有搜索内容：
 *
 * 自动展开搜索结果
 * ========================================================= */

watch(searchKeyword, () => {
  if (searchKeyword.value.trim()) {
    const keys = new Set<string>();

    collectExpandableKeys(filteredRoutes.value, keys);

    expandedKeys.value = keys;
  } else {
    /*
     * 清空搜索以后，
     * 恢复当前路由需要的展开状态
     */
    expandAll();
    expandCurrentRoute();
  }
});

/* =========================================================
 * 当前模块变化
 *
 * 左侧 AsideMenuBar
 * 切换模块以后：
 *
 * 1. 清空搜索
 * 2. 默认全部展开
 * 3. 根据当前 URL 再定位一次
 * ========================================================= */

watch(
  () => layoutStore.currentModule,
  () => {
    searchKeyword.value = "";

    isSearchMode.value = false;

    nextTick(() => {
      expandAll();
      expandCurrentRoute();
    });
  },
  {
    immediate: true,
  },
);

/* =========================================================
 * Router 变化
 *
 * 点击子菜单、
 * 浏览器前进后退、
 * router.push
 *
 * 都会触发。
 * ========================================================= */

watch(
  () => route.fullPath,
  () => {
    nextTick(() => {
      expandCurrentRoute();
    });
  },
  {
    immediate: true,
  },
);

/* =========================================================
 * 搜索打开
 * ========================================================= */

function openSearch() {
  isSearchMode.value = true;

  nextTick(() => {
    searchInputRef.value?.focus();
  });
}

/* =========================================================
 * 搜索失焦
 * ========================================================= */

function handleSearchBlur() {
  isSearchMode.value = false;
}

/* =========================================================
 * ESC
 * ========================================================= */

function handleSearchEscape() {
  searchKeyword.value = "";

  isSearchMode.value = false;
}
</script>

<style scoped lang="less">
/* =========================================================
 * Container
 * ========================================================= */

.sub-aside-menu {
  display: flex;
  flex-direction: column;

  width: 220px;
  height: 100%;

  flex-shrink: 0;

  background: #ffffff;

  border-right: 1px solid #eeeeee;

  box-sizing: border-box;

  user-select: none;
}

/* =========================================================
 * Header
 * ========================================================= */

.sub-aside-menu__header {
  display: flex;
  align-items: center;

  width: 100%;
  height: 48px;

  flex-shrink: 0;

  padding: 0 12px;

  border-bottom: 1px solid #eeeeee;

  box-sizing: border-box;
}

/* =========================================================
 * Title
 * ========================================================= */

.sub-aside-menu__title {
  flex: 1;

  min-width: 0;

  overflow: hidden;

  color: #333333;

  font-size: 14px;
  font-weight: 500;

  line-height: 48px;

  text-overflow: ellipsis;
  white-space: nowrap;
}

/* =========================================================
 * Search
 * ========================================================= */

.sub-aside-menu__search {
  flex: 1;

  min-width: 0;
}

.sub-aside-menu__search input {
  width: 100%;
  height: 30px;

  padding: 0 8px;

  color: #333333;

  font-size: 13px;

  background: #f7f8f9;

  border: 1px solid #e5e7e9;

  border-radius: 4px;

  outline: none;

  box-sizing: border-box;

  transition:
    border-color 0.16s ease,
    background-color 0.16s ease;
}

.sub-aside-menu__search input:focus {
  background: #ffffff;

  border-color: #c5e3f2;
}

.sub-aside-menu__search input::placeholder {
  color: #aaaaaa;
}

/* =========================================================
 * Actions
 * ========================================================= */

.sub-aside-menu__actions {
  display: flex;
  align-items: center;

  flex-shrink: 0;

  margin-left: 8px;
}

/* =========================================================
 * Action Button
 * ========================================================= */

.header-action {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 28px;
  height: 28px;

  padding: 0;

  color: #777777;

  font-size: 15px;

  cursor: pointer;

  background: transparent;

  border: 0;
  border-radius: 4px;

  outline: none;

  transition:
    color 0.16s ease,
    background-color 0.16s ease;
}

.header-action:hover {
  color: #333333;

  background: #f7f7f7;
}

/* =========================================================
 * Scroll
 * ========================================================= */

.sub-aside-menu__scroll {
  flex: 1;

  min-height: 0;

  overflow-x: hidden;
  overflow-y: auto;

  scrollbar-width: none;
}

.sub-aside-menu__scroll::-webkit-scrollbar {
  display: none;
}

/* =========================================================
 * Nav
 * ========================================================= */

.sub-aside-menu__nav {
  width: 100%;

  padding: 8px 8px 16px;

  box-sizing: border-box;
}

/* =========================================================
 * Empty
 * ========================================================= */

.sub-aside-menu__empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  min-height: 160px;

  color: #999999;

  font-size: 13px;
}

.sub-aside-menu__empty-icon {
  margin-bottom: 8px;

  font-size: 22px;
}
</style>
