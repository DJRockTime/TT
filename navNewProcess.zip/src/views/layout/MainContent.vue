<template>
  <main class="main-content">
    <div class="main-content-inner">
      <!-- <router-view /> -->
      <router-view v-slot="{ Component }">
        <KeepAlive :include="keepAliveNames">
          <component :is="Component" :key="route.fullPath" />
        </KeepAlive>
      </router-view>
    </div>
  </main>
</template>
<script setup lang="ts">
import { useRoute } from "vue-router";
const route = useRoute();

const keepAliveNames = ref<string[]>(["RoleDetail"]);
</script>
<style scoped lang="less">
.main-content {
  flex: 1;
  min-width: 0;
  min-height: 0;
  height: 100%;
  overflow: hidden;
  background: #f7f8fa;
  box-sizing: border-box;
}
.main-content__inner {
  width: 100%;
  height: 100%;
  overflow: auto;
  box-sizing: border-box;
  scrollbar-width: thin;
  &::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
  &::-webkit-scrollbar-thumb {
    background: #d8dce2;
    border-radius: 3px;
  }
  &::-webkit-scrollbar-track {
    background: transparent;
  }
}
</style>
