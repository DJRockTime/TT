<template>
  <aside class="sub-aside-menu">
    <!-- =====================================================
         Header
         ===================================================== -->
    <header class="sub-aside-menu__header">
      <!-- 模块标题 -->
      <div v-if="!isSearchMode" class="sub-aside-menu__title">
        {{ currentModuleTitle }}
      </div>

      <!-- 搜索框 -->
      <div v-else class="sub-aside-menu__search">
        <input
          ref="searchInputRef"
          v-model="searchKeyword"
          type="text"
          placeholder="搜索菜单"
          @blur="handleSearchBlur"
          @keydown.esc="handleSearchEscape"
        />
      </div>

      <!-- Header 操作区 -->
      <div class="sub-aside-menu__actions">
        <!-- 搜索 -->
        <button
          v-if="!isSearchMode"
          class="header-action"
          type="button"
          title="搜索"
          @click="openSearch"
        >
          🔍
        </button>

        <!-- 全部展开 / 全部收起 -->
        <button
          class="header-action header-action--collapse"
          type="button"
          :title="isAllExpanded ? '全部收起' : '全部展开'"
          @click="toggleAll"
        >
          {{ isAllExpanded ? "↑" : "↓" }}
        </button>
      </div>
    </header>

    <!-- =====================================================
         Menu Scroll Container
         ===================================================== -->
    <div class="sub-aside-menu__scroll">
      <nav class="sub-aside-menu__nav">
        <template v-for="route in filteredRoutes" :key="getRouteKey(route)">
          <SubMenuItem
            :route="route"
            :level="0"
            :expanded-keys="expandedKeys"
            :search-keyword="searchKeyword"
            @toggle="toggleRoute"
          />
        </template>

        <!-- 搜索无结果 -->
        <div v-if="filteredRoutes.length === 0" class="sub-aside-menu__empty">
          <span class="sub-aside-menu__empty-icon"> 🔍 </span>

          <span>没有找到相关菜单</span>
        </div>
      </nav>
    </div>
  </aside>
</template>

<script setup lang="ts">
import { computed, nextTick, ref } from "vue";

import type { RouteRecordRaw } from "vue-router";

import accessControlRoutes from "@/router/access-control.ts";
import organizationRoutes from "@/router/organization.ts";
import opsRoutes from "@/router/ops.ts";
import documentRoutes from "@/router/document.ts";

import SubMenuItem from "./SubMenuItem.vue";

/* =========================================================
 * 当前模块
 *
 * 暂时不做左侧 AsideMenuBar 联动。
 *
 * 默认：
 * 权限控制中心
 * ========================================================= */

type ModuleKey = "access-control" | "organization" | "ops" | "document";

const currentModule = ref<ModuleKey>("access-control");

const moduleRouteMap: Record<ModuleKey, RouteRecordRaw[]> = {
  "access-control": accessControlRoutes,
  organization: organizationRoutes,
  ops: opsRoutes,
  document: documentRoutes,
};

const moduleTitleMap: Record<ModuleKey, string> = {
  "access-control": "权限控制中心",
  organization: "组织架构管理",
  ops: "系统运维监控",
  document: "文档基础配置",
};

/* =========================================================
 * 当前模块标题
 * ========================================================= */

const currentModuleTitle = computed(() => {
  return moduleTitleMap[currentModule.value];
});

/* =========================================================
 * 当前模块路由
 * ========================================================= */

const currentRoutes = computed(() => {
  return moduleRouteMap[currentModule.value] ?? [];
});

/* =========================================================
 * 展开状态
 *
 * Set 保存所有展开的 route key
 * ========================================================= */

const expandedKeys = ref<Set<string>>(new Set());

/* =========================================================
 * 搜索
 * ========================================================= */

const isSearchMode = ref(false);

const searchKeyword = ref("");

const searchInputRef = ref<HTMLInputElement | null>(null);

/* =========================================================
 * 搜索过滤
 *
 * 当前只搜索当前模块。
 *
 * 注意：
 * 父级如果匹配，
 * 则保留整个父级。
 *
 * 子级匹配，
 * 则保留父级以及匹配的子级。
 * ========================================================= */

const filteredRoutes = computed(() => {
  const keyword = searchKeyword.value.trim().toLowerCase();

  if (!keyword) {
    return currentRoutes.value;
  }

  return filterRoutes(currentRoutes.value, keyword);
});

/* =========================================================
 * 初始化
 *
 * 默认全部展开
 * ========================================================= */

function initializeExpandedRoutes() {
  const keys = new Set<string>();

  collectExpandableRoutes(currentRoutes.value, keys);

  expandedKeys.value = keys;
}

initializeExpandedRoutes();

/* =========================================================
 * 收集所有可以展开的路由
 * ========================================================= */

function collectExpandableRoutes(routes: RouteRecordRaw[], keys: Set<string>) {
  for (const route of routes) {
    if (route.children && route.children.length > 0) {
      keys.add(getRouteKey(route));

      collectExpandableRoutes(route.children, keys);
    }
  }
}

/* =========================================================
 * 获取唯一 Key
 * ========================================================= */

function getRouteKey(route: RouteRecordRaw): string {
  if (route.name) {
    return String(route.name);
  }

  return route.path;
}

/* =========================================================
 * 判断是否允许点击
 *
 * 默认规则：
 *
 * 有 children 的一级菜单：
 * 不允许点击
 *
 * 没有 children：
 * 可以点击
 *
 * meta.clickable 可以覆盖默认规则。
 *
 * clickable: true
 * clickable: false
 * ========================================================= */

function isClickable(route: RouteRecordRaw): boolean {
  const meta = route.meta as Record<string, unknown> | undefined;

  if (typeof meta?.clickable === "boolean") {
    return meta.clickable;
  }

  if (route.children && route.children.length > 0) {
    return false;
  }

  return true;
}

/* =========================================================
 * 搜索过滤
 * ========================================================= */

function filterRoutes(routes: RouteRecordRaw[], keyword: string): RouteRecordRaw[] {
  const result: RouteRecordRaw[] = [];

  for (const route of routes) {
    const meta = route.meta as Record<string, unknown> | undefined;

    const title = String(meta?.title ?? "");

    const currentMatched = title.toLowerCase().includes(keyword);

    const children = route.children ? filterRoutes(route.children, keyword) : [];

    if (currentMatched || children.length > 0) {
      result.push({
        ...route,
        children: children.length > 0 ? children : route.children,
      });
    }
  }

  return result;
}

/* =========================================================
 * 单个菜单展开 / 收起
 * ========================================================= */

function toggleRoute(key: string) {
  const next = new Set(expandedKeys.value);

  if (next.has(key)) {
    next.delete(key);
  } else {
    next.add(key);
  }

  expandedKeys.value = next;
}

/* =========================================================
 * 是否全部展开
 * ========================================================= */

const allExpandableKeys = computed(() => {
  const keys = new Set<string>();

  collectExpandableRoutes(currentRoutes.value, keys);

  return keys;
});

const isAllExpanded = computed(() => {
  const allKeys = allExpandableKeys.value;

  if (allKeys.size === 0) {
    return true;
  }

  return Array.from(allKeys).every((key) => expandedKeys.value.has(key));
});

/* =========================================================
 * 全部展开 / 全部收起
 * ========================================================= */

function toggleAll() {
  if (isAllExpanded.value) {
    expandedKeys.value = new Set();
    return;
  }

  expandedKeys.value = new Set(allExpandableKeys.value);
}

/* =========================================================
 * 打开搜索
 * ========================================================= */

function openSearch() {
  isSearchMode.value = true;

  nextTick(() => {
    searchInputRef.value?.focus();
  });
}

/* =========================================================
 * 搜索失焦
 * ========================================================= */

function handleSearchBlur() {
  /*
   * 如果有搜索内容，
   * 失焦以后仍然恢复标题。
   */
  isSearchMode.value = false;
}

/* =========================================================
 * ESC
 * ========================================================= */

function handleSearchEscape() {
  searchKeyword.value = "";
  isSearchMode.value = false;
}
</script>

<style scoped lang="less">
/* =========================================================
 * Sub Aside Menu
 * ========================================================= */

.sub-aside-menu {
  display: flex;
  flex-direction: column;

  width: 220px;
  height: 100%;

  flex-shrink: 0;

  background: #ffffff;
  border-right: 1px solid #eeeeee;

  box-sizing: border-box;

  user-select: none;
}

/* =========================================================
 * Header
 * ========================================================= */

.sub-aside-menu__header {
  display: flex;
  align-items: center;

  width: 100%;
  height: 48px;

  flex-shrink: 0;

  padding: 0 12px;

  box-sizing: border-box;

  border-bottom: 1px solid #eeeeee;
}

/* =========================================================
 * 模块标题
 * ========================================================= */

.sub-aside-menu__title {
  flex: 1;

  overflow: hidden;

  color: #333333;

  font-size: 14px;
  font-weight: 500;

  line-height: 48px;

  text-overflow: ellipsis;
  white-space: nowrap;
}

/* =========================================================
 * 搜索区域
 * ========================================================= */

.sub-aside-menu__search {
  flex: 1;

  min-width: 0;
}

/* =========================================================
 * 搜索 Input
 *
 * 原生 input
 * ========================================================= */

.sub-aside-menu__search input {
  width: 100%;
  height: 30px;

  padding: 0 8px;

  color: #333333;

  font-size: 13px;

  background: #f7f8f9;

  border: 1px solid #e5e7e9;
  border-radius: 4px;

  outline: none;

  box-sizing: border-box;

  transition:
    border-color 0.16s ease,
    background-color 0.16s ease;

  &:focus {
    background: #ffffff;
    border-color: #c5e3f2;
  }

  &::placeholder {
    color: #aaaaaa;
  }
}

/* =========================================================
 * Header 操作区
 * ========================================================= */

.sub-aside-menu__actions {
  display: flex;
  align-items: center;

  flex-shrink: 0;

  margin-left: 8px;
}

/* =========================================================
 * Header Button
 * ========================================================= */

.header-action {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 28px;
  height: 28px;

  padding: 0;

  color: #777777;

  font-size: 15px;

  cursor: pointer;

  background: transparent;

  border: 0;
  border-radius: 4px;

  outline: none;

  box-sizing: border-box;

  transition:
    color 0.16s ease,
    background-color 0.16s ease;

  &:hover {
    color: #333333;
    background: #f7f7f7;
  }

  &:active {
    background: #eeeeee;
  }
}

/* =========================================================
 * Scroll
 * ========================================================= */

.sub-aside-menu__scroll {
  flex: 1;

  min-height: 0;

  overflow-x: hidden;
  overflow-y: auto;

  scrollbar-width: none;

  &::-webkit-scrollbar {
    display: none;
  }
}

/* =========================================================
 * Menu
 * ========================================================= */

.sub-aside-menu__nav {
  width: 100%;

  padding: 8px 8px 16px;

  box-sizing: border-box;
}

/* =========================================================
 * Empty
 * ========================================================= */

.sub-aside-menu__empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  min-height: 160px;

  color: #999999;

  font-size: 13px;
}

.sub-aside-menu__empty-icon {
  margin-bottom: 8px;

  font-size: 22px;
}
</style>
