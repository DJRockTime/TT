<template>
  <div class="customer-tags">
    <div
      v-for="tag in tags"
      :key="tag.key"
      class="customer-tag"
      :class="{
        'is-active': tag.key === activeTagKey,

        'is-detail': tag.type === 'detail',
      }"
      @click="handleTagClick(tag)"
    >
      <span class="customer-tag__title">
        {{ tag.title }}
      </span>

      <button
        v-if="tags.length > 1"
        class="customer-tag__close"
        type="button"
        aria-label="关闭标签"
        @click.stop="handleClose(tag)"
      >
        ×
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref, watch } from "vue";

import { useRoute, useRouter } from "vue-router";

import { useLayoutStore } from "@/store/layout.ts";

import { useNavigationStore } from "@/store/navigation";

import { useDropKeepAlive } from "@/composables/useKeepAlive.ts";

/* =========================================================
 * Tag
 * ========================================================= */

interface CustomerTag {
  key: string;

  title: string;

  path: string;

  type: "module" | "detail";
}

/* =========================================================
 * Router
 * ========================================================= */

const router = useRouter();

const route = useRoute();

/* =========================================================
 * Store
 * ========================================================= */

const layoutStore = useLayoutStore();

const navigationStore = useNavigationStore();

/* =========================================================
 * Module Map
 * ========================================================= */

const moduleMap: Record<
  string,
  {
    title: string;
    path: string;
  }
> = {
  "access-control": {
    title: "权限控制中心",

    path: "/access-control/user",
  },

  organization: {
    title: "组织架构管理",

    path: "/organization/department",
  },

  ops: {
    title: "系统运维监控",

    path: "/ops/monitor",
  },

  document: {
    title: "文档基础配置",

    path: "/document/category",
  },
};

/* =========================================================
 * Tags
 * ========================================================= */

const tags = ref<CustomerTag[]>([
  {
    key: "access-control",

    title: "权限控制中心",

    path: "/access-control/user",

    type: "module",
  },
]);

/* =========================================================
 * Detail
 * ========================================================= */

function isDetailRoute() {
  return route.meta.detail === true;
}

/* =========================================================
 * Current Module
 * ========================================================= */

function getCurrentModule() {
  return route.meta.module as string | undefined;
}

/* =========================================================
 * Active Tag
 * ========================================================= */

const activeTagKey = computed(() => {
  /* =======================================================
   * Detail
   * ======================================================= */

  if (isDetailRoute()) {
    return route.fullPath;
  }

  /* =======================================================
   * 普通模块
   * ======================================================= */

  const module = getCurrentModule();

  if (module && moduleMap[module]) {
    return module;
  }

  return route.fullPath;
});

/* =========================================================
 * Detail ID
 * ========================================================= */

function getDetailId() {
  const values = Object.values(route.params);

  if (!values.length) {
    return "";
  }

  const value = values[0];

  if (Array.isArray(value)) {
    return value.join("/");
  }

  return String(value);
}

/* =========================================================
 * Update Tags
 * ========================================================= */

function updateCurrentTag() {
  /* =======================================================
   * Router → Layout Store
   * ======================================================= */

  const module = getCurrentModule();

  if (module && moduleMap[module] && layoutStore.currentModule !== module) {
    layoutStore.setCurrentModule(module);
  }

  /* =======================================================
   * Detail
   * ======================================================= */

  if (isDetailRoute()) {
    const key = route.fullPath;

    const exists = tags.value.some((tag) => tag.key === key);

    if (!exists) {
      const id = getDetailId();

      tags.value.push({
        key,

        title: id ? `详情 ${id}` : "详情",

        path: route.fullPath,

        type: "detail",
      });
    }

    return;
  }

  /* =======================================================
   * Module
   * ======================================================= */

  if (module && moduleMap[module]) {
    const moduleInfo = moduleMap[module];

    const exists = tags.value.some((tag) => tag.key === module);

    if (!exists) {
      tags.value.push({
        key: module,

        title: moduleInfo.title,

        path: moduleInfo.path,

        type: "module",
      });
    }
  }
}

/* =========================================================
 * Route Watch
 * ========================================================= */

watch(
  () => route.fullPath,

  () => {
    updateCurrentTag();
  },

  {
    immediate: true,
  },
);

/* =========================================================
 * Click Tag
 *
 * ★★★ 第四步核心 ★★★
 *
 * Module Tag：
 *
 *     ↓
 * 读取模块导航记忆
 *
 *     ↓
 * 有记忆
 *     → 恢复最后访问页面
 *
 * 没有记忆
 *     → Tag 默认 path
 *
 * Detail Tag：
 *
 *     → 直接恢复 detail path
 * ========================================================= */

async function handleTagClick(tag: CustomerTag) {
  /* =======================================================
   * Detail Tag
   * ======================================================= */

  if (tag.type === "detail") {
    if (route.fullPath === tag.path) {
      return;
    }

    await router.push(tag.path);

    return;
  }

  /* =======================================================
   * Module Tag
   * ======================================================= */

  const module = tag.key;

  /* =======================================================
   * 同步当前模块
   * ======================================================= */

  if (module && layoutStore.currentModule !== module) {
    layoutStore.setCurrentModule(module);
  }

  /* =======================================================
   * ★ 优先读取模块记忆
   * ======================================================= */

  const rememberedRoute = navigationStore.getRememberedRoute(module);

  /* =======================================================
   * 有记忆
   * ======================================================= */

  if (rememberedRoute) {
    if (route.fullPath !== rememberedRoute) {
      await router.push(rememberedRoute);
    }

    return;
  }

  /* =======================================================
   * 没有记忆
   *
   * 使用 Tag 默认 path
   * ======================================================= */

  if (route.fullPath !== tag.path) {
    await router.push(tag.path);
  }
}

/* =========================================================
 * Close Tag
 *
 * ★ 保留当前关闭清理机制
 * ========================================================= */

async function handleClose(tag: CustomerTag) {
  if (tags.value.length <= 1) {
    return;
  }

  const index = tags.value.findIndex((item) => item.key === tag.key);

  if (index === -1) {
    return;
  }

  const isCurrent = tag.key === activeTagKey.value;

  /* =======================================================
   * ★ 关闭模块 Tag
   *
   * 删除该模块导航记忆。
   *
   * Detail Tag 不参与模块记忆。
   * ======================================================= */

  if (tag.type === "module") {
    navigationStore.removeRememberedRoute(tag.key);

    // useDropKeepAlive.module(tag.key);
  } else if (tag.type === "detail") {
    /*
     * 详情 Tag 单独管理自己的页面状态
     */
    // useDropKeepAlive.route(tag.path);
  }

  /* =======================================================
   * 删除 Tag
   * ======================================================= */

  tags.value.splice(index, 1);

  /* =======================================================
   * 非当前 Tag
   *
   * 不需要改变当前 Router。
   * ======================================================= */

  if (!isCurrent) {
    return;
  }

  /* =======================================================
   * 当前 Tag 被关闭
   *
   * 优先右边
   * ↓
   * 左边
   * ↓
   * 第一个
   * ======================================================= */

  const nextTag = tags.value[index] ?? tags.value[index - 1] ?? tags.value[0];

  if (!nextTag) {
    return;
  }

  /* =======================================================
   * ★ 不直接使用 nextTag.path
   *
   * 因为 nextTag 可能是 module Tag，
   * handleTagClick 会自动读取其记忆。
   * ======================================================= */

  await handleTagClick(nextTag);
}
</script>

<style scoped lang="less">
.customer-tags {
  display: flex;
  align-items: center;

  width: 100%;
  height: 40px;

  padding: 0 14px;

  overflow-x: auto;
  overflow-y: hidden;

  box-sizing: border-box;

  background: #ffffff;

  border-bottom: 1px solid #eeeeee;

  scrollbar-width: none;

  &::-webkit-scrollbar {
    display: none;
  }
}

.customer-tag {
  display: inline-flex;
  align-items: center;
  justify-content: center;

  flex-shrink: 0;

  height: 28px;

  margin-right: 7px;

  padding: 0 8px 0 13px;

  color: #777777;

  font-size: 13px;
  font-weight: 400;

  line-height: 1;

  cursor: pointer;

  background: #f7f8f9;

  border: 1px solid #eeeeee;

  border-radius: 4px;

  box-sizing: border-box;

  transition:
    color 0.18s ease,
    background-color 0.18s ease,
    border-color 0.18s ease,
    box-shadow 0.18s ease;

  &:hover {
    color: #3d3d3d;

    background: #f2f4f5;

    border-color: #e3e5e7;
  }

  &.is-active {
    color: #2f596d;

    background: #c5e3f2;

    border-color: #b6d8e8;

    box-shadow: 0 2px 6px rgb(76 123 148 / 10%);
  }

  &.is-active:hover {
    background: #c5e3f2;

    border-color: #b6d8e8;
  }
}

.customer-tag__title {
  display: block;

  max-width: 140px;

  overflow: hidden;

  text-overflow: ellipsis;

  white-space: nowrap;
}

.customer-tag__close {
  display: inline-flex;

  align-items: center;
  justify-content: center;

  width: 18px;
  height: 18px;

  margin-left: 5px;

  padding: 0;

  color: #9aa0a4;

  font-family: Arial, sans-serif;

  font-size: 15px;

  line-height: 18px;

  cursor: pointer;

  background: transparent;

  border: 0;

  border-radius: 50%;

  transition:
    color 0.18s ease,
    background-color 0.18s ease;

  &:hover {
    color: #ffffff;

    background: rgb(67 92 105 / 45%);
  }
}

.customer-tag.is-active {
  .customer-tag__close {
    color: #638394;

    &:hover {
      color: #ffffff;

      background: rgb(67 92 105 / 55%);
    }
  }
}
</style>
