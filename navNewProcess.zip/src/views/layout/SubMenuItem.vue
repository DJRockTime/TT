<template>
  <!-- =====================================================
       详情路由不参与菜单展示
       ===================================================== -->
  <div v-if="!isDetailRoute" class="sub-menu-item">
    <!-- =====================================================
         当前菜单
         ===================================================== -->
    <div
      class="menu-node"
      :class="{
        'is-clickable': clickable,
        'has-children': hasChildren,
        'is-active': isActive,
        [`level-${level}`]: true,
      }"
      @click="handleClick"
    >
      <!-- 展开箭头 -->
      <button v-if="hasChildren" class="menu-node__arrow" type="button" @click.stop="handleToggle">
        <span
          :class="{
            'is-expanded': isExpanded,
          }"
        >
          ›
        </span>
      </button>

      <!-- 没有子节点时占位 -->
      <span v-else class="menu-node__arrow-placeholder" />

      <!-- 菜单标题 -->
      <span class="menu-node__title">
        {{ title }}
      </span>
    </div>

    <!-- =====================================================
         子菜单
         ===================================================== -->
    <div v-if="hasChildren && isExpanded" class="menu-node__children">
      <SubMenuItem
        v-for="child in visibleChildren"
        :key="getRouteKey(child)"
        :route="child"
        :level="level + 1"
        :expanded-keys="expandedKeys"
        :search-keyword="searchKeyword"
        @toggle="$emit('toggle', $event)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from "vue";

import { useRoute, useRouter } from "vue-router";

import type { RouteRecordRaw } from "vue-router";

/* =========================================================
 * Props
 * ========================================================= */

interface Props {
  route: RouteRecordRaw;
  level: number;
  expandedKeys: Set<string>;
  searchKeyword: string;
}

const props = defineProps<Props>();

/* =========================================================
 * Emits
 * ========================================================= */

const emit = defineEmits<{
  toggle: [key: string];
}>();

/* =========================================================
 * Router
 * ========================================================= */

const router = useRouter();

const currentRoute = useRoute();

/* =========================================================
 * Meta
 * ========================================================= */

const meta = computed(() => {
  return props.route.meta as Record<string, unknown> | undefined;
});

/* =========================================================
 * 是否为详情路由
 *
 * 规则：
 *
 * meta.detail === true
 *
 * 详情页面：
 *
 *   /role/:id
 *   /user/:id
 *   /order/:id
 *
 * 不参与左侧菜单展示。
 * ========================================================= */

const isDetailRoute = computed(() => {
  return meta.value?.detail === true;
});

/* =========================================================
 * 标题
 * ========================================================= */

const title = computed(() => {
  return String(props.route.meta?.title ?? props.route.name ?? props.route.path);
});

/* =========================================================
 * 可见子路由
 *
 * ★ 核心
 *
 * detail: true 的路由直接从菜单树中过滤掉。
 *
 * 例如：
 *
 * role
 * ├── list
 * ├── create
 * └── role/:id       ← detail: true
 *
 * 最终菜单只看到：
 *
 * role
 * ├── list
 * └── create
 * ========================================================= */

const visibleChildren = computed<RouteRecordRaw[]>(() => {
  if (!props.route.children?.length) {
    return [];
  }

  return props.route.children.filter((child) => {
    return child.meta?.detail !== true;
  });
});

/* =========================================================
 * 子路由
 *
 * 注意：
 *
 * 这里不能再直接判断：
 *
 * props.route.children
 *
 * 而应该判断过滤后的 visibleChildren。
 * ========================================================= */

const hasChildren = computed(() => {
  return visibleChildren.value.length > 0;
});

/* =========================================================
 * Key
 * ========================================================= */

function getRouteKey(route: RouteRecordRaw) {
  if (route.name) {
    return String(route.name);
  }

  return route.path;
}

const routeKey = computed(() => {
  return getRouteKey(props.route);
});

/* =========================================================
 * 是否展开
 * ========================================================= */

const isExpanded = computed(() => {
  return props.expandedKeys.has(routeKey.value);
});

/* =========================================================
 * 是否可点击
 *
 * 默认：
 *
 * 有 children
 *   → 不可点击
 *
 * 没 children
 *   → 可以点击
 *
 * meta.clickable 可以覆盖默认行为。
 * ========================================================= */

const clickable = computed(() => {
  if (typeof meta.value?.clickable === "boolean") {
    return meta.value.clickable;
  }

  return !hasChildren.value;
});

/* =========================================================
 * 当前路由是否 Active
 * ========================================================= */

const isActive = computed(() => {
  if (!props.route.name) {
    return false;
  }

  return currentRoute.name === props.route.name;
});

/* =========================================================
 * 展开 / 收起
 * ========================================================= */

function handleToggle() {
  emit("toggle", routeKey.value);
}

/* =========================================================
 * 点击菜单
 * ========================================================= */

function handleClick() {
  /* =======================================================
   * 有 children 的菜单
   *
   * 默认只是展开 / 收起。
   * ======================================================= */

  if (!clickable.value) {
    if (hasChildren.value) {
      handleToggle();
    }

    return;
  }

  /* =======================================================
   * 没有 name 的路由无法进行可靠导航
   * ======================================================= */

  if (!props.route.name) {
    console.warn(`[SubMenuItem] 路由缺少 name：${props.route.path}`);

    return;
  }

  /* =======================================================
   * 防御：
   *
   * detail 路由理论上已经不会进入菜单。
   *
   * 这里再加一道保险。
   *
   * 防止以后某个地方错误地把 detail 路由塞进菜单。
   * ======================================================= */

  if (isDetailRoute.value) {
    console.warn(`[SubMenuItem] 详情路由不允许作为菜单导航：${String(props.route.name)}`);

    return;
  }

  /* =======================================================
   * 真正进行路由跳转
   *
   * 注意：
   *
   * 这里只处理普通菜单路由。
   *
   * /role/:id
   *
   * 不会走到这里。
   * ======================================================= */

  router.push({
    name: props.route.name,
  });
}
</script>

<style scoped lang="less">
/* =========================================================
 * Menu Node
 * ========================================================= */

.menu-node {
  position: relative;

  display: flex;
  align-items: center;

  width: 100%;
  height: 36px;

  color: #666666;

  font-size: 13px;

  border-radius: 4px;

  box-sizing: border-box;

  transition:
    color 0.16s ease,
    background-color 0.16s ease;

  &.is-clickable {
    cursor: pointer;

    &:hover {
      color: #333333;

      background: #f7f7f7;
    }
  }

  &.has-children {
    cursor: default;
  }
}

/* =========================================================
 * Active
 * ========================================================= */

.menu-node.is-active {
  color: #31566d;

  background: #dfecfd;
}

/* =========================================================
 * Level
 * ========================================================= */

.menu-node.level-0 {
  padding-right: 8px;
}

.menu-node.level-1 {
  padding-right: 8px;
}

.menu-node.level-2 {
  padding-right: 8px;
}

.menu-node.level-3 {
  padding-right: 8px;
}

/* =========================================================
 * Arrow
 * ========================================================= */

.menu-node__arrow {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 28px;
  height: 36px;

  flex-shrink: 0;

  padding: 0;

  color: #999999;

  cursor: pointer;

  background: transparent;

  border: 0;

  outline: none;

  box-sizing: border-box;
}

.menu-node__arrow span {
  display: block;

  font-size: 18px;

  line-height: 1;

  transform: rotate(0deg);

  transition: transform 0.18s ease;
}

.menu-node__arrow span.is-expanded {
  transform: rotate(90deg);
}

/* =========================================================
 * 无子菜单占位
 * ========================================================= */

.menu-node__arrow-placeholder {
  display: block;

  width: 28px;
  height: 36px;

  flex-shrink: 0;
}

/* =========================================================
 * Title
 * ========================================================= */

.menu-node__title {
  min-width: 0;

  overflow: hidden;

  text-overflow: ellipsis;

  white-space: nowrap;
}

/* =========================================================
 * Children
 * ========================================================= */

.menu-node__children {
  width: 100%;

  padding-left: 16px;

  box-sizing: border-box;
}
</style>
