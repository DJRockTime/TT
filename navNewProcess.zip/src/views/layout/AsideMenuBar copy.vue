<template>
  <aside class="aside-menu" @mouseenter="handleAsideEnter" @mouseleave="handleAsideLeave">
    <!-- =====================================================
         左侧 48px 图标区域
         ===================================================== -->
    <div class="aside-menu__icons">
      <div
        v-for="(module, index) in modules"
        :key="module.key"
        class="module-icon"
        :class="{
          'is-active': activeIndex === index,
          'is-hover': hoverIndex === index,
        }"
        @mouseenter="handleModuleEnter(index)"
        @click="handleSelect(index)"
      >
        <span class="module-icon__emoji">
          {{ module.icon }}
        </span>
      </div>
    </div>

    <!-- =====================================================
         右侧 Hover 面板
         ===================================================== -->
    <div v-if="isPanelVisible" class="aside-menu__panel">
      <div
        v-for="(module, index) in modules"
        :key="module.key"
        class="module-label"
        :class="{
          'is-active': activeIndex === index,
          'is-hover': hoverIndex === index,
        }"
        @mouseenter="handleModuleEnter(index)"
        @click="handleSelect(index)"
      >
        <span
          v-if="hoverIndex === index"
          class="module-label__arrow"
          :class="{
            'is-active': activeIndex === index,
          }"
        />

        <span class="module-label__text">
          {{ module.title }}
        </span>
      </div>
    </div>
  </aside>
</template>

<script setup lang="ts">
import { ref } from "vue";

interface ModuleItem {
  key: string;
  title: string;
  icon: string;
}

const modules: ModuleItem[] = [
  {
    key: "access-control",
    title: "权限控制中心",
    icon: "🍃",
  },
  {
    key: "organization",
    title: "组织架构管理",
    icon: "🏀",
  },
  {
    key: "ops",
    title: "系统运维监控",
    icon: "🍂",
  },
  {
    key: "document",
    title: "文档基础配置",
    icon: "⚾",
  },
];

/**
 * 当前 Active 模块
 */
const activeIndex = ref(0);

/**
 * 当前 Hover 模块
 */
const hoverIndex = ref<number | null>(null);

/**
 * 右侧面板
 */
const isPanelVisible = ref(false);

function handleAsideEnter() {
  isPanelVisible.value = true;
}

function handleAsideLeave() {
  hoverIndex.value = null;
  isPanelVisible.value = false;
}

function handleModuleEnter(index: number) {
  hoverIndex.value = index;
}

function handleSelect(index: number) {
  activeIndex.value = index;
}
</script>

<style scoped lang="less">
/* =========================================================
 * Aside Menu
 * ========================================================= */

.aside-menu {
  position: relative;

  width: 48px;
  height: 100%;

  flex-shrink: 0;

  background: #ffffff;
  border-right: 1px solid #eeeeee;

  box-sizing: border-box;

  /*
   * 禁止文本选择
   *
   * 防止点击时出现文本光标 / 选中文本
   */
  user-select: none;
  -webkit-user-select: none;
}

/* =========================================================
 * 左侧图标区域
 * ========================================================= */

.aside-menu__icons {
  display: flex;
  flex-direction: column;
  align-items: center;

  width: 48px;
  height: 100%;

  padding: 4px 0;

  overflow-x: hidden;
  overflow-y: auto;

  box-sizing: border-box;

  scrollbar-width: none;

  &::-webkit-scrollbar {
    display: none;
  }
}

/* =========================================================
 * 左侧图标
 *
 * 40 × 48
 * ========================================================= */

.module-icon {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 40px;
  height: 48px;

  flex-shrink: 0;

  /*
   * 左右统一 GAP
   */
  margin-bottom: 4px;

  cursor: pointer;

  background: #ffffff;

  border-radius: 5px;

  box-sizing: border-box;

  transition: background-color 0.16s ease;
}

/* =========================================================
 * Emoji
 * ========================================================= */

.module-icon__emoji {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 24px;
  height: 24px;

  font-size: 20px;
  line-height: 1;

  user-select: none;
}

/* =========================================================
 * 左侧 Hover
 * ========================================================= */

.module-icon.is-hover {
  background: #f7f7f7;
}

/* =========================================================
 * 左侧 Active
 * ========================================================= */

.module-icon.is-active {
  background: #dfecfd;
}

/* =========================================================
 * Active + Hover
 * ========================================================= */

.module-icon.is-active.is-hover {
  background: #dfecfd;
}

/* =========================================================
 * 右侧面板
 * ========================================================= */

.aside-menu__panel {
  position: absolute;

  top: 4px;
  left: 56px;

  width: 240px;

  display: flex;
  flex-direction: column;

  padding: 4px 0;

  box-sizing: border-box;

  overflow: visible;

  background: #ffffff;

  border-radius: 8px;

  box-shadow:
    0 6px 20px rgb(0 0 0 / 7%),
    0 1px 4px rgb(0 0 0 / 4%);

  z-index: 100;
}

/* =========================================================
 * 右侧模块
 *
 * 关键：
 * 和左侧完全一致：
 *
 * 48px 高度
 * 4px GAP
 * ========================================================= */

.module-label {
  position: relative;

  display: flex;
  align-items: center;

  width: 240px;
  height: 48px;

  flex-shrink: 0;

  /*
   * 和左侧完全一样
   */
  margin-bottom: 4px;

  padding: 0 18px;

  color: #666666;

  font-size: 14px;
  font-weight: 400;

  cursor: pointer;

  background: #ffffff;

  border-radius: 6px;

  box-sizing: border-box;

  transition:
    color 0.16s ease,
    background-color 0.16s ease;
}

/* =========================================================
 * 右侧 Hover
 * ========================================================= */

.module-label.is-hover {
  color: #3f3f3f;
  background: #f7f7f7;
}

/* =========================================================
 * 右侧 Active
 * ========================================================= */

.module-label.is-active {
  color: #31566d;
  background: #dfecfd;
}

/* =========================================================
 * Active + Hover
 * ========================================================= */

.module-label.is-active.is-hover {
  color: #31566d;
  background: #dfecfd;
}

/* =========================================================
 * 右侧文字
 * ========================================================= */

.module-label__text {
  position: relative;

  z-index: 2;

  white-space: nowrap;

  user-select: none;
}

/* =========================================================
 * Hover 箭头
 *
 * CSS 三角形
 *
 * 只有 Hover 才存在
 * ========================================================= */

.module-label__arrow {
  position: absolute;

  left: -7px;
  top: 50%;

  width: 0;
  height: 0;

  border-top: 7px solid transparent;
  border-bottom: 7px solid transparent;

  border-right: 7px solid #f7f7f7;

  transform: translateY(-50%);

  z-index: 3;
}

/* =========================================================
 * Active 箭头
 * ========================================================= */

.module-label__arrow.is-active {
  border-right-color: #dfecfd;
}
</style>
