可以。直接闭环。

但为了**不破坏你现在已经稳定的导航记忆体系**，我建议这次只新增一个 composable，并对 `CustomerTags.vue` 做生命周期接入。

核心规则最终定死：

```text
普通页面
    ↓
自己决定 useKeepAlive()
    ↓
sessionStorage
    ↓
关闭所属 Module Tag
    ↓
模块下所有普通页面 KeepAlive 清除

详情页
    ↓
自动 KeepAlive
    ↓
独立 Detail Tag
    ↓
关闭 Detail Tag
    ↓
只清除自己的 KeepAlive
```

---

# 一、增加 `src/composables/useKeepAlive.ts`

```ts
import { computed, type MaybeRefOrGetter, toValue } from "vue";
import { useStorage } from "@vueuse/core";

/* =========================================================
 * KeepAlive State
 *
 * 业务级页面状态缓存
 *
 * 不使用 Vue <KeepAlive>
 *
 * 存储：
 * sessionStorage
 *
 * Key：
 * keepAlive:${path}
 * ========================================================= */

export type KeepAliveState = Record<string, unknown>;

/* =========================================================
 * Key
 * ========================================================= */

function getStorageKey(path: string) {
  return `keepAlive:${path}`;
}

/* =========================================================
 * 深度复制初始状态
 *
 * 防止不同页面之间引用同一个对象。
 * ========================================================= */

function cloneInitialState<T>(value: T): T {
  if (value === undefined || value === null) {
    return value;
  }

  if (typeof structuredClone === "function") {
    return structuredClone(value);
  }

  return JSON.parse(JSON.stringify(value));
}

/* =========================================================
 * useKeepAlive
 *
 * 页面使用：
 *
 * const { state, clear } = useKeepAlive(
 *   "/document/category",
 *   {
 *     formData: {},
 *     scrollTop: 0,
 *     rules: {},
 *   },
 * );
 *
 * ========================================================= */

export function useKeepAlive<T extends KeepAliveState>(
  path: MaybeRefOrGetter<string>,
  initialState: T,
) {
  const resolvedPath = computed(() => toValue(path));

  /*
   * VueUse useStorage
   *
   * sessionStorage：
   * 页面刷新仍然存在
   * 浏览器会话结束后消失
   */
  const state = useStorage<T>(
    computed(() => getStorageKey(resolvedPath.value)),
    cloneInitialState(initialState),
    sessionStorage,
    {
      deep: true,
    },
  );

  /* =======================================================
   * 是否存在缓存
   * ======================================================= */

  const hasState = computed(() => {
    return Object.keys(state.value ?? {}).length > 0;
  });

  /* =======================================================
   * 清除当前页面
   * ======================================================= */

  function clear() {
    sessionStorage.removeItem(getStorageKey(resolvedPath.value));

    state.value = cloneInitialState(initialState);
  }

  /* =======================================================
   * 返回
   * ======================================================= */

  return {
    state,

    hasState,

    clear,

    key: computed(() => getStorageKey(resolvedPath.value)),
  };
}

/* =========================================================
 * 删除单个页面 KeepAlive
 *
 * useDropKeepAlive("/document/category")
 *
 * ========================================================= */

function dropRouteKeepAlive(path: string) {
  if (!path) {
    return;
  }

  sessionStorage.removeItem(getStorageKey(path));
}

/* =========================================================
 * 删除模块 KeepAlive
 *
 * useDropKeepAlive.module("document")
 *
 * 删除：
 *
 * keepAlive:/document/category
 * keepAlive:/document/template
 *
 * 但不会删除：
 *
 * keepAlive:/document/category/1001
 *
 * 详情页由自己的 Detail Tag 单独管理。
 * ========================================================= */

function dropModuleKeepAlive(module: string) {
  if (!module) {
    return;
  }

  const prefix = `keepAlive:/${module}/`;

  const keys: string[] = [];

  for (let index = 0; index < sessionStorage.length; index++) {
    const key = sessionStorage.key(index);

    if (!key) {
      continue;
    }

    /*
     * 只处理 KeepAlive
     */
    if (!key.startsWith(prefix)) {
      continue;
    }

    const path = key.slice("keepAlive:".length);

    /*
     * 详情页判断：
     *
     * /document/category
     *       只有两个路径段
     *
     * /document/category/1001
     *       三个以上路径段
     *
     * 当前项目详情页通常属于这种形式。
     *
     * 这里暂时不删除详情。
     */
    const segments = path.split("/").filter(Boolean);

    if (segments.length > 2) {
      continue;
    }

    keys.push(key);
  }

  keys.forEach((key) => {
    sessionStorage.removeItem(key);
  });
}

/* =========================================================
 * 删除全部 KeepAlive
 *
 * 预留。
 * ========================================================= */

function dropAllKeepAlive() {
  const keys: string[] = [];

  for (let index = 0; index < sessionStorage.length; index++) {
    const key = sessionStorage.key(index);

    if (key?.startsWith("keepAlive:")) {
      keys.push(key);
    }
  }

  keys.forEach((key) => {
    sessionStorage.removeItem(key);
  });
}

/* =========================================================
 * 统一删除 API
 *
 * useDropKeepAlive.route(path)
 *
 * useDropKeepAlive.module(module)
 *
 * useDropKeepAlive.all()
 * ========================================================= */

export const useDropKeepAlive = {
  route: dropRouteKeepAlive,

  module: dropModuleKeepAlive,

  all: dropAllKeepAlive,
};
```

---

# 二、普通页面怎么用

例如你的：

```text
src/views/document/category/DocumentCategory.vue
```

直接：

```ts
<script setup lang="ts">
import { useKeepAlive } from "@/composables/useKeepAlive";

const { state } = useKeepAlive("/document/category", {
  formData: {
    name: "",
    code: "",
    enabled: true,
  },

  scrollTop: 0,

  currentPage: 1,

  pageSize: 20,

  keyword: "",
});
</script>
```

然后原来：

```ts
const formData = reactive({
  name: "",
  code: "",
});
```

可以改成：

```ts
const formData = state.value.formData;
```

或者如果你喜欢：

```ts
const state = useKeepAlive(...).state;
```

那么：

```ts
state.value.formData
state.value.scrollTop
state.value.currentPage
```

全部都是缓存状态。

---

# 三、这里有一个非常重要的建议

**不要把 Element Plus 的 `rules` 当成必须缓存的数据。**

例如：

```ts
rules
```

实际上属于：

```text
页面静态配置
```

通常直接：

```ts
const rules = {
  name: [...]
};
```

即可。

真正应该缓存的是：

```text
formData
tableData
pagination
searchForm
scrollTop
activeTab
selectedRows
```

也就是：

> **用户操作产生的状态。**

这样 sessionStorage 会干净很多。

---

# 四、CustomerTags.vue 接入

你现在已经有：

```ts
if (tag.type === "module") {
  navigationStore.removeRememberedRoute(tag.key);
}
```

这里直接增加：

```ts
import { useDropKeepAlive } from "@/composables/useKeepAlive";
```

然后：

```ts
if (tag.type === "module") {
  navigationStore.removeRememberedRoute(tag.key);

  useDropKeepAlive.module(tag.key);
}
```

但是详情页：

```ts
else if (tag.type === "detail") {
  useDropKeepAlive.route(tag.path);
}
```

所以最终整个关闭逻辑改成：

```ts
/* =======================================================
 * 清理 KeepAlive
 * ======================================================= */

if (tag.type === "module") {
  /*
   * 删除模块路由记忆
   */
  navigationStore.removeRememberedRoute(tag.key);

  /*
   * 删除该模块下普通页面缓存
   *
   * 详情页面不会在这里删除。
   */
  useDropKeepAlive.module(tag.key);
} else if (tag.type === "detail") {
  /*
   * 详情 Tag 单独管理自己的页面状态
   */
  useDropKeepAlive.route(tag.path);
}
```

这就闭环了。

---

# 五、但是详情页还需要自动 KeepAlive

这里我建议**不要让所有详情页面开发者自己写**：

```ts
useKeepAlive(...)
```

否则以后很容易忘。

你的规则已经确定：

> **有 Detail Tag 的页面天然属于 KeepAlive。**

所以详情页面统一封装一个：

```ts
useDetailKeepAlive()
```

例如：

```ts
import { useRoute } from "vue-router";
import { useKeepAlive } from "@/composables/useKeepAlive";

export function useDetailKeepAlive<T extends Record<string, unknown>>(
  initialState: T,
) {
  const route = useRoute();

  return useKeepAlive(
    () => route.fullPath,
    initialState,
  );
}
```

放在：

```text
src/composables/useDetailKeepAlive.ts
```

详情页：

```ts
const { state } = useDetailKeepAlive({
  formData: {
    name: "",
  },

  scrollTop: 0,

  activeTab: "basic",
});
```

于是：

```text
/document/category/1001
```

自动生成：

```text
keepAlive:/document/category/1001
```

---

# 六、这时候你的详情页生命周期就非常漂亮

例如打开：

```text
详情 1001
```

产生：

```text
CustomerTag
    ↓
key = /document/category/1001
    ↓
useDetailKeepAlive()
    ↓
keepAlive:/document/category/1001
```

然后：

```text
详情 1002
```

产生：

```text
keepAlive:/document/category/1002
```

两个完全独立。

关闭：

```text
详情 1001 ×
```

执行：

```ts
useDropKeepAlive.route("/document/category/1001");
```

只删除：

```text
keepAlive:/document/category/1001
```

不会碰：

```text
keepAlive:/document/category/1002
```

---

# 七、你的 MainContent 不需要动

保持：

```vue
<template>
  <main class="main-content">
    <div class="main-content-inner">
      <router-view />
    </div>
  </main>
</template>
```

**不要加 `<KeepAlive>`。**

这正是我们这套设计的核心。

---

# 八、最终整个系统闭环

现在就是：

```text
                    Router
                      │
                      ▼
                当前 Route
                      │
          ┌───────────┴───────────┐
          │                       │
       普通页面                  详情页面
          │                       │
          ▼                       ▼
  页面自己决定 Hook        自动 useDetailKeepAlive
          │                       │
          └───────────┬───────────┘
                      ▼
                 sessionStorage
                      │
             keepAlive:${path}
                      │
                      ▼
                CustomerTags
                      │
                 ┌────┴────┐
                 │         │
              Module     Detail
                 │         │
                 ▼         ▼
          清理模块缓存   清理单页缓存
                 │         │
                 ▼         ▼
       NavigationMemory   KeepAlive
             同步清除      同步清除
```

这样你现在拥有的是：

**① Navigation Memory**

```text
“这个模块上次停在哪个子路由？”
```

**② KeepAlive Memory**

```text
“这个页面上次的数据是什么？”
```

**③ CustomerTags**

```text
“这个页面/模块是否还存在？”
```

**④ Router**

```text
“当前到底是谁？”
```

四者职责完全分开。

而且最重要的是：

> **Tag 是生命周期的最终控制者。**

Tag 在 → 页面记忆可以存在。

Tag 关 → 对应记忆必须消失。

这就真正形成了你要的**Tag-driven 页面状态系统**。
