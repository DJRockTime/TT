<template>
  <div class="page-container">
    <el-card shadow="never">
      <el-form :model="queryForm" inline>
        <el-form-item label="机构名称">
          <el-input v-model="queryForm.name" placeholder="请输入机构名称" clearable />
        </el-form-item>

        <el-form-item label="机构类型">
          <el-select v-model="queryForm.type" placeholder="请选择" clearable style="width: 140px">
            <el-option label="公司" value="company" />
            <el-option label="部门" value="department" />
            <el-option label="中心" value="center" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary"> 查询 </el-button>
          <el-button @click="handleReset"> 重置 </el-button>
        </el-form-item>
      </el-form>

      <el-divider />

      <div class="toolbar">
        <el-button type="primary" @click="handleAdd"> 新增机构 </el-button>
      </div>

      <el-table :data="tableData" row-key="id" border stripe>
        <el-table-column prop="name" label="机构名称" min-width="180" />

        <el-table-column prop="code" label="机构编码" min-width="160" />

        <el-table-column prop="type" label="机构类型" width="120">
          <template #default="{ row }">
            <el-tag>
              {{ getTypeName(row.type) }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="leader" label="负责人" width="120" />

        <el-table-column prop="phone" label="联系电话" width="160" />

        <el-table-column prop="createdAt" label="创建时间" width="180" />

        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleEdit(row as any)"> 编辑 </el-button>

            <el-button link type="danger"> 删除 </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="机构名称">
          <el-input v-model="form.name" />
        </el-form-item>

        <el-form-item label="机构编码">
          <el-input v-model="form.code" />
        </el-form-item>

        <el-form-item label="机构类型">
          <el-select v-model="form.type" style="width: 100%">
            <el-option label="公司" value="company" />
            <el-option label="部门" value="department" />
            <el-option label="中心" value="center" />
          </el-select>
        </el-form-item>

        <el-form-item label="负责人">
          <el-input v-model="form.leader" />
        </el-form-item>

        <el-form-item label="联系电话">
          <el-input v-model="form.phone" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="dialogVisible = false"> 取消 </el-button>

        <el-button type="primary" @click="handleSave"> 保存 </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from "vue";

interface Department {
  id: number;
  name: string;
  code: string;
  type: "company" | "department" | "center";
  leader: string;
  phone: string;
  createdAt: string;
}

const queryForm = reactive({
  name: "",
  type: "",
});

const tableData = ref<Department[]>([
  {
    id: 1,
    name: "总部",
    code: "HQ",
    type: "company",
    leader: "王总",
    phone: "010-88888888",
    createdAt: "2026-08-18 09:00",
  },
  {
    id: 2,
    name: "技术部",
    code: "TECH",
    type: "department",
    leader: "张经理",
    phone: "010-88888801",
    createdAt: "2026-08-17 10:20",
  },
  {
    id: 3,
    name: "产品中心",
    code: "PRODUCT",
    type: "center",
    leader: "李经理",
    phone: "010-88888802",
    createdAt: "2026-08-16 14:10",
  },
]);

const dialogVisible = ref(false);
const dialogTitle = ref("新增机构");

const form = reactive({
  name: "",
  code: "",
  type: "department",
  leader: "",
  phone: "",
});

function getTypeName(type: Department["type"]) {
  const map = {
    company: "公司",
    department: "部门",
    center: "中心",
  };

  return map[type];
}

function handleReset() {
  queryForm.name = "";
  queryForm.type = "";
}

function handleAdd() {
  dialogTitle.value = "新增机构";

  Object.assign(form, {
    name: "",
    code: "",
    type: "department",
    leader: "",
    phone: "",
  });

  dialogVisible.value = true;
}

function handleEdit(row: Department) {
  dialogTitle.value = "编辑机构";

  Object.assign(form, {
    name: row.name,
    code: row.code,
    type: row.type,
    leader: row.leader,
    phone: row.phone,
  });

  dialogVisible.value = true;
}

function handleSave() {
  dialogVisible.value = false;
}
</script>

<style scoped lang="less">
.page-container {
  padding: 20px;
}

.toolbar {
  margin-bottom: 16px;
}
</style>
