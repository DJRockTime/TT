<template>
  <div class="page-container">
    <el-card shadow="never">
      <!-- 查询 -->
      <el-form :model="queryForm" inline>
        <el-form-item label="岗位名称">
          <el-input v-model="queryForm.name" placeholder="请输入岗位名称" clearable />
        </el-form-item>

        <el-form-item label="岗位状态">
          <el-select
            v-model="queryForm.status"
            placeholder="请选择状态"
            clearable
            style="width: 140px"
          >
            <el-option label="启用" value="enabled" />
            <el-option label="停用" value="disabled" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleSearch"> 查询 </el-button>
          <el-button @click="handleReset"> 重置 </el-button>
        </el-form-item>
      </el-form>

      <el-divider />

      <!-- 工具栏 -->
      <div class="toolbar">
        <el-button type="primary" @click="handleAdd"> 新增岗位 </el-button>

        <el-button type="danger" plain :disabled="selectedRows.length === 0"> 批量删除 </el-button>
      </div>

      <!-- 表格 -->
      <el-table :data="tableData" border stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="50" />

        <el-table-column prop="name" label="岗位名称" min-width="160" />

        <el-table-column prop="code" label="岗位编码" min-width="150" />

        <el-table-column prop="department" label="所属部门" min-width="160" />

        <el-table-column
          prop="description"
          label="岗位描述"
          min-width="240"
          show-overflow-tooltip
        />

        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 'enabled' ? 'success' : 'info'">
              {{ row.status === "enabled" ? "启用" : "停用" }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="createdAt" label="创建时间" width="180" />

        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleEdit(row as any)"> 编辑 </el-button>

            <el-button link type="danger"> 删除 </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="pagination.total"
          background
          layout="total, sizes, prev, pager, next"
        />
      </div>
    </el-card>

    <!-- 新增 / 编辑 -->
    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="岗位名称">
          <el-input v-model="form.name" />
        </el-form-item>

        <el-form-item label="岗位编码">
          <el-input v-model="form.code" />
        </el-form-item>

        <el-form-item label="所属部门">
          <el-select v-model="form.department" placeholder="请选择部门" style="width: 100%">
            <el-option label="技术部" value="技术部" />
            <el-option label="产品部" value="产品部" />
            <el-option label="运营部" value="运营部" />
          </el-select>
        </el-form-item>

        <el-form-item label="岗位描述">
          <el-input
            v-model="form.description"
            type="textarea"
            :rows="3"
            placeholder="请输入岗位描述"
          />
        </el-form-item>

        <el-form-item label="状态">
          <el-switch v-model="form.enabled" active-text="启用" inactive-text="停用" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="dialogVisible = false"> 取消 </el-button>

        <el-button type="primary" @click="handleSave"> 保存 </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import type { AnyColumn } from "element-plus/es/components/table-v2/src/common.mjs";
import { reactive, ref } from "vue";

interface Position {
  id: number;
  name: string;
  code: string;
  department: string;
  description: string;
  status: "enabled" | "disabled";
  createdAt: string;
}

const queryForm = reactive({
  name: "",
  status: "",
});

const tableData = ref<Position[]>([
  {
    id: 1,
    name: "前端工程师",
    code: "FE",
    department: "技术部",
    description: "负责前端应用开发与维护",
    status: "enabled",
    createdAt: "2026-08-18 09:20",
  },
  {
    id: 2,
    name: "后端工程师",
    code: "BE",
    department: "技术部",
    description: "负责后端服务及接口开发",
    status: "enabled",
    createdAt: "2026-08-17 14:30",
  },
  {
    id: 3,
    name: "产品经理",
    code: "PM",
    department: "产品部",
    description: "负责产品规划与需求管理",
    status: "enabled",
    createdAt: "2026-08-16 10:10",
  },
]);

const selectedRows = ref<Position[]>([]);

const pagination = reactive({
  page: 1,
  pageSize: 10,
  total: tableData.value.length,
});

const dialogVisible = ref(false);
const dialogTitle = ref("新增岗位");

const form = reactive({
  name: "",
  code: "",
  department: "",
  description: "",
  enabled: true,
});

function handleSearch() {
  console.log("查询岗位", queryForm);
}

function handleReset() {
  queryForm.name = "";
  queryForm.status = "";
}

function handleSelectionChange(rows: Position[]) {
  selectedRows.value = rows;
}

function handleAdd() {
  dialogTitle.value = "新增岗位";

  Object.assign(form, {
    name: "",
    code: "",
    department: "",
    description: "",
    enabled: true,
  });

  dialogVisible.value = true;
}

function handleEdit(row: Position) {
  dialogTitle.value = "编辑岗位";

  Object.assign(form, {
    name: row.name,
    code: row.code,
    department: row.department,
    description: row.description,
    enabled: row.status === "enabled",
  });

  dialogVisible.value = true;
}

function handleSave() {
  dialogVisible.value = false;
}
</script>

<style scoped lang="less">
.page-container {
  padding: 20px;
}

.toolbar {
  margin-bottom: 16px;
}

.pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}
</style>
