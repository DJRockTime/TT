import js from "@eslint/js";
import tseslint from "typescript-eslint";
import vue from "eslint-plugin-vue";
import prettier from "eslint-config-prettier";

export default tseslint.config(
  {
    ignores: ["dist", "node_modules", ".vite"],
  },

  js.configs.recommended,

  ...tseslint.configs.recommended,
  ...vue.configs["flat/essential"],

  prettier,
);
