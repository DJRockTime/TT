import { openDB } from 'idb';

export interface WorkItem {
  id: number;

  content: string;

  time: number;
}

const DB = 'work-db';

const STORE = 'work';

async function getDB() {
  return openDB(
    DB,

    1,

    {
      upgrade(db) {
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(
            STORE,

            {
              keyPath: 'id',
            }
          );
        }
      },
    }
  );
}

export async function addWork(content: string) {
  const db = await getDB();

  await db.put(
    STORE,

    {
      id: Date.now(),

      content,

      time: Date.now(),
    }
  );
}

export async function getWorks() {
  const db = await getDB();

  return await db.getAll(STORE);
}

export async function clearWorks() {
  const db = await getDB();

  await db.clear(STORE);
}
