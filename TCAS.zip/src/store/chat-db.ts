import { openDB } from "idb";

export interface Message {
    role: "user" | "assistant";

    content: string;
}

const DB_NAME = "smart-agent";

const STORE = "chat";

async function getDB() {
    return openDB(
        DB_NAME,

        1,

        {
            upgrade(db) {
                if (!db.objectStoreNames.contains(STORE)) {
                    db.createObjectStore(STORE);
                }
            },
        },
    );
}

export async function saveMessages(list: Message[]) {
    const db = await getDB();

    await db.put(
        STORE,

        JSON.parse(JSON.stringify(list)),

        "history",
    );
}

export async function loadMessages() {
    const db = await getDB();

    return (
        (await db.get(
            STORE,

            "history",
        )) || []
    );
}

export async function clearMessages() {
    const db = await getDB();

    await db.delete(
        STORE,

        "history",
    );
}
