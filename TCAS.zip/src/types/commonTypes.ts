export type NavigationMode = 'link' | 'dropdown' | 'mega' | 'external';

export interface NavigationItem {
  /**
   * 唯一ID
   */
  id: string;

  /**
   * 显示名称
   */
  title: string;

  /**
   * 导航模式
   */
  mode: NavigationMode;

  /**
   * 跳转路由
   */
  path?: string;

  /**
   * 外链
   */
  href?: string;

  /**
   * 子菜单
   */
  children?: NavigationItem[];
}

import type { Component } from 'vue';

export interface TreeMenuData {
  /**
   * 唯一ID
   */
  id: string;

  /**
   * 标题
   */
  label: string;

  /**
   * Router Path
   */
  path?: string;

  /**
   * Router Name
   */
  name?: string;

  /**
   * 图标
   */
  icon?: Component;

  /**
   * 禁用
   */
  disabled?: boolean;

  /**
   * 隐藏
   */
  hidden?: boolean;

  /**
   * 是否允许点击
   * false：仅展开
   */
  clickable?: boolean;

  /**
   * 默认展开
   */
  expanded?: boolean;

  /**
   * 子节点
   */
  children?: TreeMenuData[];

  /**
   * 扩展信息
   */
  meta?: Record<string, any>;

  /* --------------------- */
  /* 以下字段组件初始化自动维护 */
  /* --------------------- */

  /**
   * 父节点
   */
  parent?: TreeMenuData;

  /**
   * 层级
   */
  level?: number;
}
