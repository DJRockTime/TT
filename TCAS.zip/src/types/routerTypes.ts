import 'vue-router';

export interface AppRouteMeta {
  /**
   * 页面标题
   */
  title: string;

  /**
   * 图标
   */
  icon?: string;

  /**
   * 是否缓存
   */
  keepAlive?: boolean;

  /**
   * 是否显示左侧菜单
   */
  left?: boolean;

  /**
   * 是否显示右侧栏
   */
  right?: boolean;

  /**
   * 左侧宽度
   */
  leftWidth?: number;

  /**
   * 右侧宽度
   */
  rightWidth?: number;

  /**
   * 是否显示Breadcrumb
   */
  breadcrumb?: boolean;

  /**
   * 是否显示Tabs
   */
  tabs?: boolean;

  /**
   * 是否隐藏菜单
   */
  hidden?: boolean;

  /**
   * 排序
   */
  order?: number;
}

declare module 'vue-router' {
  interface RouteMeta extends AppRouteMeta {}
}
