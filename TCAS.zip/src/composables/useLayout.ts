import { computed } from 'vue';
import { useRoute } from 'vue-router';

export function useLayout() {
  const route = useRoute();
  const showLeft = computed(() => !!route.meta.left);
  const showRight = computed(() => !!route.meta.right);
  const leftWidth = computed(() => Number(route.meta.leftWidth ?? 260));
  const rightWidth = computed(() => Number(route.meta.rightWidth ?? 320));

  return {
    showLeft,
    showRight,
    leftWidth,
    rightWidth,
  };
}
