<script setup ts>
  import { useRouter } from 'vue-router';

  const router = useRouter();

  const goHome = () => {
    router.push('/');
  };
</script>

<template>
  <div class="error-container">
    <div class="content-box">
      <!-- Minimalist Icon Representation -->
      <div class="icon-wrapper">
        <div class="circle"></div>
        <div class="line"></div>
      </div>

      <h1 class="code">404</h1>
      <p class="message">Page not found</p>
      <p class="description">The page you are looking for doesn't exist or has been moved.</p>

      <button class="back-btn" @click="goHome">Back to Home</button>
    </div>
  </div>
</template>

<style scoped>
  .error-container {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 80vh;
    padding: 20px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    color: #2c3e50;
    background-color: #ffffff;
  }

  .content-box {
    text-align: center;
    max-width: 400px;
    width: 100%;
  }

  .icon-wrapper {
    display: inline-block;
    position: relative;
    width: 64px;
    height: 64px;
    margin-bottom: 24px;
  }

  .circle {
    width: 100%;
    height: 100%;
    border: 3px solid #e2e8f0;
    border-radius: 50%;
    box-sizing: border-box;
  }

  .line {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 32px;
    height: 3px;
    background-color: #94a3b8;
    transform: translate(-50%, -50%) rotate(45deg);
  }

  .code {
    font-size: 72px;
    font-weight: 800;
    line-height: 1;
    margin: 0 0 8px 0;
    letter-spacing: -0.05em;
    color: #0f172a;
  }

  .message {
    font-size: 20px;
    font-weight: 500;
    margin: 0 0 12px 0;
    color: #334155;
  }

  .description {
    font-size: 14px;
    line-height: 1.5;
    margin: 0 0 32px 0;
    color: #64748b;
  }

  .back-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 40px;
    padding: 0 24px;
    font-size: 14px;
    font-weight: 500;
    color: #ffffff;
    background-color: #0f172a;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition:
      background-color 0.2s ease,
      transform 0.1s ease;
  }

  .back-btn:hover {
    background-color: #1e293b;
  }

  .back-btn:active {
    transform: scale(0.98);
  }
</style>
