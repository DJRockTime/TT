<template>
  <aside class="right-aside">Right Aside</aside>
</template>

<script setup lang="ts"></script>

<style scoped>
  .right-aside {
    width: 320px;
    border-left: 1px solid #ebeef5;
    overflow: auto;
    flex-shrink: 0;
  }
</style>
