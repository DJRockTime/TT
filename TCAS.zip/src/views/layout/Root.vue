<template>
  <div class="root-layout">
    <Navigation />

    <section class="main-container">
      <router-view />
    </section>
  </div>
</template>

<script setup lang="ts">
  import Navigation from '@/views/layout/Navigation.vue';
</script>

<style scoped lang="less">
  .root-layout {
    display: flex;
    flex-direction: column;

    width: 100%;
    height: 100%;

    overflow: hidden;
  }

  /* 剩余高度全部给页面 */

  .main-container {
    flex: 1;

    min-height: 0;

    overflow: hidden;
  }
</style>
