<template>
  <section
    class="main-layout"
    :style="{
      gap: `${gap}px`,
      padding: `${padding}px`,
    }"
  >
    <!-- Left -->
    <aside v-if="showLeft" class="main-layout__left" :style="{ width: `${leftWidth}px` }">
      <slot name="left" />
    </aside>

    <!-- Center -->
    <main class="main-layout__center">
      <slot name="center" />
    </main>

    <!-- Right -->
    <aside v-if="showRight" class="main-layout__right" :style="{ width: `${rightWidth}px` }">
      <slot name="right" />
    </aside>
  </section>
</template>

<script setup lang="ts">
  interface Props {
    /**
     * 是否显示左侧
     */
    showLeft?: boolean;

    /**
     * 是否显示右侧
     */
    showRight?: boolean;

    /**
     * 左侧宽度
     */
    leftWidth?: number;

    /**
     * 右侧宽度
     */
    rightWidth?: number;

    /**
     * Layout 间距
     */
    gap?: number;

    /**
     * 内边距
     */
    padding?: number;
  }

  withDefaults(defineProps<Props>(), {
    showLeft: false,
    showRight: false,

    leftWidth: 240,
    rightWidth: 300,

    gap: 0,
    padding: 0,
  });
</script>

<style scoped lang="less">
  .main-layout {
    display: flex;

    width: 100%;
    height: 100%;

    overflow: hidden;

    box-sizing: border-box;

    background: #f5f7fa;
  }

  .main-layout__left,
  .main-layout__center,
  .main-layout__right {
    height: 100%;

    min-height: 0;

    overflow: auto;
  }

  /* 左侧 */

  .main-layout__left {
    flex-shrink: 0;

    border-right: 1px solid #ebeef5;

    background: #fff;
  }

  /* 中间 */

  .main-layout__center {
    flex: 1;

    min-width: 0;

    background: #fff;
  }

  /* 右侧 */

  .main-layout__right {
    flex-shrink: 0;

    border-left: 1px solid #ebeef5;

    background: #fff;
  }
</style>
