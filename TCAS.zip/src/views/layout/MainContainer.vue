<template>
  <main class="main-container">
    <LeftAside v-if="route.meta.left" />
    <Center />
    <RightAside v-if="route.meta.right" />
  </main>
</template>

<script setup lang="ts">
  import { useRoute } from 'vue-router';

  import LeftAside from '@/views/layout/LeftAside.vue';
  import Center from '@/views/layout/Center.vue';
  import RightAside from '@/views/layout/RightAside.vue';

  const route = useRoute();
</script>

<style scoped>
  .main-container {
    display: flex;
    flex: 1;
    min-height: 0;
    overflow: hidden;
  }
</style>
