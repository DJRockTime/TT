<template>
  <section class="center">
    <RouterView />
  </section>
</template>

<script setup lang="ts"></script>

<style scoped>
  .center {
    flex: 1;

    overflow: auto;
  }
</style>
