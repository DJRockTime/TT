<template>
  <header class="navigation">
    <!-- logo -->
    <div class="logo">LOGO</div>

    <!-- menu -->
    <div class="menu" ref="menuRef">
      <NavigationItem
        v-for="item in navigation"
        :key="item.id"
        :item="item"
        @active="moveIndicator"
      />

      <div class="indicator" :style="indicatorStyle" />
    </div>

    <!-- actions -->
    <div class="actions">
      <div class="action-item">🥝</div>

      <div class="action-item">🍃</div>

      <div class="action-item">🍋</div>

      <div class="action-item">🍈</div>
    </div>
  </header>
</template>

<script setup lang="ts">
  import { navigation } from '@/router/navigation';
  import NavigationItem from './NavigationItem.vue';

  import { ref, reactive, nextTick, onMounted } from 'vue';
  import { useRoute } from 'vue-router';

  const menuRef = ref<HTMLElement | null>(null);

  const indicatorStyle = reactive({
    width: '0px',

    transform: 'translateX(0px)',
  });

  function moveIndicator(el: HTMLElement) {
    const {
      offsetLeft,

      offsetWidth,
    } = el;

    indicatorStyle.width = `${offsetWidth}px`;

    indicatorStyle.transform = `translateX(${offsetLeft}px)`;
  }

  onMounted(() => {
    nextTick(() => {
      const activeItem = menuRef.value?.querySelector('.active') as HTMLElement;

      if (activeItem) {
        moveIndicator(activeItem);
      }
    });
  });
</script>

<style scoped lang="less">
  .navigation {
    width: 100%;
    height: 48px;
    display: flex;
    align-items: center;
    background: #111827;
    color: #ffffff;
    padding: 0 24px;
    box-sizing: border-box;
    flex-shrink: 0;
  }

  /**
 * Logo区域
 */
  .logo {
    width: 180px;

    flex-shrink: 0;

    font-size: 22px;

    font-weight: 600;

    letter-spacing: 1px;
  }

  /**
 * 中间菜单
 */
  .menu {
    flex: 1;

    height: 100%;

    display: flex;

    align-items: center;
  }

  /**
 * 右侧操作区域
 */
  .actions {
    display: flex;

    align-items: center;

    gap: 20px;

    height: 100%;
  }

  .action-item {
    width: 36px;

    height: 36px;

    display: flex;

    align-items: center;

    justify-content: center;

    cursor: pointer;

    border-radius: 8px;

    font-size: 20px;

    transition: background 0.25s ease;

    &:hover {
      background: rgba(255, 255, 255, 0.1);
    }
  }

  .menu {
    position: relative;

    height: 48px;

    display: flex;

    align-items: center;
  }

  .indicator {
    position: absolute;

    bottom: 0;

    left: 0;

    height: 3px;

    background: #409eff;

    border-radius: 3px;

    transition:
      transform 0.3s ease,
      width 0.3s ease;
  }
</style>
