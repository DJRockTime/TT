<template>
  <div
    ref="itemRef"
    class="navigation-item"
    :class="{
      active: isActive,
    }"
    @click="handleClick"
    @mouseenter="hover = true"
    @mouseleave="hover = false"
  >
    <span class="title">
      {{ item.title }}
    </span>

    <!-- dropdown -->
    <NavigationDropdown v-if="item.mode === 'dropdown' && hover" :items="item.children" />

    <!-- mega menu -->
    <NavigationMega v-if="item.mode === 'mega' && hover" :items="item.children" />
  </div>
</template>

<script setup lang="ts">
  import { ref, computed } from 'vue';

  import { useRoute, useRouter } from 'vue-router';
  import type { NavigationItem } from '@/router/types';
  import NavigationDropdown from './NavigationDropdown.vue';
  import NavigationMega from './NavigationMega.vue';

  const props = defineProps<{
    item: NavigationItem;
  }>();

  const route = useRoute();

  const isActive = computed(() => {
    if (!props.item.path) {
      return false;
    }

    console.log(route.path);
    console.log(route.path === props.item.path);

    return route.path === props.item.path;
  });

  const hover = ref(false);

  const router = useRouter();

  const emit = defineEmits<{
    active: [el: HTMLElement];
  }>();

  const itemRef = ref<HTMLElement>();

  function active() {
    emit('active', itemRef.value!);
  }

  function handleClick() {
    active();

    if (props.item.mode === 'link') {
      router.push(props.item.path!);
    }

    if (props.item.mode === 'external') {
      window.open(props.item.href, '_blank');
    }
  }
</script>

<style scoped lang="less">
  .navigation-item {
    position: relative;

    height: 64px;

    padding: 0 22px;

    display: flex;

    align-items: center;

    justify-content: center;

    color: #d1d5db;

    font-size: 15px;

    margin-right: 10px;

    cursor: pointer;

    transition: all 0.25s ease;

    white-space: nowrap;

    &:hover {
      color: #ffffff;

      background: rgba(255, 255, 255, 0.08);
    }
  }

  .title {
    line-height: 1;
  }
</style>
