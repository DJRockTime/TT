<template>
  <aside class="left-aside">Left Aside</aside>
</template>

<script setup lang="ts"></script>

<style scoped>
  .left-aside {
    width: 260px;

    border-right: 1px solid #ebeef5;

    overflow: auto;

    flex-shrink: 0;
  }
</style>
