<template>
  <div class="mega">
    <div v-for="item in items" :key="item.id" class="mega-item" @click.stop="handleClick(item)">
      <div class="mega-title">
        {{ item.title }}
      </div>

      <div class="mega-desc">
        {{ item.description ?? '快速访问功能' }}
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { useRouter } from 'vue-router';

  import type { NavigationItem } from '@/router/types';

  defineProps<{
    items?: NavigationItem[];
  }>();

  const router = useRouter();

  function handleClick(item: NavigationItem) {
    if (item.path) {
      router.push(item.path);
    }
  }
</script>

<style scoped lang="less">
  .mega {
    position: absolute;

    top: 58px;

    left: 50%;

    transform: translateX(-50%);

    width: 620px;

    min-height: 160px;

    padding: 24px;

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 16px;

    background: #ffffff;

    border-radius: 12px;

    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.18);

    animation: megaShow 0.2s ease;
  }

  .mega-item {
    padding: 16px;

    border-radius: 8px;

    cursor: pointer;

    transition: 0.2s;

    &:hover {
      background: #f3f4f6;
    }
  }

  .mega-title {
    font-size: 15px;

    font-weight: 600;

    color: #111827;

    margin-bottom: 8px;
  }

  .mega-desc {
    font-size: 13px;

    color: #6b7280;
  }

  @keyframes megaShow {
    from {
      opacity: 0;

      transform: translate(-50%, -15px);
    }

    to {
      opacity: 1;

      transform: translate(-50%, 0);
    }
  }
</style>
