<template>
  <div class="dropdown">
    <div v-for="item in items" :key="item.id" class="dropdown-item" @click.stop="handleClick(item)">
      {{ item.title }}
    </div>
  </div>
</template>

<script setup lang="ts">
  import { useRouter } from 'vue-router';

  import type { NavigationItem } from '@/router/types';

  defineProps<{
    items?: NavigationItem[];
  }>();

  const router = useRouter();

  function handleClick(item: NavigationItem) {
    if (item.path) {
      router.push(item.path);
    }
  }
</script>

<style scoped lang="less">
  .dropdown {
    position: absolute;

    top: 58px;

    left: 50%;

    transform: translateX(-50%);

    width: 180px;

    padding: 8px;

    background: #ffffff;

    border-radius: 8px;

    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);

    animation: dropdownShow 0.2s ease;
  }

  .dropdown-item {
    height: 40px;

    display: flex;

    align-items: center;

    padding: 0 16px;

    color: #374151;

    border-radius: 6px;

    cursor: pointer;

    transition: 0.2s;

    &:hover {
      background: #f3f4f6;

      color: #2563eb;
    }
  }

  @keyframes dropdownShow {
    from {
      opacity: 0;

      transform: translate(-50%, -10px);
    }

    to {
      opacity: 1;

      transform: translate(-50%, 0);
    }
  }
</style>
