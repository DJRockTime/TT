<template>
  <div class="page">
    <div class="header">
      <div class="title">工作助手</div>
      <div class="tabs">
        <el-button plain>今日记录</el-button>
        <el-button plain>周报</el-button>
        <el-button plain>工作问答</el-button>
        <el-button danger @click="clear">清空记录</el-button>
      </div>
    </div>
    <div ref="chatRef" class="chat">
      <div v-for="(msg, index) in messages" :key="index" class="msg" :class="msg.role">
        <div class="content">
          {{ msg.content }}
        </div>
      </div>
    </div>

    <div class="footer">
      <el-input
        v-model="input"
        type="textarea"
        :rows="3"
        resize="none"
        placeholder="输入工作内容..."
        @keyup.enter="send"
      />

      <el-button type="primary" @click="send">发送</el-button>
      <el-button @click="stop">停止</el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { nextTick, ref, onMounted } from 'vue';
  import { streamChat } from '@/api/chat';
  import { loadMessages, saveMessages, clearMessages } from '@/store/chat-db';

  interface Message {
    role: 'user' | 'assistant';

    content: string;
  }

  let controller: AbortController | null = null;

  controller = new AbortController();

  const input = ref('');

  const loading = ref(false);

  const messages = ref<Message[]>([]);

  const chatRef = ref<HTMLElement>();

  async function scrollBottom() {
    await nextTick();

    chatRef.value?.scrollTo({
      top: chatRef.value.scrollHeight,

      behavior: 'smooth',
    });
  }

  async function clear() {
    messages.value = [];

    await clearMessages();
  }

  async function send() {
    if (!input.value || loading.value) {
      return;
    }

    loading.value = true;

    const text = input.value;

    input.value = '';

    messages.value.push({
      role: 'user',
      content: text,
    });
    await saveMessages(messages.value);

    messages.value.push({
      role: 'assistant',

      content: '',
    });
    await saveMessages(messages.value);

    scrollBottom();

    const index = messages.value.length - 1;

    await streamChat(
      text,

      (chunk) => {
        messages.value[index].content += chunk;

        scrollBottom();
      },

      controller.signal
    );

    // 输出结束后保存一次
    await saveMessages(messages.value);

    loading.value = false;
  }

  function stop() {
    controller?.abort();

    loading.value = false;
  }

  onMounted(async () => {
    messages.value = await loadMessages();
  });
</script>

<style scoped>
  .page {
    height: 100vh;

    display: flex;

    flex-direction: column;

    padding: 20px;

    box-sizing: border-box;

    background: #f6f8fa;
  }

  .header {
    margin-bottom: 20px;
  }

  .title {
    font-size: 28px;

    font-weight: 700;

    margin-bottom: 12px;
  }

  .tabs {
    display: flex;

    gap: 10px;
  }

  .chat {
    flex: 1;

    overflow: auto;

    background: white;

    border-radius: 12px;

    padding: 20px;
  }

  .msg {
    display: flex;

    margin-bottom: 16px;
  }

  .user {
    justify-content: flex-end;
  }

  .assistant {
    justify-content: flex-start;
  }

  .content {
    max-width: 70%;

    padding: 12px;

    border-radius: 10px;

    background: #eaf2ff;
  }

  .user .content {
    background: #409eff;

    color: white;
  }

  .footer {
    display: flex;

    gap: 10px;

    margin-top: 20px;
  }

  .footer .el-input {
    flex: 1;
  }
</style>
