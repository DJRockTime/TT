<template>
  <MainLayout :show-left="true" :show-right="true" :left-width="240" :right-width="300">
    <!-- 左侧 -->
    <template #left>
      <div class="left-panel">
        <!-- <h3>📂 产品菜单</h3>

        <div class="menu-item active">产品首页</div>
        <div class="menu-item">产品列表</div>
        <div class="menu-item">产品分类</div>
        <div class="menu-item">产品标签</div>
        <div class="menu-item">产品设置</div> -->
        <MenuTree
          :menu-data="menuRoutes"
          :default-expanded="['/system', '/content']"
          :clickable-levels="[-1]"
          :navigable-levels="[0, 1]"
          @node-click="handleClick"
        />
      </div>
    </template>

    <!-- 中间 -->
    <template #center>
      <div class="content-panel">
        <div class="page-header">
          <h2>产品中心（Product Center）</h2>

          <div class="actions">
            <button>新增产品</button>
            <button>导入</button>
            <button>导出</button>
          </div>
        </div>

        <div class="card">
          <h3>欢迎来到产品中心 👋</h3>

          <p>
            这里以后就是 router-view， ProductList、ProductDetail、ProductSetting 都会在这里切换。
          </p>
        </div>

        <div class="card table-demo">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>产品名称</th>
                <th>状态</th>
                <th>更新时间</th>
              </tr>
            </thead>

            <tbody>
              <tr>
                <td>1001</td>
                <td>Portal Framework</td>
                <td>运行中</td>
                <td>2026-07-13</td>
              </tr>

              <tr>
                <td>1002</td>
                <td>AI Agent</td>
                <td>开发中</td>
                <td>2026-07-13</td>
              </tr>

              <tr>
                <td>1003</td>
                <td>MenuTree</td>
                <td>待开发</td>
                <td>2026-07-13</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </template>

    <!-- 右侧 -->
    <template #right>
      <div class="right-panel">
        <div class="notice-card">
          <h3>📢 产品公告</h3>

          <ul>
            <li>产品模块已完成 Layout。</li>
            <li>下一步开始开发 MenuTree。</li>
            <li>Router 将作为唯一数据源。</li>
          </ul>
        </div>

        <div class="notice-card">
          <h3>📊 数据统计</h3>

          <p>产品数量：128</p>

          <p>在线产品：126</p>

          <p>待审核：2</p>
        </div>
      </div>
    </template>
  </MainLayout>
</template>

<script setup lang="ts">
  import MainLayout from '@/views/layout/MainLayout.vue';
  import MenuTree from '@/views/TreeMenu/MenuTree.vue';
  // 示例 routes.ts（三层结构）
  import type { MenuItem } from '@/views/TreeMenu/MenuTree.vue'; // 引入你定义的类型

  const handleClick = () => {
    console.log('rock');
  };

  const menuRoutes: MenuItem[] = [
    {
      path: '/dashboard',
      name: 'Dashboard',
      meta: {
        label: '仪表盘',
        icon: 'i-mdi-view-dashboard', // 示例 icon（可换成你项目使用的图标库）
      },
    },
    {
      path: '/system',
      name: 'System',
      meta: {
        label: '系统管理',
        icon: 'i-mdi-cog',
      },
      children: [
        {
          path: '/system/users',
          name: 'UserManagement',
          meta: {
            label: '用户管理',
            icon: 'i-mdi-account-multiple',
          },
          children: [
            {
              path: '/system/users/list',
              name: 'UserList',
              meta: {
                label: '用户列表',
                icon: 'i-mdi-format-list-bulleted',
              },
            },
            {
              path: '/system/users/create',
              name: 'UserCreate',
              meta: {
                label: '新增用户',
                icon: 'i-mdi-account-plus',
              },
            },
          ],
        },
        {
          path: '/system/roles',
          name: 'RoleManagement',
          meta: {
            label: '角色管理',
            icon: 'i-mdi-shield-account',
            disabled: false, // 可以单独禁用某一项
          },
        },
      ],
    },
    {
      path: '/content',
      name: 'Content',
      meta: {
        label: '内容管理',
        icon: 'i-mdi-file-document',
      },
      children: [
        {
          path: '/content/articles',
          name: 'ArticleManagement',
          meta: {
            label: '文章管理',
            icon: 'i-mdi-newspaper',
          },
          children: [
            {
              path: '/content/articles/list',
              name: 'ArticleList',
              meta: {
                label: '文章列表',
              },
            },
            {
              path: '/content/articles/category',
              name: 'ArticleCategory',
              meta: {
                label: '分类管理',
                disabled: true, // 示例：禁用某一层级
              },
            },
          ],
        },
        {
          path: '/content/comments',
          name: 'CommentManagement',
          meta: {
            label: '评论管理',
            icon: 'i-mdi-comment-text',
          },
        },
      ],
    },
    {
      path: '/statistics',
      name: 'Statistics',
      meta: {
        label: '数据统计',
        icon: 'i-mdi-chart-bar',
      },
      // 第三层示例（更深层）
      children: [
        {
          path: '/statistics/overview',
          name: 'StatOverview',
          meta: {
            label: '概览统计',
          },
        },
        {
          path: '/statistics/detail',
          name: 'StatDetail',
          meta: {
            label: '详细报表',
          },
          children: [
            {
              path: '/statistics/detail/sales',
              name: 'SalesReport',
              meta: {
                label: '销售报表',
              },
            },
            {
              path: '/statistics/detail/users',
              name: 'UserReport',
              meta: {
                label: '用户行为',
              },
            },
          ],
        },
      ],
    },
  ];
</script>

<style scoped lang="less">
  .left-panel {
    height: 100%;
    padding: 16px;
    box-sizing: border-box;
    background: #fff;
  }

  .left-panel h3 {
    margin-bottom: 20px;
  }

  .menu-item {
    padding: 10px 14px;
    margin-bottom: 8px;
    border-radius: 6px;
    cursor: pointer;
    transition: 0.2s;
  }

  .menu-item:hover {
    background: #f5f7fa;
  }

  .menu-item.active {
    color: #409eff;
    background: #ecf5ff;
  }

  .content-panel {
    height: 100%;
    padding: 20px;
    overflow: auto;
    box-sizing: border-box;
    background: #f5f7fa;
  }

  .page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;

    margin-bottom: 20px;
  }

  .actions button {
    margin-left: 10px;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    background: #409eff;
    color: #fff;
    cursor: pointer;
  }

  .card {
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 8px;
    background: #fff;
  }

  .table-demo table {
    width: 100%;
    border-collapse: collapse;
  }

  .table-demo th,
  .table-demo td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ebeef5;
  }

  .right-panel {
    height: 100%;
    padding: 16px;
    box-sizing: border-box;
    background: #fff;
  }

  .notice-card {
    padding: 16px;
    margin-bottom: 16px;
    border-radius: 8px;
    background: #f8f8f8;
  }

  .notice-card h3 {
    margin-bottom: 12px;
  }

  .notice-card ul {
    padding-left: 18px;
  }

  .notice-card li {
    margin-bottom: 8px;
  }
</style>
