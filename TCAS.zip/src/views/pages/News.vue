<template>
  <div class="page">Home Page</div>
</template>

<script setup lang="ts"></script>

<style scoped>
  .page {
    padding: 40px;
  }
</style>
