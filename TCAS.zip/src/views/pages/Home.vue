<template>
  <MainLayout
    :show-left="Boolean(route.meta.showLeft)"
    :show-right="Boolean(route.meta.showRight)"
    :right-width="320"
  >
    <!-- 中间 -->
    <template #center>
      <div class="home-content">
        <div class="card">
          <h2>Welcome Home 👋</h2>

          <p>这里是首页内容区域，以后可以放 Banner、统计信息、快捷入口等。</p>
        </div>

        <div class="card">
          <h3>Quick Access</h3>

          <div class="grid">
            <div class="grid-item">产品中心</div>
            <div class="grid-item">消息中心</div>
            <div class="grid-item">新闻资讯</div>
            <div class="grid-item">帮助中心</div>
          </div>
        </div>
      </div>
    </template>

    <!-- 右侧 -->
    <template #right>
      <div class="news-panel">
        <h3>📢 最新公告</h3>

        <ul>
          <li>Portal Framework 正在开发中</li>
          <li>Vue3 + TS + Vite</li>
          <li>MainLayout 已完成第一版</li>
          <li>下一步开发 LeftAside</li>
        </ul>
      </div>
    </template>
  </MainLayout>
</template>

<script setup lang="ts">
  import { useRoute } from 'vue-router';

  import MainLayout from '@/views/layout/MainLayout.vue';

  const route = useRoute();
</script>

<style scoped lang="less">
  .home-content {
    height: 100%;

    padding: 20px;

    overflow: auto;

    background: #f5f7fa;
  }

  .card {
    margin-bottom: 20px;

    padding: 20px;

    background: #fff;

    border-radius: 8px;

    box-shadow: 0 2px 8px rgb(0 0 0 / 5%);
  }

  .grid {
    display: grid;

    grid-template-columns: repeat(2, 1fr);

    gap: 16px;

    margin-top: 16px;
  }

  .grid-item {
    display: flex;

    justify-content: center;

    align-items: center;

    height: 100px;

    border-radius: 8px;

    background: #409eff;

    color: #fff;

    cursor: pointer;

    transition: 0.2s;
  }

  .grid-item:hover {
    transform: translateY(-2px);
  }

  .news-panel {
    height: 100%;

    padding: 20px;

    overflow: auto;

    border-left: 1px solid #ebeef5;

    background: #fff;
  }

  .news-panel ul {
    margin: 0;
    padding-left: 18px;
  }

  .news-panel li {
    margin-bottom: 12px;

    line-height: 24px;

    cursor: pointer;
  }
</style>
