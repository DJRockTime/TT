<template>
  <MainLayout>
    <template #left>
      <MenuTree />
    </template>

    <router-view />

    <template #right>
      <NoticePanel />
    </template>
  </MainLayout>
  <div class="page">Home Page</div>
</template>

<script setup lang="ts"></script>

<style scoped>
  .page {
    padding: 40px;
  }
</style>
