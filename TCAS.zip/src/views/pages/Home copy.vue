<script setup lang="ts">
  import { ref } from 'vue';
  import { Icon } from '@iconify/vue';
  import { ElMessage } from 'element-plus';

  // Sidebar collapse state
  const isCollapse = ref(false);

  // Dummy user profile data
  const user = ref({
    username: 'Alex Developer',
    role: 'Administrator',
    avatar: 'https://unsplash.com',
  });

  // Quick stats card data
  const stats = ref([
    { title: 'Total Visits', value: '12,480', icon: 'solar:graph-up-bold', color: '#409EFF' },
    {
      title: 'Active Projects',
      value: '32',
      icon: 'solar:folder-with-files-bold',
      color: '#67C23A',
    },
    { title: 'Pending Tasks', value: '7', icon: 'solar:clipboard-list-bold', color: '#E6A23C' },
  ]);

  // Mock list items
  const recentActivities = ref([
    { id: 1, text: 'Deployed Version 1.2.0 to staging', time: '10 mins ago', type: 'success' },
    { id: 2, text: 'Database optimization completed', time: '1 hour ago', type: 'info' },
    { id: 3, text: 'Fixed navigation guard bug in router', time: '3 hours ago', type: 'warning' },
  ]);

  const handleAction = (actionName: string) => {
    ElMessage({
      message: `Action executed: ${actionName}`,
      type: 'success',
    });
  };
</script>

<template>
  <el-container class="layout-container">
    <!-- Sidebar Menu -->
    <el-aside :width="isCollapse ? '64px' : '240px'" class="aside-menu">
      <div class="logo-wrapper">
        <Icon icon="solar:widget-bold" class="logo-icon" />
        <span v-show="!isCollapse" class="logo-text">CoreAdmin</span>
      </div>

      <el-menu
        default-active="1"
        :collapse="isCollapse"
        background-color="#0f172a"
        text-color="#94a3b8"
        active-text-color="#ffffff"
        class="el-menu-vertical"
      >
        <el-menu-item index="1">
          <Icon icon="solar:home-smile-angle-bold" class="menu-icon" />
          <template #title>Dashboard</template>
        </el-menu-item>
        <el-menu-item index="2">
          <Icon icon="solar:users-group-two-rounded-bold" class="menu-icon" />
          <template #title>Team Members</template>
        </el-menu-item>
        <el-menu-item index="3">
          <Icon icon="solar:settings-bold" class="menu-icon" />
          <template #title>Settings</template>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <!-- Main Container -->
    <el-container>
      <!-- Navbar / Header -->
      <el-header class="navbar-header">
        <div class="header-left">
          <button class="collapse-toggle" @click="isCollapse = !isCollapse">
            <Icon
              :icon="isCollapse ? 'solar:hamburger-menu-linear' : 'solar:menu-to-the-left-linear'"
            />
          </button>
          <span class="page-title">Workspace Dashboard</span>
        </div>

        <div class="header-right">
          <el-dropdown trigger="click">
            <div class="profile-trigger">
              <img :src="user.avatar" alt="Avatar" class="avatar-img" />
              <div class="user-meta">
                <span class="user-name">{{ user.username }}</span>
                <span class="user-role">{{ user.role }}</span>
              </div>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="handleAction('Profile')">My Profile</el-dropdown-item>
                <el-dropdown-item @click="handleAction('Settings')">Preferences</el-dropdown-item>
                <el-dropdown-item divided @click="handleAction('Logout')">
                  Sign Out
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <!-- Dashboard View Body -->
      <el-main class="main-content">
        <!-- Stats Grid Row -->
        <el-row :gutter="20" class="stats-row">
          <el-col v-for="stat in stats" :key="stat.title" :xs="24" :sm="12" :md="8">
            <el-card shadow="never" class="stat-card">
              <div class="stat-card-inner">
                <div
                  class="stat-icon-box"
                  :style="{ backgroundColor: stat.color + '15', color: stat.color }"
                >
                  <Icon :icon="stat.icon" />
                </div>
                <div class="stat-info">
                  <p class="stat-label">{{ stat.title }}</p>
                  <h3 class="stat-value">{{ stat.value }}</h3>
                </div>
              </div>
            </el-card>
          </el-col>
        </el-row>

        <!-- Dynamic Action Content Cards -->
        <el-row :gutter="20">
          <el-col :xs="24" :md="16">
            <el-card shadow="never" class="content-card">
              <template #header>
                <div class="card-header">
                  <span>Overview & Progress</span>
                  <el-button
                    type="primary"
                    size="small"
                    plain
                    @click="handleAction('Refresh View')"
                  >
                    Refresh Data
                  </el-button>
                </div>
              </template>
              <div class="welcome-banner">
                <h2>Welcome Back, {{ user.username.split(' ')[0] }}!</h2>
                <p>
                  All core infrastructure integrations—including your customized asynchronous
                  lazy-router chunk loaders—are running flawlessly.
                </p>
              </div>
            </el-card>
          </el-col>

          <el-col :xs="24" :md="8">
            <el-card shadow="never" class="content-card">
              <template #header>
                <div class="card-header">
                  <span>Recent Events</span>
                </div>
              </template>
              <div class="activity-timeline">
                <div v-for="item in recentActivities" :key="item.id" class="activity-item">
                  <span
                    class="activity-dot"
                    :style="{
                      backgroundColor:
                        item.type === 'success'
                          ? '#67C23A'
                          : item.type === 'warning'
                            ? '#E6A23C'
                            : '#909399',
                    }"
                  ></span>
                  <div class="activity-body">
                    <p class="activity-text">{{ item.text }}</p>
                    <span class="activity-time">{{ item.time }}</span>
                  </div>
                </div>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </el-main>
    </el-container>
  </el-container>
</template>

<style scoped lang="less">
  .layout-container {
    height: 100vh;
    background-color: #f8fafc;
  }

  /* Sidebar Design Styles */
  .aside-menu {
    background-color: #0f172a;
    transition: width 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    display: flex;
    flex-direction: column;
    overflow: hidden;

    .logo-wrapper {
      height: 64px;
      display: flex;
      align-items: center;
      padding: 0 20px;
      gap: 12px;
      border-bottom: 1px solid #1e293b;
      color: #ffffff;

      .logo-icon {
        font-size: 24px;
        color: #38bdf8;
        flex-shrink: 0;
      }
      .logo-text {
        font-size: 18px;
        font-weight: 700;
        letter-spacing: -0.02em;
        white-space: nowrap;
      }
    }

    .el-menu-vertical {
      border-right: none;
      width: 100%;
    }

    .menu-icon {
      font-size: 18px;
      margin-right: 12px;
    }
  }

  /* Navbar Header Styles */
  .navbar-header {
    height: 64px;
    background-color: #ffffff;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 24px;

    .header-left {
      display: flex;
      align-items: center;
      gap: 16px;

      .collapse-toggle {
        background: none;
        border: none;
        font-size: 20px;
        color: #64748b;
        cursor: pointer;
        display: flex;
        align-items: center;
        padding: 4px;
        border-radius: 4px;
        transition: background-color 0.2s;

        &:hover {
          background-color: #f1f5f9;
        }
      }

      .page-title {
        font-size: 16px;
        font-weight: 600;
        color: #0f172a;
      }
    }

    .header-right {
      .profile-trigger {
        display: flex;
        align-items: center;
        gap: 10px;
        cursor: pointer;
        padding: 4px 8px;
        border-radius: 6px;
        transition: background-color 0.2s;

        &:hover {
          background-color: #f1f5f9;
        }

        .avatar-img {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          object-fit: cover;
          border: 2px solid #e2e8f0;
        }

        .user-meta {
          display: flex;
          flex-direction: column;
          text-align: left;

          .user-name {
            font-size: 14px;
            font-weight: 500;
            color: #1e293b;
            line-height: 1.2;
          }
          .user-role {
            font-size: 12px;
            color: #64748b;
          }
        }
      }
    }
  }

  /* Body Content View Layouts */
  .main-content {
    padding: 24px;
    overflow-y: auto;

    .stats-row {
      margin-bottom: 24px;
    }

    .stat-card {
      border: 1px solid #e2e8f0;
      border-radius: 12px;

      .stat-card-inner {
        display: flex;
        align-items: center;
        gap: 16px;

        .stat-icon-box {
          width: 48px;
          height: 48px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 22px;
        }

        .stat-info {
          .stat-label {
            margin: 0 0 4px 0;
            font-size: 13px;
            color: #64748b;
          }
          .stat-value {
            margin: 0;
            font-size: 22px;
            font-weight: 700;
            color: #0f172a;
          }
        }
      }
    }

    .content-card {
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      margin-bottom: 24px;

      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;

        font-weight: 600;
        color: #1e293b;
      }
    }
    .welcome-banner {
      padding: 12px 4px;
      h2 {
        margin: 0 0 8px 0;
        color: #0f172a;
        font-weight: 700;
      }
      p {
        margin: 0;
        color: #475569;
        font-size: 14px;
        line-height: 1.6;
      }
    } /* Minimal Timeline Structure */
    .activity-timeline {
      display: flex;
      flex-direction: column;
      gap: 16px;
      .activity-item {
        display: flex;
        gap: 12px;
        align-items: flex-start;
        .activity-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          margin-top: 6px;
          flex-shrink: 0;
        }
        .activity-body {
          .activity-text {
            margin: 0 0 2px 0;
            font-size: 13.5px;
            color: #334155;
          }
          .activity-time {
            font-size: 11px;
            color: #94a3b8;
          }
        }
      }
    }
  }
</style>
