import TreeMenu from './TreeMenu.vue';

export default TreeMenu;

export * from '@/types/commonTypes';
