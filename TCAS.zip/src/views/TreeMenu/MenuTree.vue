<!-- MenuTree.vue -->
<template>
  <div class="menu-tree">
    <TreeNode
      v-for="item in menuData"
      :key="item.path || item.name"
      :node="item"
      :active-path="activePath"
      :expanded-keys="expandedKeys"
      :toggle-expand="toggleExpand"
      :on-node-click="handleNodeClick"
      :depth="0"
      :max-depth="maxDepth"
      :clickable-levels="clickableLevels"
      :navigable-levels="navigableLevels"
    />
  </div>
</template>

<script setup lang="ts">
  import { ref, computed, watch } from 'vue';
  import { useRoute, useRouter, type RouteRecordRaw } from 'vue-router';
  import TreeNode from './TreeNode.vue';

  export interface MenuMeta {
    label: string;
    icon?: string; // icon class or name (e.g. 'i-mdi-home')
    disabled?: boolean;
    [key: string]: any; // 其他自定义控制字段
  }

  export interface MenuItem extends Omit<RouteRecordRaw, 'children' | 'meta'> {
    meta: MenuMeta;
    children?: MenuItem[];
  }

  const props = defineProps<{
    menuData: MenuItem[];
    // 可选：默认展开的路径数组（支持多层）
    defaultExpanded?: string[];
    // 可选：最大递归深度（默认不限制）
    maxDepth?: number;
    // 可选：哪些层级可点击（从0开始，-1表示全部）
    clickableLevels?: number[];
    // 可选：哪些层级可跳转路由（从0开始，-1表示全部）
    navigableLevels?: number[];
  }>();

  const emit = defineEmits<{
    (e: 'node-click', node: MenuItem): void;
  }>();

  const route = useRoute();
  const router = useRouter();

  const activePath = ref(route.path);
  const expandedKeys = ref<Set<string>>(new Set(props.defaultExpanded || []));

  // 监听路由变化自动高亮
  watch(
    () => route.path,
    (newPath) => {
      activePath.value = newPath;
    }
  );

  const toggleExpand = (key: string) => {
    if (expandedKeys.value.has(key)) {
      expandedKeys.value.delete(key);
    } else {
      expandedKeys.value.add(key);
    }
    // 触发响应式更新
    expandedKeys.value = new Set(expandedKeys.value);
  };

  const handleNodeClick = (node: MenuItem, isNavigable: boolean) => {
    emit('node-click', node);

    if (isNavigable && node.path) {
      router.push(node.path);
    }
  };

  // 如果想默认展开所有第一层，可以这样处理
  // 但这里保持用户传入的 defaultExpanded 更灵活
</script>

<style scoped>
  .menu-tree {
    width: 100%;
    user-select: none;
  }
</style>
