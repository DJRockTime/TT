<!-- TreeNode.vue -->
<template>
  <div class="tree-node">
    <!-- 当前节点 -->
    <div
      class="node-item"
      :class="{
        active: isActive,
        disabled: isDisabled,
        'has-children': hasChildren,
      }"
      :style="{ paddingLeft: `${depth * 16}px` }"
      @click="handleClick"
    >
      <!-- 展开/折叠图标 -->
      <span v-if="hasChildren" class="toggle-icon" @click.stop="toggle">
        {{ isExpanded ? '▼' : '▶' }}
      </span>
      <span v-else class="toggle-placeholder"></span>

      <!-- 图标 -->
      <span v-if="node.meta?.icon" class="node-icon">
        <i :class="node.meta.icon"></i>
      </span>

      <!-- 标签 -->
      <span class="node-label">{{ node.meta?.label || node.name || node.path }}</span>
    </div>

    <!-- 子节点递归 -->
    <div v-if="hasChildren" class="node-children" :class="{ expanded: isExpanded }">
      <TreeNode
        v-for="child in node.children"
        :key="child.path || child.name"
        :node="child"
        :active-path="activePath"
        :expanded-keys="expandedKeys"
        :toggle-expand="toggleExpand"
        :on-node-click="onNodeClick"
        :depth="depth + 1"
        :max-depth="maxDepth"
        :clickable-levels="clickableLevels"
        :navigable-levels="navigableLevels"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed } from 'vue';
  import type { MenuItem } from './MenuTree.vue';

  const props = defineProps<{
    node: MenuItem;
    activePath: string;
    expandedKeys: Set<string>;
    toggleExpand: (key: string) => void;
    onNodeClick: (node: MenuItem, isNavigable: boolean) => void;
    depth: number;
    maxDepth?: number;
    clickableLevels?: number[];
    navigableLevels?: number[];
  }>();

  const hasChildren = computed(() => !!(props.node.children && props.node.children.length > 0));

  const isExpanded = computed(() => props.expandedKeys.has(getKey(props.node)));

  const isActive = computed(
    () => props.activePath === props.node.path || props.activePath.startsWith(props.node.path + '/')
  );

  const isDisabled = computed(() => props.node.meta?.disabled === true);

  const currentLevel = computed(() => props.depth);

  const isClickable = computed(() => {
    if (props.clickableLevels === undefined) return true;
    if (props.clickableLevels.includes(-1)) return true;
    return props.clickableLevels.includes(currentLevel.value);
  });

  const isNavigable = computed(() => {
    if (!props.node.path) return false;
    if (props.navigableLevels === undefined) return true;
    if (props.navigableLevels.includes(-1)) return true;
    return props.navigableLevels.includes(currentLevel.value);
  });

  const shouldRenderChildren = computed(() => {
    if (props.maxDepth !== undefined && props.depth >= props.maxDepth) {
      return false;
    }
    return hasChildren.value;
  });

  function getKey(node: MenuItem): string {
    return node.path || node.name || String(Math.random());
  }

  function toggle(e: Event) {
    e.stopImmediatePropagation();
    props.toggleExpand(getKey(props.node));
  }

  function handleClick() {
    if (isDisabled.value || !isClickable.value) return;
    props.onNodeClick(props.node, isNavigable.value);
  }
</script>

<style scoped>
  .tree-node {
    font-size: 14px;
  }

  .node-item {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    cursor: pointer;
    border-radius: 4px;
    transition: all 0.2s ease;
    color: #333;
  }

  .node-item:hover {
    background-color: #f5f5f5;
  }

  .node-item.active {
    background-color: #e6f0ff;
    color: #1890ff;
    font-weight: 500;
  }

  .node-item.disabled {
    color: #aaa;
    cursor: not-allowed;
  }

  .node-item.disabled:hover {
    background-color: transparent;
  }

  /* 展开/折叠图标旋转动画 */
  .toggle-icon {
    display: inline-block;
    width: 18px;
    margin-right: 4px;
    font-size: 12px;
    transition: transform 0.3s ease;
  }

  .toggle-icon:hover {
    transform: scale(1.1);
  }

  /* 关键：子菜单动画 */
  .node-children {
    margin-left: 8px;
    overflow: hidden;
    max-height: 0;
    opacity: 0;
    transition:
      max-height 0.35s ease,
      opacity 0.35s ease;
  }

  .node-children.expanded {
    max-height: 1200px; /* 足够大，支持较深层级 */
    opacity: 1;
  }

  .toggle-placeholder {
    display: inline-block;
    width: 22px;
  }

  .node-icon {
    margin-right: 8px;
    font-size: 16px;
    color: #666;
  }

  .node-label {
    flex: 1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
