import { computed, inject, provide, ref, watch, type InjectionKey, type Ref } from 'vue';

import { useRoute, useRouter } from 'vue-router';

import type { TreeMenuData } from '@/types/commonTypes';

export interface TreeContext {
  expandedKeys: Ref<Set<string>>;

  selectedKeys: Ref<Set<string>>;

  activePath: Ref<string>;

  accordion: Ref<boolean>;

  toggle: (id: string) => void;

  select: (id: string) => void;

  navigate: (path?: string) => void;

  expandAll: () => void;

  collapseAll: () => void;
}

const TREE_KEY: InjectionKey<TreeContext> = Symbol('TREE_MENU');

/**
 * 初始化树关系
 */
function buildTree(menus: TreeMenuData[], parent?: TreeMenuData, level = 0) {
  menus.forEach((item) => {
    item.parent = parent;

    item.level = level;

    if (item.children?.length) {
      buildTree(item.children, item, level + 1);
    }
  });
}

/**
 * 收集全部ID
 */
function collectIds(menus: TreeMenuData[], result: string[]) {
  menus.forEach((item) => {
    result.push(item.id);

    if (item.children?.length) {
      collectIds(item.children, result);
    }
  });
}

export function provideTree(options: {
  menus: TreeMenuData[];

  accordion?: boolean;

  defaultExpandedKeys?: string[];

  defaultSelectedKeys?: string[];
}) {
  const router = useRouter();

  const route = useRoute();

  buildTree(options.menus);

  const expandedKeys = ref(new Set(options.defaultExpandedKeys ?? []));

  const selectedKeys = ref(new Set(options.defaultSelectedKeys ?? []));

  const accordion = ref(Boolean(options.accordion));

  const activePath = computed(() => route.path);

  function toggle(id: string) {
    if (accordion.value) {
      expandedKeys.value.clear();
    }

    if (expandedKeys.value.has(id)) {
      expandedKeys.value.delete(id);
    } else {
      expandedKeys.value.add(id);
    }
  }

  function select(id: string) {
    selectedKeys.value.clear();

    selectedKeys.value.add(id);
  }

  function navigate(path?: string) {
    if (!path) return;

    if (route.path === path) return;

    router.push(path);
  }

  function expandAll() {
    const ids: string[] = [];

    collectIds(options.menus, ids);

    expandedKeys.value = new Set(ids);
  }

  function collapseAll() {
    expandedKeys.value.clear();
  }

  /**
   * 路由变化
   * 自动同步 selected
   */
  watch(
    activePath,
    () => {
      const loop = (menus: TreeMenuData[]) => {
        menus.forEach((item) => {
          if (item.path && route.path.startsWith(item.path)) {
            select(item.id);

            let current = item.parent;

            while (current) {
              expandedKeys.value.add(current.id);

              current = current.parent;
            }
          }

          if (item.children?.length) {
            loop(item.children);
          }
        });
      };

      loop(options.menus);
    },
    {
      immediate: true,
    }
  );

  provide(TREE_KEY, {
    expandedKeys,

    selectedKeys,

    accordion,

    activePath,

    toggle,

    select,

    navigate,

    expandAll,

    collapseAll,
  });
}

export function useTree() {
  const tree = inject(TREE_KEY);

  if (!tree) {
    throw new Error('TreeMenu 必须包裹 TreeNode 使用');
  }

  return tree;
}
