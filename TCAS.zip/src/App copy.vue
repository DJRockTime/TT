<script setup lang="ts">
import Chat from "@/views/chat/index.vue";
</script>

<template>
    <Chat />
</template>
