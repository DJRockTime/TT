import axios from "axios";

export const chatApi = (message: string) => {
    return axios.post("http://127.0.0.1:8000/chat", {
        message,
    });
};

export async function streamChat(
    message: string,
    onChunk: (s: string) => void,
    signal: AbortSignal,
) {
    try {
        const res = await fetch("http://127.0.0.1:8000/stream", {
            method: "POST",

            headers: {
                "Content-Type": "application/json",
            },

            body: JSON.stringify({
                message,
            }),

            signal,
        });

        const reader = res.body?.getReader();

        if (!reader) {
            return;
        }

        const decoder = new TextDecoder();

        while (true) {
            const { done, value } = await reader.read();

            if (done) {
                break;
            }

            onChunk(decoder.decode(value));
        }
    } catch (e) {
        if (e instanceof DOMException && e.name === "AbortError") {
            console.log("用户停止生成");

            return;
        }

        throw e;
    }
}
