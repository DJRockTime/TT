import type { NavigationItem } from '@/types/commonTypes';

import { navigation as home } from './modules/home';
import { navigation as product } from './modules/product';
import { navigation as message } from './modules/message';
import { navigation as news } from './modules/news';

export default [home, product, message, news];

export const navigation: NavigationItem[] = [
  {
    id: 'home',
    title: '首页',
    mode: 'link',
    path: '/home',
  },

  {
    id: 'product',
    title: '产品',
    mode: 'dropdown',
    children: [
      {
        id: 'product1',
        title: '产品一',
        mode: 'link',
        path: '/product1',
      },
      {
        id: 'product2',
        title: '产品二',
        mode: 'link',
        path: '/product2',
      },
    ],
  },

  {
    id: 'message',
    title: '消息中心',
    mode: 'mega',
    children: [
      {
        id: 'notice',
        title: '通知',
        mode: 'link',
        path: '/message',
      },
      {
        id: 'email',
        title: '邮件',
        mode: 'link',
        path: '/message',
      },
      {
        id: 'todo',
        title: '待办',
        mode: 'link',
        path: '/message',
      },
    ],
  },

  {
    id: 'github',
    title: 'Github',
    mode: 'external',
    href: 'https://github.com',
  },
];
