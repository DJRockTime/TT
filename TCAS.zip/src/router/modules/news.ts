import type { RouteRecordRaw } from 'vue-router';
import { lazy } from '@/router/lazy';

export const navigation = {
  id: 'news',
  title: '新闻',
  mode: 'link',
  path: '/news',
  module: 'news',
};

const routes: RouteRecordRaw[] = [
  {
    path: '/news',
    name: 'News',
    component: lazy('News'),

    meta: {
      title: '新闻',
      left: true,
      right: true,
    },
  },
];

export default routes;
