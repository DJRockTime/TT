import type { RouteRecordRaw } from 'vue-router';
import { lazy } from '@/router/lazy'; // Import the lazy loading utility

export const navigation = {
  id: 'product',
  mode: 'dropdown',
  title: '产品',
  path: '/product',
  children: [],
  module: 'product',
};

const routes: RouteRecordRaw[] = [
  {
    path: '/product',
    component: lazy('Root'),
    children: [
      {
        path: '/product1',
        name: 'ProductHome',
        component: lazy('Product'),
        meta: {
          title: '产品',
          showLeft: true,
          showRight: false,
        },
      },
    ],
  },
];

export default routes;
