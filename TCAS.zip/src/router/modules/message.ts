import type { RouteRecordRaw } from 'vue-router';
import { lazy } from '@/router/lazy';

export const navigation = {
  id: 'message',
  title: '消息',
  mode: 'link',
  path: '/message',
  module: 'message',
};

const routes: RouteRecordRaw[] = [
  {
    path: '/message',
    name: 'Message',
    component: lazy('Message'),
    meta: {
      title: '消息',
      left: false,
      right: true,
    },
  },
];

export default routes;
