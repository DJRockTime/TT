import type { RouteRecordRaw } from 'vue-router';
import { lazy } from '@/router/lazy';

export const navigation = {
  id: 'home',
  title: '首页',
  mode: 'link',
  path: '/home',
  module: 'home',
};

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    redirect: '/home',
  },
  {
    path: '/home',
    name: 'Home',
    component: lazy('Root'),
    children: [
      {
        path: '',
        name: 'HomeView',
        component: lazy('Home'),
        meta: {
          title: '首页',
          showLeft: false,
          showRight: true,
        },
      },
    ],
  },
];

export default routes;
