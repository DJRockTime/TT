// 1. 递归扫描 src 目录下的所有 .vue 文件
const modules = import.meta.glob('../**/*.vue', { eager: false });

/**
 * 严格匹配文件名延迟加载 Vue 组件
 * @param fileName 严格区分大小写的文件名（不带后缀，如 'Home' 或 'NotFoundView'）
 */
export function lazy(fileName: string) {
  // 在扫描到的字典中寻找严格匹配文件名的路径
  let matchPath = Object.keys(modules).find((path) => {
    const currentFileName = path.split('/').pop()?.replace('.vue', '');
    return currentFileName === fileName;
  });

  // 2. 核心修复：如果找不到传入的文件，尝试直接降级匹配 'NotFoundView'
  if (!matchPath) {
    console.error(`[Lazy Router Error]: 找不到匹配 "${fileName}" 的组件，正在降级到 NotFoundView`);

    // 自动在全局模块中寻找名为 'NotFoundView' 的文件路径
    matchPath = Object.keys(modules).find((path) => {
      return path.split('/').pop()?.replace('.vue', '') === 'NotFoundView';
    });
  }

  // 3. 如果连 NotFoundView 都没在项目中创建，抛出最终致命错误
  if (!matchPath) {
    throw new Error(`[Lazy Router Fatal Error]: 项目中未找到任何 NotFoundView.vue 文件！`);
  }

  // 返回对应的动态导入函数 () => import('...')
  return modules[matchPath];
}
