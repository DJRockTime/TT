import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router';

import home from '@/router/modules/home'; // Import the Home component
import product from '@/router/modules/product'; // Import the Product component
import message from '@/router/modules/message'; // Import the Message component
import news from '@/router/modules/news'; // Import the News component

// 1. Define your routes
const routes: RouteRecordRaw[] = [...home, ...product, ...message, ...news];

// 2. Create the router instance
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
  // Automatically scroll to top on route change
  scrollBehavior(_to, _from, savedPosition) {
    if (savedPosition) {
      return savedPosition;
    }
    return { top: 0 };
  },
});

// 3. Navigation Guard (Optional: Updates page title dynamically)
router.beforeEach((to, _from, next) => {
  const baseTitle = 'My App';
  document.title = to.meta.title ? `${to.meta.title} | ${baseTitle}` : baseTitle;
  next();
});

export default router;
