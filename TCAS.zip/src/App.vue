<template>
  <!-- Routed views will render directly here -->
  <router-view />
  <!-- <NotFoundView /> -->
</template>

<script setup lang="ts">
  // No extra setup logic needed for a pure entry wrapper
  // import NotFoundView from '@/views/notFound/NotFoundView.vue';
</script>

<style lang="less">
  @import '@/assets/css/common.less';
  @import '@/assets/css/global.less';

  #app {
    height: 100%;
  }
</style>
