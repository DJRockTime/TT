import { createApp } from 'vue';
import { createPinia } from 'pinia'; // 1. Import Pinia
import ElementPlus from 'element-plus';
import App from './App.vue';
import router from './router'; // 2. Import Router

import 'element-plus/dist/index.css';

const app = createApp(App);
const pinia = createPinia(); // 3. Create Pinia instance

// Register plugins
app.use(pinia);
app.use(router);
app.use(ElementPlus);

app.mount('#app');
